Overview:
  This directory contains a quick start validation tool to validate Teradata Message
  Queue Access Module after installation.

Directory Contents:
  mqaxsmodvalidate.bat -- This script is installed on Windows platform. You must
  execute this script from its current installed location.The script 
  will execute mqaxsmodqstart.fl in the quickstart directory.
	
  Usage: mqaxsmodvalidate.bat [NODEID] [UserName] [UserPassword]
  where: [NODIE] is a database name ID.
       	 [UserName] is a database user name.
       	 [UserPassword] is a database user password.

  mqaxsmodvalidate.ksh -- This script is installed on unix platforms. You must
  execute this script from its current installed location.The script 
  will execute mqaxsmodqstart.fl in the quickstart directory 

	 Usage: ./mqaxsmodvalidate.ksh <NODEID> <UserName> <UserPassword>
         where: <NODEID> is a database name ID
   	        <UserName> is database user name.
      	        <UserPassword> is database user password.
User can edit mqaxsmod_parmfile and give desired inputs.The sample mqaxsmod_parmfile contains
QMGR test_qm
QNM test_qm
CKFILE MQCHKPT 
where test_qm is sample queue manager and sample queue.
Before running mqaxsmodvalidate.bat or mqaxsmodvalidate.ksh user has to put messages into queue.

