/* % TITLE pmddamt.h ... Device Dependent Access module structs/types       */
/****************************************************************************/
/*                                                                          */
/*  Copyright 1997-2014,2018,2020 Teradata Corporation. ALL RIGHTS RESERVED.*/
/*  Teradata Corporation CONFIDENTIAL AND TRADE SECRET                      */
/*  This copyrighted material is the Confidential, Unpublished              */
/*  Property of the Teradata Corporation.  This copyright notice            */
/*  and any other copyright notices included in machine readable            */
/*  copies must be reproduced on all authorized copies.                     */
/*                                                                          */
/* CRITICAL USAGE NOTE:                                                     */
/*  This header file is to be the EXACT same file for both SA & TPT.        */
/*  The cooresponding versions in /vob/tdcli & /vob/paralx must match       */
/*  The identiy will insure that the same access module will work with      */
/*  the standalone utilities AND the TPT DC oeprator                        */
/*                                                                          */
/* History Information                                                      */
/*                                                                          */
/*                      JIRA                                                */
/* Revision    Date     ISSUE    DID      Comments                          */
/* ----------- -------- -------- -------- -----------------------           */
/* 17.00.00.00 05122020 SA52533  HM186000 Merge/Sync Access Module Header   */
/*                                        Files From TPT DC                 */
/* 16.20.00.00 08202018 SA50999  HM186000 Dataconnector and Axsmod's need to*/
/*                                        support any length access module  */
/*                                        init string                       */
/* 15.10.00.00 06122014 SA33970  HM186000 Merge/Sync Access Module Header   */
/*                                        Files From TPT                    */
/* 14.10.00.00 27072012 SA3822   HM186000 PIOM porting on Mac OS            */
/*                                                                          */
/*                      DR/#                                                */
/* Revision    Date     DCR    DID    Comments                              */
/* ----------- -------- -----  ------ -----------------------               */
/* 14.00.00.02 12032010 141568 MN7    Win64bit PIOM to handle alignment     */
/* 14.00.00.01 11292010 143378 TWB    Expand filename size                  */
/* 13.10.00.01 08272008 115918 TWB    IBM compiler.  Changes                */
/*                                    courtesy ASG & DEH                    */
/* 13.00.00.01 06262007 100091 TWB    Common AM headers                     */
/* 02.04.00.01 01062006 100716 TWB    Timeout support (added header ID)     */
/* 02.02.00.03 06242005  94488 CSG    Port to HP-Itanium                    */
/* 02.02.00.02 04292004  68938 TWB    AIX packing                           */
/* 02.02.00.01 04212004  86512 TWB    Update version id                     */
/* 02.00.00.06 11142002  65685 TRV    pack 1 avoided for Win64 platform     */
/* 02.00.00.05 11072002  64602 TWB    Add header version Ids                */
/* 02.00.00.04 09022002  64540 TRV    Changes for NPAM C++ compilation      */
/* 02.00.00.03 08272002  63707 TWB    Copyright Notice                      */
/* 02.00.00.02 07182002  58762 TRV    HPUX 64-bit Porting                   */
/* 02.00.00.01 07042002  58755 TRV    SOLARIS SPARC 64-bit Porting          */
/* 02.00.00.00 07012002  58754 TRV    Native 64-bit Client Support          */
/* 01.04.00.03 02152001  53279 CSG    Port DATACON to AIX                   */
/* 01.04.00.02 02132001  53280 CSG    Port DATACON to HPUX                  */
/* 01.04.00.01 11142000  52214 CSG    To support Solaris C++ compilation    */
/* 01.02.00.01 05051999  46309 TWB    Up error text length from 512 to 32000*/
/* 01.01.00.02 07121998  42617 TWB    Included CPP extern for PIDMMain      */
/* 01.01.00.01 05291998  42617 TWB    Initial externalization of API        */
/*                                                                          */
/****************************************************************************/

#ifndef PMDDAMT_H
#define PMDDAMT_H

/* DR 58755, DR 58762  --> */

#if defined(HPUX) && defined(PIOM64) && !defined(HPUX_IA64) /*DR94488*/
   #ifdef __cplusplus                    /* DR 64540 --> */
      #define pmddamt_packing "pack 8"                                   /* 86512 */
      #pragma pack 8 
   #else
      /*#define pmddamt_packing "HP_ALIGN NATURAL PUSH"*/         /*86512#SA33970*/
      /*#pragma HP_ALIGN NATURAL PUSH */                                /*SA33970*/
   #endif                                /* DR 64540 <-- */
#elif defined(HPUX_IA64) && defined(PIOM64)   /* DR 94488 --> */
   #define pmddamt_packing "pack(8)"
   #pragma pack(8)                               /* DR 94488 <-- */
#elif defined(SOLARIS) && defined(PIOM64)
   #define pmddamt_packing "pack(8)"                                  /* 86512 */
   #pragma pack(8)
#elif defined (AIX)                                                /* 68938 */
   #define pmddamt_packing "options align=packed"                    /*TPT21117*/
   #pragma options align=packed                                       /* 68938 */
#elif defined(__MVS__)                                            /* 115918 */
   #pragma pack(packed)                                              /* 115918 */
   #define pmddamt_packing "pack(packed)"                            /* 115918 */
#elif !defined(HPUX) && !defined(SOLARIS)                         /* 115918 */\
      && !defined(_WIN64) && !defined(__APPLE__) /* DRs: 53279, 53280, 52214, 65685,SA3822 */
   #define pmddamt_packing "pack (push, 1)"                           /* 86512 */
   #pragma pack (push, 1)
#elif defined(_WIN64)                                              /*141568*/
   #define pmddamt_packing "pack (push, 1)"                         /*TPT21117*/
   #pragma pack (push, 1)                                             /*141568*/
#endif                                                             /*141568*/

#if !defined (pmddamt_packing)                                     /* 64602 */
   #define pmddamt_packing "none"                                     /* 86512 */
#endif                                                             /* 64602 */

/* DR 58755, DR 58762 <-- */

#define pmddamt_HeaderVersion "Common 17.00.00.00"         /* SRC_ID SA52533 */
#define pmddamt_ID "pmddamt header version '" pmddamt_HeaderVersion \
 "', packing '" pmddamt_packing "'"
/* DR 58754 --> */

#ifdef PIOM64
#define pmiInterfaceVersion   2001
#else
#define pmiInterfaceVersion   2000
#endif

/* DR 58754 <-- */

#define pmiMAX_EC_LEN        30
/*                                EyeCatcher strings for each structure type */
#define pmiEC_CmdBlock_t    "AXSMOD block:CmdBlock_t"
#define pmiEC_Init_t        "AXSMOD block:Init_t"
#define pmiEC_Open_t        "AXSMOD block:Open_t"
#define pmiEC_Close_t       "AXSMOD block:Close_t"
#define pmiEC_RW_t          "AXSMOD block:RW_t"
#define pmiEC_Pos_t         "AXSMOD block:Pos_t"
#define pmiEC_Shut_t        "AXSMOD block:Shut_t" 
#define pmiEC_ID_t          "AXSMOD block:ID_t"
#define pmiEC_Attr_t        "AXSMOD block:Attr_t"

#define pmiMAX_INIT_STR_LEN 512
#define pmiMAX_FNAME_LEN    32767                                  /* 143378 */
#define pmiMAX_ETEXT_LEN    32000                                /* DR 46309 */

/*                               the following defines are required only for */
/*                              communications between the DIAM and the DDAM */
#define pmiPIDMOptInit     1 
#define pmiPIDMOptOpen     2
#define pmiPIDMOptClose    3
#define pmiPIDMOptCloseR   10
#define pmiPIDMOptRead     4
#define pmiPIDMOptWrite    5
#define pmiPIDMOptGetPos   6
#define pmiPIDMOptSetPos   7
#define pmiPIDMOptShut     8
#define pmiPIDMOptID       9
#define pmiPIDMOptGetA_A   11
#define pmiPIDMOptGetF_A   12
#define pmiPIDMOptPutA_A   13
#define pmiPIDMOptPutF_A   14

typedef struct _pmiInit
{
 char      EyeCatcher[pmiMAX_EC_LEN];   /* Struct eyecatcher string */
 pmUInt32  StructLength;                /* Length of this structure */
 void     *PIData;           /* Access module Internal Data Pointer */
 pmUInt16  InterfaceVerNo;          /* pmdcomt.h version identifier */
 pmUInt16  InterfaceVerNoD;         /* pmddamt.h version identifier */
 pmUInt32  ClientIDL;                   /* Length of ClientID field */
 pmUInt32  InitStrL;                     /* Length of InitStr field */
 char      ClientID[pmMAX_CLIENT_ID+1];        /* Client identifier */
 char      InitStr[pmiMAX_INIT_STR_LEN+1];  /* Initialization field */
 pmUInt32  NewInitStrL;              /* Length of new InitStr field *//*SA50999*/
 char     *NewInitStr;                  /* New initialization field *//*SA50999*/
} pmiInit_t;

typedef struct _pmiOpen
{
 char         EyeCatcher[pmiMAX_EC_LEN];        /* Struct eyecatcher string */
 pmUInt32     StructLength;                     /* Length of this structure */
 void        *PIData;                /* Access module Internal Data Pointer */
 pmOpenMode_t OpenMode;                                 /* provided to PIDM */
 pmUInt16     BlkHeaderLen;                              /* defined by PIDM */
 pmUInt32     BlkSize;                                   /* defined by PIDM */
 void        *FIData;         /* File Internal Data (returned/used by PIDM) */
 pmUInt16     FileNameL;                                /* provided to PIDM */
 char         FileName[pmiMAX_FNAME_LEN+1];             /* provided to PIDM */
} pmiOpen_t;

typedef struct _pmiClose
{
  char      EyeCatcher[pmiMAX_EC_LEN];   /* Struct eyecatcher string */
  pmUInt32  StructLength;                /* Length of this structure */
  void     *FIData;
} pmiClose_t;

typedef struct _pmiRW
{
  char      EyeCatcher[pmiMAX_EC_LEN];   /* Struct eyecatcher string */
  pmUInt32  StructLength;                /* Length of this structure */
  void     *FIData;
  pmUInt32  BufferLen;
  char     *Buffer;
} pmiRW_t;

typedef struct _pmiPos
{
  char      EyeCatcher[pmiMAX_EC_LEN];   /* Struct eyecatcher string */
  pmUInt32  StructLength;                /* Length of this structure */
  void     *FIData;
  pmPos_t   Position;
} pmiPos_t;

typedef struct _pmiShut
{
  char      EyeCatcher[pmiMAX_EC_LEN];   /* Struct eyecatcher string */
  pmUInt32  StructLength;                /* Length of this structure */
  void     *PIData;
  pmUInt16  Mode;
} pmiShut_t;

typedef struct _pmiID
{
  char       EyeCatcher[pmiMAX_EC_LEN];   /* Struct eyecatcher string */
  pmUInt32   StructLength;                /* Length of this structure */
  pmVerLst_t VerIDList;
} pmiID_t;

typedef struct _pmiAttribute
{
  char      EyeCatcher[pmiMAX_EC_LEN];   /* Struct eyecatcher string */
  pmUInt32  StructLength;                /* Length of this structure */
  void     *ObjData;            /* Object pointer (PIData or FIData) */
  pmUInt32  AttrNameLen;                 /* Length of attribute name */
  char      AttrName[pmMAX_ATR_NAME_LEN];         /* Attrribute name */
  pmUInt32  AttrValueLen;               /* Length of attribute value */
  char      AttrValue[pmMAX_ATR_VAL_LEN];         /* Attribute value */
} pmiAttr_t;

typedef struct _pmiCmdBlock
{
  char           EyeCatcher[pmiMAX_EC_LEN]; /* Struct eyecatcher string */
  pmUInt32       StructLength;              /* Length of this structure */
  pmUInt32       Reqtype;
  pmReturnType   Retcode;                                /* set by DDAM */
  pmTrceLvl_t    TraceLvl;
  pmNameBuf_t    ErrMsg;       /* Set by DDAM if retcode is pmrcFailure */
} pmiCmdBlock_t;

#ifdef WIN32
#ifdef CPP
extern "C"
      {
       __declspec(dllexport) void PIDMMain ( pmiCmdBlock_t *, void * );
      }
#else
__declspec(dllexport) void PIDMMain ( pmiCmdBlock_t *, void * );
#endif
#else
void PIDMMain ( pmiCmdBlock_t *, void * );
#endif

/* DR 58755, 58762 --> */

#if defined(HPUX) && defined(PIOM64) && !defined(HPUX_IA64) /*DR94488*/
   #ifdef __cplusplus                     /* DR 64540 --> */
      #pragma pack 
   #else
      /*#pragma HP_ALIGN POP */                                        /*TPT21117*/
   #endif                                 /* DR 64540 <-- */
#elif defined(HPUX_IA64) && defined(PIOM64)   /* DR 94488 --> */
   #pragma pack()                                /* DR 94488 <-- */
#elif defined(SOLARIS) && defined(PIOM64)
   #pragma pack()
#elif defined (AIX)                                                /* 68938 */
   #pragma options align=reset                                        /* 68938 */
#elif defined(__MVS__)                                            /* 115918 */
   #pragma pack(reset)                                               /* 115918 */
#elif !defined(HPUX) && !defined(SOLARIS)                         /* 115918 */\
      && !defined(_WIN64) && !defined(__APPLE__) /* DRs: 53279, 53280, 52214, 65685,SA3822 */
   #pragma pack (pop)
#elif defined(_WIN64)                                             /* 141568 */
   #pragma pack (pop)                                                /* 141568 */
#endif                                                            /* 141568 */

/* DR 58755, 58762 <-- */

#endif /* PMDDAMT_H */
