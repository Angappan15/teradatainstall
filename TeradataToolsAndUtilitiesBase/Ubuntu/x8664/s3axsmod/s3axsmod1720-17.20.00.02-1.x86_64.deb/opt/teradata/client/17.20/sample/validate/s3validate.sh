#!/bin/sh
#******************************************************************************
#*    Copyright 2016 Teradata Corporation. ALL RIGHTS RESERVED.
#*    TERADATA CONFIDENTIAL AND TRADE SECRET.
#*
#*    Teradata Access Module for Amazon S3 Quick Start
#*    validatation for UNIX
#*
#*******************************************************************************

BUCKET=$1
PREFIX=$2
OBJECT=$3
PATH=$4
REQUIRED_ARGS=4

error_handle (){
        echo "$@"
        echo "Note:"
        echo "***************************************************************************"
        echo "* Please refer to the console messages and try to fix the errors before   *"
        echo "* re-running the job again. If the job error message does not make sense, *"
        echo "* please capture the console output and send it to the Teradata GSC team. *"
        echo "***************************************************************************"
}

if test ! $# = $REQUIRED_ARGS
then
  echo "Script Usage: ./validate.sh parameter1 parameter2 parameter3 parameter4"
  echo "Test Binary Usage: ./s3am_testharness  [-h] |  [-v] [-t <n>]  [ -i <AWS ID> ] [ -k <AWS Key> ] [-g <n_read_limit>]  -r|-w  -m <module pathname> -p <module params>"
  echo "Example: ./s3am_testharness -w -p \"<S3Bucket=BucketName> <S3Prefix=PrefixName> <S3Object=ObjectName> -m <module_path>\""
  echo "where   <S3Bucket> This parameter specifies the Amazon S3 bucket to be used for load and export operations"
  echo "        <S3Prefix> This parameter is the name of the "directory" to be used within the bucket on the S3 service."
  echo "        <S3Object> S3Object is the name of the directory containing the files comprising the object."

  error_handle "Quick Start Validation of Teradata Access Module for Amazon S3 script failed."
  exit 1
fi

./s3am_testharness -w -p "S3Bucket=$BUCKET S3Prefix=$PREFIX S3Object=$OBJECT" -m $PATH

exit 0
