Overview:
  This directory contains a quick start validation tool to validate Teradata
  TPump after installation.

Directory Contents:
  tpumpvalidate.bat -- This script is installed on Windows platform. You must
  execute this script from its current installed location.  
  Usage: tpumpvalidate [NODEID] [UserName] [UserPassword]
  where: [NODEID] is a database name Id.
         [UserName] is a database User Name.
         [UserPassword] is a database User Password.

  tpumpvalidate.ksh -- This script is installed on UNIX platforms. You must
  execute this script from its current installed location.  
  Usage: ./tpumpvalidate.ksh [NODEID] [UserName] [UserPassword]
  where: [NODEID] is a database name Id.
         [UserName] is a database User Name.
         [UserPassword] is a database User Password.
