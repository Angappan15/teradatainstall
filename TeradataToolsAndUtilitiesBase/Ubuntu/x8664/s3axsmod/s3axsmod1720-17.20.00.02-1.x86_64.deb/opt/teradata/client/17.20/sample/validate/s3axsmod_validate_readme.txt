Overview:
  This directory contains a quick start validation tool to validate 
  Teradata Access Module for Amazon S3 after installation.

Directory Contents:
  s3validate.sh -- This script is installed on unix platforms. You must
  execute this script from its current installed location.The script
  will execute s3am_testharness in the quickstart directory

  Script Usage: ./s3validate.sh parameter1 parameter2 parameter3 parameter4
  
  Test Binary Usage: ./s3am_testharness  [-h] [-v] [-t <n>] [-r | -w ] 
  [ -k AWS Key ] [ -i AWS ID ] -m <module path>  -p <module params> 
  -g <n_read_limit>

  Test Binary Usage: ./s3am_testharness -h

  Usage: ./s3am_testharness  [-h] |  [-v] [-t <n>]  [ -i <AWS ID> ] [ -k <AWS Key> ] 
  [-g <n_read_limit>]  -r|-w  -m <module pathname> -p <module params>

        -h                   Print this usage message and exit
        -v                   Enable erbose logging
        -t <n>               Set diagnostic trace flag
        -i <AWS ID>          Set AWS ACCESS KEY ID env var for this run
        -k <AWS Key>         Set AWS SECRET ACCESS KEY env var for this run
        -g <n_read_limit>    Execute <n_read_limit> reads and then do a getpos() operation
        -r                   Read data from S3
        -w                   Write data to S3
        -m <pathname>        Pathname of the access module to load
        -p <parameters>      Parameters to be passed ot the access module
  
  The 4 parameters [parameter1, parameter2, parameter3 and parameter4] 
  are required by the Test Binary [s3am_testharness] 
  and are substituted as mentioned below for the Test Binary to work.
  ./s3am_testharness -w -p \"<S3Bucket=parameter1> <S3Prefix=parameter2> <S3Object=parameter3>\ -m <module path>"

  where -w for write mode and -r for read mode.
        -m <module path> Path for Teradata Access Module for Amazon S3.
        -p for module parameters which are described below.
        <S3Bucket> This parameter specifies the Amazon S3 bucket to be used for load and export operations
        <S3Prefix> This parameter is the name of the "directory" to be used within the bucket on the S3 service.
        <S3Object> S3Object is the name of the directory containing the files comprising the object.

validate.bat -- This script is installed on Windows platforms. You must
  execute this script from its current installed location.The script
  will execute s3am_testharness in the quickstart directory

  Script Usage: validate.bat parameter1 parameter2 parameter3
  
  Test Binary Usage: ./s3am_testharness  [-h] [-v] [-t <n>] [-r | -w ] 
  [ -k AWS Key ] [ -i AWS ID ] -m <module path>  -p <module params> 
  -g <n_read_limit>

  Test Binary Usage: ./s3am_testharness -h

  Usage: ./s3am_testharness  [-h] |  [-v] [-t <n>]  [ -i <AWS ID> ] [ -k <AWS Key> ] 
  [-g <n_read_limit>]  -r|-w  -m <module pathname> -p <module params>

        -h                   Print this usage message and exit
        -v                   Enable erbose logging
        -t <n>               Set diagnostic trace flag
        -i <AWS ID>          Set AWS ACCESS KEY ID env var for this run
        -k <AWS Key>         Set AWS SECRET ACCESS KEY env var for this run
        -g <n_read_limit>    Execute <n_read_limit> reads and then do a getpos() operation
        -r                   Read data from S3
        -w                   Write data to S3
        -m <pathname>        Pathname of the access module to load
        -p <parameters>      Parameters to be passed ot the access module
  
  The 3 parameters [parameter1, parameter2, parameter3] 
  are required by the Test Binary [s3am_testharness] 
  and are substituted as mentioned below for the Test Binary to work.
  s3am_testharness.exe -w -p \"<S3Bucket=parameter1> <S3Prefix=parameter2> <S3Object=parameter3>\ -m <module path>"

  where -w for write mode and -r for read mode.
        -m <module path> Path for Teradata Access Module for Amazon S3.
        -p for module parameters which are described below.
        <S3Bucket> This parameter specifies the Amazon S3 bucket to be used for load and export operations
        <S3Prefix> This parameter is the name of the "directory" to be used within the bucket on the S3 service.
        <S3Object> S3Object is the name of the directory containing the files comprising the object.
        

