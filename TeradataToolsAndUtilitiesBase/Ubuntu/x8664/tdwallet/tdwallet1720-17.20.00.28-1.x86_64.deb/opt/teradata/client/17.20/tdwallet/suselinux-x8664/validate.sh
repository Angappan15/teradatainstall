################################################################################
#
# TITLE: validate.sh
#
# Copyright 2014 by Teradata Corporation
# All rights reserved
# TERADATA CONFIDENTIAL AND TRADE SECRET
#
# Description: TDWallet product readiness validation script
#
# Revision    Date     JI     DID      Comments
# ----------- -------- -----  -------- ------------------------------------------
# 15.10.00.00 10302014 32651  MN185007 Initial version

#!/bin/ksh

./tdwallet list > /tmp/tdwalletprvt$$.txt 2>&1
rc=$?
if [[ $rc != 0 ]] ; then
    echo Teradata Wallet is not ready for use....The following error\(s\) occurred: 
    cat /tmp/tdwalletprvt$$.txt
else
    echo Teradata Wallet version $(./tdwallet version) is ready for use.
fi
rm /tmp/tdwalletprvt$$.txt > /dev/null
