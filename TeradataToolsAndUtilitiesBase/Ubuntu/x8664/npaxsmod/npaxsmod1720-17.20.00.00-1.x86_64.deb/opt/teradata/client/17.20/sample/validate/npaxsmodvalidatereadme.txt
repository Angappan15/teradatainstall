Overview:
  This directory contains a quick start validation tool to validate Teradata Named pipe
  Access Module after installation.

Directory Contents:
  npaxsmodvalidate.bat -- This script is installed on Windows platform. You must
  execute this script from its current installed location.  The script 
  will execute npaxsmodqstart.fl and npaxsmodqstart.fe scripts in the quickstart directory: 
	
  Usage: npaxsmodvalidate.bat [NODEID] [UserName] [UserPassword]
  where: [NODIE] is a database name ID.
       	 [UserName] is a database user name.
       	 [UserPassword] is a database user password.

  npaxsmodvalidate.ksh -- This script is installed on unix platforms. You must
  execute this script from its current installed location.  The script 
  will execute npaxsmodqstart.fl and npaxsmodqstart.fe scripts in the quickstart directory: 

  Usage: ./npaxsmodvalidate.ksh <NODEID> <UserName> <UserPassword>
  where: <NODEID> is a database name ID
         <UserName> is database user name.
         <UserPassword> is database user password.

