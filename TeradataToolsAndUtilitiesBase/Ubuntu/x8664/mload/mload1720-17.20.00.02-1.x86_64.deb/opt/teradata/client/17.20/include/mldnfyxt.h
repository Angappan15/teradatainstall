#ifndef MLDNFYXT_H
#define MLDNFYXT_H
/************************************************************************
*                                                                       *
* Title: MLDNFYXT.H     Header file to be used by notify exits          *
*                                                                       *
*                                                                       *
* Copyright 1990-2013,2021 Teradata Corporation.                        *
* ALL RIGHTS RESERVED.                                                  *
* Teradata Corporation CONFIDENTIAL AND TRADE SECRET                    *
*                                                                       *
* This copyrighted material is the Confidential, Unpublished            *
* Property of the Teradata Corporation.  This copyright notice and      *
* any other copyright notices included in machine readable              *
* copies must be reproduced on all authorized copies.                   *
*                                                                       *
*  Purpose       Header file to be used for notify exits under Mload.   *
*                                                                       *
*  Description   Notify header file.                                    *
*                                                                       *
* History Information                                                   *
*                                                                       *
* Revision    Date     Issue    DID      Comments                       *
* ----------- -------- -------- -------- ------------------------------ *
* 17.10.00.01 06202021 SA-53076 HM186000 MF connectivity via gateway    *
* 15.00.00.01 03212013 SA-29992 YY151001 14.10 and 15.0 Notify issue    *
* 15.00.00.00 02272013 SA-29733 YY151001 Fix DR112037                   *
* 14.10.00.00 10312012 SA-28635 HM186000 Enhance Notify Exit            *
*                                        functionality to support EON   *
*                                                                       *
* Revision    Date     DR    DID     Comments                           *
* ----------- -------- ----- ------- -----------------------------------*
* 14.00.00.03 12212010 147533 XX151000 More changes for 8 byte count    *
* 14.00.00.02 12032010 141944 XX151000 Support 8 byte counter           *
* 14.00.00.01 11012010 112037 sv185048 To add Database name             *
* 13.01.00.01 09152008 123961 YY151  Modify ML delete intialize event   *
* 13.00.00.00 09052007 115449 XX151000 Copyright changes                *
* 07.08.00.01 10052005 96203 CSG     Port to HP-UX Itanium              *
* 07.05.00.00 03132001 53286 CSG     Port MLOAD to HP-UX                *
* 07.02.00.01 07241998 42570 SFD     Update NOTIFY Event values         *
* 07.02.00.00 06221998 42570 SFD     Update NOTIFY EXIT interface       *
* 07.00.00.00 10/24/97 37833 MKB     Add Windows/NT support             *
* 06.00.00.00 11/15/96 38008 MKB     Add ClearCase support              *
*                                                                       *
* Past History                                                          *
*              H3_00  96Feb19  CME  DR 34581 add Export-like features   *
*              H3_01  96Apr15  MKB  DR 35873 MTEST compatibility        *
*                                                                       *
************************************************************************/
  
/*                                                     DR53286->       */
/* The following typedef has been commented out here and has been      */
/* put in mldnfyxt.c because of the reasons:-                          */
/* 1) This header file is being used by other mload source files.      */
/*    They are taking type defintions  already from coptypes.h.        */
/*    So ,on HP-UX,compiler is encountering type redefintion error     */
/* 2) This has been put in mldnfyxt.c ,because this file is using      */
/*    UInt32 , and not using coptypes.h                                */
/* typedef unsigned long UInt32;                                       */
/* #ifndef UInt32                                                      */
/* typedef unsigned long UInt32;                                       */
/* #endif                                                              */
/*                                                  <- DR53286         */
 
typedef enum {
   NMEventInitialize     =  0,
   NMEventFileInmodOpen  =  1,
   NMEventPhaseIBegin    =  2,
   NMEventCheckPoint     =  3,
   NMEventPhaseIEnd      =  4,
   NMEventPhaseIIBegin   =  5,
   NMEventPhaseIIEnd     =  6,
   NMEventErrorTableI    =  7,
   NMEventErrorTableII   =  8,
   NMEventDBSRestart     =  9,
   NMEventCLIError       = 10,
   NMEventDBSError       = 11,
   NMEventExit           = 12,
   NMEventAmpsDown       = 21,
   NMEventImportBegin    = 22,
   NMEventImportEnd      = 23,
   NMEventDeleteInit     = 24,
   NMEventDeleteBegin    = 25,
   NMEventDeleteEnd      = 26,
   NMEventDeleteExit     = 27,
   NMEventPhaseIEnd64    = 28,   /* DR141944 */
   NMEventImportEnd64    = 29,   /* DR141944 */
   NMEventInitializeEON  = 30,   /* SA-29992 */
   NMEventPhaseIBeginEON = 31,   /* SA-29992 */
   NMEventCheckPoint64   = 32,   /* SA-29992 */
   NMEventPhaseIIEnd64   = 33,   /* SA-29992 */
   NMEventErrorTableI64  = 34,   /* SA-29992 */
   NMEventErrorTableII64 = 35,   /* SA-29992 */
   NMEventDeleteInitEON  = 36,   /* SA-29992 */
   NMEventDeleteBeginEON = 37,   /* SA-29992 */
   NMEventDeleteEnd64    = 38    /* SA-29992 */
} NfyMLDEvent;

/**************************************/
/* Structure for User Exit Interface  */
/* DR42570 - redesigned and rewritten */
/**************************************/

#define NOTIFYID_FASTLOAD      1
#define NOTIFYID_MULTILOAD     2
#define NOTIFYID_FASTEXPORT    3
#define NOTIFYID_BTEQ          4
#define NOTIFYID_TPUMP         5

#define MAXVERSIONIDLEN    32
#define MAXUTILITYNAMELEN  32
#define MAXUSERNAMELEN     64
#define MAXUSERSTRLEN      80
#define MAXTABLENAMELEN   128
#define MAXFILENAMELEN    256
#define MAXDBASENAMELEN    62                           /* RFC 112037 */
#define MAXUINT64LEN       24                            /*  SA-29992 */


typedef struct _MLNotifyExitParm {
   UInt32 Event;                      /* should be NfyMLDEvent values */
   union {
      struct {
         UInt32 VersionLen;
         char   VersionId[MAXVERSIONIDLEN];
         UInt32 UtilityId;
         UInt32 UtilityNameLen;
         char   UtilityName[MAXUTILITYNAMELEN];
         UInt32 UserNameLen;        
         char   UserName[MAXUSERNAMELEN];
         UInt32 UserStringLen; 
         char   UserString[MAXUSERSTRLEN];
      } Initialize;
      struct {
         UInt32 FileNameLen;
         char   FileOrInmodName[MAXFILENAMELEN];
         UInt32 ImportNo;
      } FileInmodOpen ;
      struct {
         UInt32 TableNameLen;
         char   TableName[MAXTABLENAMELEN];
         UInt32 TableNo;
         char   DBaseName[MAXDBASENAMELEN];                 /*SA-29733*/
      } PhaseIBegin;
      struct {
         UInt32 RecordCount;
      } CheckPoint;
      struct {
         UInt32 RecsRead;
         UInt32 RecsSkipped;
         UInt32 RecsRejected;
         UInt32 RecsSent;
      } PhaseIEnd ;
      struct {
         UInt32 dummy;
      } PhaseIIBegin;
      struct {
         UInt32 Inserts;
         UInt32 Updates;
         UInt32 Deletes;
         UInt32 TableNo;
      } PhaseIIEnd;
      struct {
         UInt32 Rows;
         UInt32 TableNo;
      } ErrorTableI;
      struct {
         UInt32 Rows;
         UInt32 TableNo;
      } ErrorTableII ;
      struct {
         UInt32 dummy;
      } DBSRestart;
      struct {
         UInt32 ErrorCode;
      } CLIError;
      struct {
         UInt32 ErrorCode;
      } DBSError;
      struct {
         UInt32 ReturnCode;
      } Exit;
      struct {
         UInt32 dummy;
      } AmpsDown;
      struct {
         UInt32 ImportNo;
      } ImportBegin ;
      struct {
         UInt32 RecsRead;
         UInt32 RecsSkipped;
         UInt32 RecsRejected;
         UInt32 RecsSent;
         UInt32 ImportNo;
      } ImportEnd ;
      struct {/* DR123961 */
         UInt32 VersionLen;
         char   VersionId[MAXVERSIONIDLEN];
         UInt32 UtilityId;
         UInt32 UtilityNameLen;
         char   UtilityName[MAXUTILITYNAMELEN];
         UInt32 UserNameLen;        
         char   UserName[MAXUSERNAMELEN];
         UInt32 UserStringLen; 
         char   UserString[MAXUSERSTRLEN];
      } DeleteInit;
      struct {
         UInt32 TableNameLen;
         char   TableName[MAXTABLENAMELEN];
         UInt32 TableNo;
         char   DBaseName[MAXDBASENAMELEN];               /* SA-29992 */
      } DeleteBegin;
      struct {
         UInt32 Deletes;
         UInt32 TableNo;
      } DeleteEnd;
      struct {
         UInt32 ReturnCode;
      } DeleteExit;   
/*SA-29992==>*/
      struct {
         char RecsRead[MAXUINT64LEN];
         char RecsSkipped[MAXUINT64LEN];
         char RecsRejected[MAXUINT64LEN];
         char RecsSent[MAXUINT64LEN];
      } PhaseIEnd64 ;
      struct {
         char RecsRead[MAXUINT64LEN];
         char RecsSkipped[MAXUINT64LEN];
         char RecsRejected[MAXUINT64LEN];
         char RecsSent[MAXUINT64LEN];
         UInt32 ImportNo;
      } ImportEnd64 ;       
      struct {
         UInt32 VersionLen;
         char   VersionId[MAXVERSIONIDLEN];
         UInt32 UtilityId;
         UInt32 UtilityNameLen;
         char   UtilityName[MAXUTILITYNAMELEN];
         UInt32 UserNameLen;        
         char   *UserName;
         UInt32 UserStringLen; 
         char   *UserString;
      } InitializeEON;
      struct {
         UInt32 TableNameLen;
         char   *TableName;
         UInt32 TableNo;
         char   *DBaseName;  
      } PhaseIBeginEON;
      struct {
         char RecordCount[MAXUINT64LEN];
      } CheckPoint64;
      struct {
         char Inserts[MAXUINT64LEN];
         char Updates[MAXUINT64LEN];
         char Deletes[MAXUINT64LEN];
         UInt32 TableNo;
      } PhaseIIEnd64;
      struct {
         char Rows[MAXUINT64LEN];
         UInt32 TableNo;
      } ErrorTableI64;
      struct {
         char Rows[MAXUINT64LEN];
         UInt32 TableNo;
      } ErrorTableII64 ;
      struct {
         UInt32 VersionLen;
         char   VersionId[MAXVERSIONIDLEN];
         UInt32 UtilityId;
         UInt32 UtilityNameLen;
         char   UtilityName[MAXUTILITYNAMELEN];
         UInt32 UserNameLen;        
         char   *UserName;
         UInt32 UserStringLen; 
         char   *UserString;
      } DeleteInitEON;
      struct {
         UInt32 TableNameLen;
         char   *TableName;
         UInt32 TableNo;
         char   *DBaseName; 
      } DeleteBeginEON;
      struct {
         char Deletes[MAXUINT64LEN];
         UInt32 TableNo;
      } DeleteEnd64;
/*<==SA-29992*/
   } Vals;
} MLNotifyExitParm;

#ifdef __MVS__                                 /* SA-53076 *//*DR37833*/
#define  MLNfyExit MLNfEx                                    /*DR37833*/
#endif                                                       /*DR37833*/

/*DR 96203 -->*/

#ifdef __MVS__                                     /* SA-53076 */
extern long MLNfyExit(
#else
extern Int32 MLNfyExit(
#endif

/*DR 96203 <--*/

#ifdef __STDC__                                 /*H3_01*/
          MLNotifyExitParm *Parms/* DR147533, SA-29992 */
#endif                                          /*H3_01*/
);

#endif /* MLDNFYXT_H */
