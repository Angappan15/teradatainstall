#ifndef CLIV2IF_H
#define CLIV2IF_H
#define CLIV2IF_H_REV "17.20.00.00"
/*******************************************************************************
 * TITLE:        CLIV2IF.H .. CLIv2 User Exits type                  17.20.00.00
 *                            definitions for "C"
 *
 *  Copyright 1986-2022 by Teradata Corporation.  All rights reserved.
 *
 *  Purpose      To contain the type definitions needed for
 *               interfacing to CLIv2 User Exits from a "C" program.
 *
 *  Description  This include file contains the type
 *               definitions needed for an application program
 *               to make calls to CLIv2.
 *
 *  History
 *    D.1   86Jul28  DRP  Coded
 *    D.2   86Dec03  DAA  DCR3075  To satisfy STV
 *    D.3   87Jan07  DAA  modified for compatibility w/ host
 *    F.1   87Jan07  DAA  DCR3075  compatibility w/ host
 *    F.2   87Mar12  DAA  DR9522   Fix DBFPRQ
 *    F.3   87MAR12  DAA  DR9522   FIX DBFPRQ
 *    F.4   87MAR17  DAA  DR9522   FIX DBFPRQ
 *    F.5   87Jul21  DAA  DCR3780  add options parcel
 *    F.6   87Aug12  DAA  DR10227  mainframe compatibility
 *    F.7   87Oct28  SCT  DR10471  Narrowed to <=65 columns
 *    F.8   87Nov03  DAA  DR11006  Add hostid & fix options
 *                                 order
 *    F.9   88Jan14  DAA  DR11803  Mainframe compatibility
 *    F.10  88Feb05  DAA  DR11944  Avoid duplicate fieldnams
 *    F.11  88Feb18  WHY  DR11926  (MR# fe87-18102a0)
 *    F.12  88Apr15  DAA  DR12068  switch lreq/lrsp
 *    F.13  88Apr18  DAA  DR12068  fix DR number above
 *    G0_00 88Jul25  SN   Created  for Release G.0
 *    G0_01 88Oct06  WBJ  DCR4029  & other G.0 mods
 *    G0_02 88Dec06  HEIDI DR14337 Fix comment
 *    G0_03 89Dec15  KXO  DCR5239  Modified for Param. SQL
 *    G0_04 90Sep05  KBC  DR19675  Cleanup warnings
 *    G0_05 90Sep14  KXO           Revised for UNIX TOOL KIT
 *    G0_06 90Nov13  KBC  DR20832  Add Record_Error
 *    G0_07 90Dec18 HEIDI DR21134  Remove Record_Error (Added to cliv2.c)
 *    G0_08 91Jan05  DJL  DCR5366  Tandem port
 *    G0_09 91Dec01  BGN  DCR6174  First revision for OS/2
 *    G0_10 91Dec31  KBC  DCR5966  Support for Windows WinCLIV2.DLL
 *    H0_00 93May20  SNT  DCR6711  Created for Release H.0
 *    H0_01 94Apr04  JAE  DCR6172  Merged in 2PC code for Genesis II.
 *    H0_02 94May13  JAE  DR29062  Changed ermg to conf
 *    H0_03 94Jun09  km5  DCR6842&5571 User Exit Structures added
 *    H0_04 94Jun29  JAE  DR29062  Added ermg back.
 *    H0_05 95Jan17  BG1  DR30470  Changed dbcnamlen to 9 char.
 *    HN_00 94Aug05  JAE  DCR6848 & DCR6848
 *                                 Added tx_semantics and language
 *                                 conformance options for NDM.
 *                                 Added definition for DBCHQE()
 *    HN_01 95FEB09  ALB  DR32294 Merged 5.0 and AFCAC code.
 *    HN_02 95Mar03  BG1  DR32414  Defined separate parameter for
 *                                 Cli User Exit struct.
 *    HN_03 95Apr04  JAE  DR30470  Removed DR 30470 change above.
 *    H3_00 95Aug23  JAE  DR32294  Completed NDM merge by removing #ifdef NDM.
 *    H3_01 95Sep13  TH4  DR34047  Added the #ifndef XXXX #define XXXX.
 *    H3_02 96Mar08  SYY  DR35631  Merge WinCLI 3.0 changes into mainstream.
 *    H3_03 96Mar21  TH4  DR35631  Merge WinCLI 3.0 changes into mainstream.
 *    04.00.00.01 TH4 96Jul12 DR36785 Version number change.
 *    04.05.00.00 CSG      2000Jan18 DR45724 CLI2 C++ safe.
 *    04.06.02.00 cc151010 2002Apr25 DR61234 Update CLIUsrExit structures.
 *    04.07.01.00 mg180007 2003Mar12 DR67744 Remove HPUX compilation warnings.
 *    04.07.01.01 mg180007 2003Apr24 DR68084 renamed TimeStamp to time_stamp
 *    04.08.00.00 mg180007 2003Jul22 DR68511 clean up defines, prototypes
 *                                   DR68140 fix EXPENTRY definition
 *    04.08.00.01 CSG      2004Jan27 DR84603 Added missing pragma pop
 *    04.08.00.02 mg180007 2004May24 DR84143 included dbcarea.h, removed
 *                                           unused definitions
 *    04.08.00.03 mg180007 2004Jul22 DR87347 CLI User Exits 2
 *    04.08.00.04 bh185000 2004Dec03 DR67971 Support multiport in dbcname
 *    04.08.01.00 mg180007 2005Feb14 DR92232 merge and update copyright year
 *    04.08.01.01 mg180007 2005Apr21 DR93472 added header revision info
 *    13.00.00.00 mg180007 2008Jan09 DR117140 copyright update
 *    13.00.00.01 mg180007 2008Feb27 DR112838 explicit load of user exits
 *    13.01.00.00 mg180007 2009Mar01 DR116309 increase dbcname length
 *    13.10.00.00 kl185018 2009Jun23 DR133468 TTU13.1 Version Renumbering 
 *                                            to TTU13.10
 *    15.10.00.00 hs186016 2015Jan22 CLAC-33167 fix crash with 258 bytes of TDP string
 *    16.00.00.00 hs186016 2017Feb13 CLIWS-6490 Remove compile warning messages
 *    17.00.00.00 hs186016 2018Nov13 CLIWS-7163 version and copyright update
 *    17.20.00.00 hs186016 2022Jan01 CLIWS-8198 version and copyright update
 ******************************************************************************/

/* DR112838 ->                                                         */
/* Since the original user exits do not support object names larger    */
/* than 30 bytes and we have no way of telling whether the user exits  */
/* are being utilized, we are disabling them by default. This will     */
/* allow us to process the logon correctly in CLIv2. The preprocessor  */
/* definitions below this comment allow for enabling custom user exits.*/
/* Enabling the definitions and implementing the appropriate user exit */
/* routines will let CLI load them automatically. Please note:         */
/* - it isn't necessary to have ANY exit level routines implemented    */
/*   and available, but if any routines are implemented, all others    */
/*   within the same level (1 or 2) must also be implemented           */
/* - if CLI2EXITLVL environment variable is set to 1 or 2 and the      */
/*   corresponding functions are not found, CLI will return error      */
/*   TDUSRLOADERR(530).                                                */
/* - if CLI2EXITLVL environment variable is not set, CLI will attempt  */
/*   to load the user exit library and all the symbols. It will give   */
/*   preference to level 2 functions if they are found, otherwise level*/
/*   1 if they're found, and if none are found the exits are disabled  */
/*   (no error is returned).                                           */
/* - if CLI2EXITLVL environment variable is set to a value other than  */
/*   1 or 2, user exits will be disabled.                              */
/*                                                                     */
/* Because of the limits in the level 1 user exit structures, we       */
/* recommend implementing level 2 functions only.                      */
/*                                                                     */
/* At some point in the future we may stop distributing the user       */
/* exit libraries in our packages. We will only provide the source     */
/* code and make files.                                                */
/*                                                                     */
/* When both macros are undefined, an empty library will be built.     */
/* Uncomment one or both of them when the corresponding exit functions */
/* are implemented                                                     */
/*                                                                     */
/* #define CLIEXITLEVEL1 */
/* #define CLIEXITLEVEL2 */
/* <- DR112838 */

/***************************************************************/
/*                                                             */
/*  DBCAREA - INTERFACE BETWEEN DBC/SQL APPLICATION AND CLIV2. */
/*                                                             */
/*  NOTES   -  RI/OI/RO/OO ( REQUIRED/OPTIONAL/INPUT/OUTPUT0   */
/*                                                             */
/***************************************************************/

#include <dbcarea.h> /* DR84143 */

/***************************************************************/
/*                                                             */
/*   The packing of the structures must match wincli32's       */
/*   packing structure of 1 byte.                              */
/*                                                             */
/***************************************************************/
#define       USRNAMLEN        92  /* DR52058 */
#define       PWDNAMLEN        92  /* DR52058 */
#define       DBCNAMLEN        70  /* DR67971, DR116309 */
#define       ACTNAMLEN        94  /* DR52058 */
#define       UEXUSRLEN        32    /* Defined new parameters */
#define       UEXPWDLEN        32    /* for Cli User Exit func.*/
#define       UEXDBCLEN        32    /* DR32414   bg1          */
#define       UEXDBCLEN15      15  /* DR116309 */
#define       UEXACTLEN        34
#define       USREXTLEN       106    /* DCR 5571 bg1  */
#define       DOMAINLEN       262    /* DR61234, CLAC-33167 */

#ifdef WIN32
#pragma pack (push,1)       /* DR84603: corrected pack stmt */
#endif

/**************************************************************/
/* User Exit Structures for Login and Pre&Post Exits          */
/**************************************************************/

struct  CliExit
{
    char    username[UEXUSRLEN];
    char    password[UEXPWDLEN];
    char    dbcname [UEXDBCLEN];
    char    account [UEXACTLEN];
};

/*********************************************************************/
/*                 Structure Declaration  for User Pre&Post SQL      */
/*                 Exit Functions added for DCR 6842                 */
/*********************************************************************/
struct CliPreSQLExit
{
    char    *SQL_Request_ptr;
    char    Start_date[80];
    Int32   Clock_time;
    char    dbcname[UEXDBCLEN15];   /* DR116309 */
    char    username[UEXUSRLEN];    /* DR84143 */
    char    account[UEXACTLEN];     /* DR84143 */
    char    password[UEXPWDLEN];    /* DR84143 */
    char    domain[DOMAINLEN];		/* DR34115 */
    Int32   *SQL_len_ptr;
    Int32   logsessid;              /* DR61234 */
    Int16   Process_Post;
};

struct CliPostSQLExit
{
    char    *SQL_Request_ptr;
    char    Start_date[80];
    Int32   Clock_time;
    char    dbcname[UEXDBCLEN15];   /* DR116309 */
    char    username[UEXUSRLEN];    /* DR84143 */
    char    account[UEXACTLEN];     /* DR84143 */
    char    password[UEXPWDLEN];    /* DR84143 */
    char    domain[DOMAINLEN];		/* DR34115 */
    Int32   *SQL_len_ptr;
    Int32   logsessid;              /* DR61234 */
};

#ifdef WIN32         /* DR84603: Added missing pack(pop) for WIN32 */
#pragma pack(pop)
#endif

/* DR87347 -> */
/***************************************************************/
/* User Exit Structures for Level 2 Login and Pre&Post Exits   */
/***************************************************************/
typedef struct CliExit2_struct
{
    char    *dbcname;
    UInt32   dbcname_actual_len;
    UInt32   dbcname_max_len;     /* = DBCNAMLEN */
    char    *username;
    UInt32   username_actual_len;
    UInt32   username_max_len;    /* = USRNAMLEN */
    char    *password;
    UInt32   password_actual_len;
    UInt32   password_max_len;    /* = PWDNAMLEN */
    char    *account;
    UInt32   account_actual_len;
    UInt32   account_max_len;     /* = ACTNAMLEN */
    char    *domain;
    UInt32   domain_actual_len;
    UInt32   domain_max_len;      /* = DOMAINLEN */
    char    *mechname;
    UInt32   mechname_actual_len;
    UInt32   mechname_max_len;    /* = MECNAMLEN */
    char    *mechdata;
    UInt32   mechdata_actual_len;
    UInt32   mechdata_max_len;    /* = MAX_LOGMECH_DATA_LEN */
    char    *charset;
    UInt32   charset_actual_len;
    UInt32   charset_max_len;     /* = CHARSETSIZ */
} CliExit2_t, *CliExit2_p;

typedef struct CliLgnExit2_struct
{
    char       eye_catcher[4];   /* "LGN "           */
    UInt32     level;            /* 2                */
    CliExit2_t opts;
} CliLgnExit2_t, *CliLgnExit2_p;

typedef struct CliSQLExit2_struct
{
    char       eye_catcher[4];   /* "PRE " or "POST" */
    UInt32     level;            /* 2                */
    char      *SQL_Request_ptr;
    char       Start_date[80];
    UInt32     Clock_time;
    Int32     *SQL_len_ptr;
    UInt32     logsessid;
    UInt16     Process_Post;     /* only applies to pre-SQL exits */
    char       fill_1[2];
    CliExit2_t opts;
} CliSQLExit2_t, *CliSQLExit2_p;
/* <- DR87347 */

#ifdef WIN32
#define DLLEXPORT __declspec(dllexport)
#else
#define DLLEXPORT extern
#endif

#ifdef __cplusplus/* DR45724-> */
extern "C" {
#endif                 /* <-DR45724 */
#ifdef WIN32                /* H3_03 *//* DR68511 */
#ifdef CLIEXITLEVEL1
    DLLEXPORT Int32 CliUsrLgnExt(struct CliExit *);         /* DCR5571 User logon Exit */
    DLLEXPORT Int32 CliPreSQLExt(struct CliPreSQLExit *);
    DLLEXPORT void  CliPostSQLExt(struct CliPostSQLExit *); /* DCR6842&6852 SQL */
#endif /* CLIEXITLEVEL1 */
#ifdef CLIEXITLEVEL2
    DLLEXPORT Int32 CliUsrLgnExt2(CliLgnExit2_p);  /* DR87347 */
    DLLEXPORT Int32 CliPreSQLExt2(CliSQLExit2_p);  /* DR87347 */
    DLLEXPORT void  CliPostSQLExt2(CliSQLExit2_p); /* DR87347 */
#endif /* CLIEXITLEVEL2 */
#endif /* WIN32 */
#ifdef __cplusplus/* DR45724-> */
}
#endif              /* <-DR45724 */

/***************************************************************/
/*                       END of CLIV2IF.H                      */
/***************************************************************/
#endif /* CLIV2IF_H */
