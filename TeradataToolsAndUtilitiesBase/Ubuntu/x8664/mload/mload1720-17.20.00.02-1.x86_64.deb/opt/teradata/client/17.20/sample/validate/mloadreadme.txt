Overview:
  This directory contains a quick start validation tool to validate Teradata
  MultiLoad after installation.

Directory Contents:
  mloadvalidate.bat -- This script is installed on Windows platform. You must
  execute this script from its current installed location.  
  Usage: mloadvalidate [NODEID] [UserName] [UserPassword]
  where: [NODEID] is a database name Id.
         [UserName] is a database User Name.
         [UserPassword] is a database User Password.

  mloadvalidate.ksh -- This script is installed on UNIX platforms. You must
  execute this script from its current installed location.  
  Usage: ./mloadvalidate.ksh [NODEID] [UserName] [UserPassword]
  where: [NODEID] is a database name Id.
         [UserName] is a database User Name.
         [UserPassword] is a database User Password.
