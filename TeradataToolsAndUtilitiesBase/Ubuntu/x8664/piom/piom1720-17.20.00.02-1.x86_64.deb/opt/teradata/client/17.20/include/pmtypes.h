/* % TITLE pmtypes.h ... Access Module user interface header file           */
/****************************************************************************/
/*                                                                          */
/*  Copyright 1997-2015,2018,2020 Teradata Corporation.                     */
/*  ALL RIGHTS RESERVED.                                                    */
/*  Teradata Corporation CONFIDENTIAL AND TRADE SECRET                      */
/*  This copyrighted material is the Confidential, Unpublished              */
/*  Property of the Teradata Corporation.  This copyright notice            */
/*  and any other copyright notices included in machine readable            */
/*  copies must be reproduced on all authorized copies.                     */
/*                                                                          */
/*                                                                          */
/* History Information                                                      */
/*                                                                          */
/*                      JIRA                                                */
/* Revision    Date     ISSUE    DID      Comments                          */
/* ----------- -------- -------- -------- ----------------------------------*/
/* 17.00.00.00 05122020 SA52533  HM186000 Merge/Sync Access Module Header   */
/*                                        Files From TPT DC                 */
/* 16.20.00.00 09142018 SA51031  HM186000 Port PIOM to native 64-bit        */ 
/* 16.00.00.00 07082015	SA43974  hm186000 PIOM support for 1MB Perm Rows    */
/* 15.10.00.00 10222014 SA43327  hm186000 provide api to rtn trace filename */
/* 15.00.00.01 09262013 SA30845  HM186000 Add MF data set access by DSNAME  */
/* 15.00.00.00 09122013 SA31869  HM186000 Provide fldata() info to caller   */
/* 14.00.00.00 03162012 SA11835  HM186000 NULL Padding support on MVS       */
/*                                                                          */
/*                      DR/#                                                */
/* Revision    Date     DCR   DID     Comments                              */
/* ----------- -------- ----- ------- -----------------------               */
/* 13.10.00.03 09022009 135338 TWB    Add function pmTZset()                */
/* 13.10.00.02 06012009 133040 TWB    Set default buffer size               */
/* 13.10.00.01 08272008 115918 TWB    IBM compiler.  Changes                */
/*                                    courtesy ASG & DEH                    */
/* 13.00.00.01 01302008 115882 TWB    Teradata Copyright                    */
/* 02.02.00.00 06242005 94488 CSG     Port to HP-Itanium                    */
/* 02.00.00.04 11142002 65685 TRV     pack 1 avoided for Win 64 platform    */
/* 02.00.00.03 09022002 64540 TRV     Changes for NPAM C++ compilation      */
/* 02.00.00.02 08272002 63707 TWB     Copyright Notice                      */
/* 02.00.00.01 07182002 58762 TRV     HPUX 64-bit Porting                   */
/* 02.00.00.00 03062002 58755 TRV     SOLARIS SPARC 64-bit Porting          */
/* 01.04.00.02 02152001 53279 CSG     Port DATACON to AIX                   */
/* 01.04.00.01 02132001 53280 CSG     Port DATACON to HPUX                  */
/* 01.03.00.02 05102000 50663 TWB     Backout 48782                         */
/* 01.03.00.01 12011999 48782 TWB     Incremented pmInterfaceVersion        */
/* 01.00.02.02 04101998 42617 TWB     API Externalization changes           */
/* 01.00.02.01 04021998 40615 TWB     Mainframe port.                       */
/* 01.00.00.03 02031998 41333 TWB     Add test program identification       */
/* 01.00.00.02 12181997 41064 TWB     Add Empty file error code             */
/* 01.00.00.01 09051997 40490 TWB     Initial version                       */
/*                                                                          */
/****************************************************************************/
/*                                                                          */
/* Note:  Any changes to the value of pmInterfaceVersionD (defined in the   */
/*        support header file pmdcomt.h) require that the value of          */
/*        pmInterfaceVersion be incremented.                                */
/*                                                                          */
/****************************************************************************/

#ifndef PMTYPES_H
#define PMTYPES_H

#ifdef WIN32
#include <windows.h>
#ifdef _PIOMAPI_
#define OBJ_EXT_PIOMAPI __declspec(dllexport)
#else
#define OBJ_EXT_PIOMAPI __declspec(dllimport)
#endif
#else
#define OBJ_EXT_PIOMAPI
#endif

#include <stdio.h>
#include "pmdcomt.h"

/* DR 58755, DR 58762 --> */

#if defined(SOLARIS) && defined(PIOM64)
   #pragma pack(8)
#elif defined(__MVS__)                                             /* 115918 */
   #pragma pack(packed)                                               /* 115918 */
#elif defined(_WIN64)                                          /* SA-51031 */
   #pragma pack (push, 1)                                         /* SA-51031 */
#elif !defined(AIX) && !defined(SOLARIS) \
   && !defined(_WIN64) /* DR 53279, DR 53280 DR 65685 */
   #pragma pack (push, 1)
#endif

/* DR 58755, DR 58762 <-- */

#define pmInterfaceVersion  2               /* Increment for each release */

typedef pmUInt32 pmFormat_t;  /* Access Module data format type */
typedef pmUInt32 pmHandle_t;  /* Access Module token */
typedef pmUInt32 pmFp_t;      /* File pointer token */
typedef pmUInt32 pmDDInfo_t;  /* Indeterminate, device       */
                              /* dependent structure         */
typedef pmUInt32 pmSeq_t;
typedef int      pmChkPt_t;   /* Checkpoint mode type */
 
/* Performance statistics structure */
typedef struct _pmStatBuf
{
  int dummy;    /* Stat fields not yet determined */
} pmStatBuf_t;
 
/* I/O buffer structure (Data area dynamically maintained) */
typedef struct _pmRWBuf
{
  pmUInt32  DataLength;
  char     *Data;
  pmUInt16  DSICFlag;   /* Device Specific Information Change Flag */
  pmSeq_t   Sequence;   /* Record sequence number */
} pmRWBuf_t;
 
/* Access Module initialization structure - used only by pmInit */
typedef struct _pmInit
{
  pmTrceLvl_t   pmTraceLevel;   /* Default trace level        */
  char         *UtilityID;      /* Calling utility identifier */
  pmUInt16      InterfaceVerNo; /* Set to pmInterfaceVersion  */
} pmInit_t;
 
/* Access Module open/initialization structure - used only by pmAttach */
typedef struct _pmAttach
{
  pmNameBuf_t  AccessModName;    /* Name of Access Module to connect */
  pmNameBuf_t  AccessModInitStr; /* Initialization string */
} pmAttach_t;

/* List of valid client utilities */
#define pmUtlIDARC          1   /* ARC */
#define pmUtlIDARC_s        "Archive/Recovery"    
#define pmUtlIDASF2         2   /* ASF2 */
#define pmUtlIDASF2_s       "ASF2"
#define pmUtlIDMLoad        3   /* MultiLoad */
#define pmUtlIDMLoad_s      "MultiLoad"
#define pmUtlIDFastLoad     4   /* FastLoad */
#define pmUtlIDFastLoad_s   "FastLoad"
#define pmUtlIDFastExport   5   /* FastExport */
#define pmUtlIDFastExport_s "FastExport"
#define pmUtlIDTPump        6   /* Teradata Pump */
#define pmUtlIDTPump_s      "TeradataPump"
#define pmUtlIDAXMTest      7   /* piomtest program */
#define pmUtlIDAXMTest_s    "AXSMOD test"
#define pmUtlID_MAX         7

/* pmIDFCodes:  Internal Data Format Codes */
#define pmIDFtext          1
#define pmIDFBin1          2
#define pmIDFBin1Plus      3
#define pmIDFBin2          4
#define pmIDFBin2Plus      5
#define pmIDFnone          6
#define pmIDLROWFBin1      7                           /* SA43974 */
#define pmIDLROWFBin1Plus  8                           /* SA43974 */
#define pmIDLROWFBin2      9                           /* SA43974 */
#define pmIDLROWFBin2Plus  10                          /* SA43974 */
#define pmIDF_MAX          10                          /* SA43974 */

/* Trace scope indicators */
#define pmTrceScopeAll     1
#define pmTrceScopeAXM     2
#define pmTrceScopeFile    3
#define pmTrceScope_MAX    4
 
/* Get position parameters (calls to pmGetPos) */
#define pmPosNormal    0
#define pmPosImDone    1  /* implies arbitrary EOF */

/* Checkpointing modes */
#define pmChkPtExact      1
#define pmChkPtFlush      2

/**************************************************************************/
/*                                                   pmprocs.c prototypes */
/**************************************************************************/
/* #ifdef I370
#define pmprocsVersion PMPRCVER
#define pmDDInfo       PMDDI
#define pmGetPos       PMGETP
#define pmAttach       PMATCH
#define pmDetach       PMDTCH
#define pmTraceMsg     PMTRCMSG
#define pmShutDown     PMSHTDWN
#define pmGetErrText   PMGTETXT
#define pmGetStats     PMGTSTAT
#define pmHexDmp       PMHD
#define pmAGetAttr     PMAGETA
#define pmAPutAttr     PMAPUTA
#define pmFGetAttr     PMFGETA
#define pmFPutAttr     PMFPUTA
#endif */

#ifdef __cplusplus  /* CPP */
extern "C" {
#endif

#if defined(__MVS__)                                               /* 135338 */
OBJ_EXT_PIOMAPI extern pmReturnType pmTZset();                     /* 135338 */
OBJ_EXT_PIOMAPI pmReturnType pmSetPadMode(pmFp_t,pmUInt16);      /* SA-11835 */
OBJ_EXT_PIOMAPI extern pmReturnType pmGetFileInfo(pmFp_t ,fldata_t *); /* SA-31869 */
#endif                                                             /* 135338 */
 
OBJ_EXT_PIOMAPI extern char pmprocsVersion[];
OBJ_EXT_PIOMAPI extern pmReturnType pmInit
              ( pmInit_t * );
OBJ_EXT_PIOMAPI extern pmReturnType pmAttach
              ( pmAttach_t *, pmChkPt_t, pmHandle_t * );
OBJ_EXT_PIOMAPI extern pmReturnType pmSetBufferSize                /* 133040 */
              ( pmUInt32 BufferSize );                             /* 133040 */
OBJ_EXT_PIOMAPI extern pmReturnType pmOpen
              ( pmOpenMode_t, pmFormat_t, char *, char *,
                pmHandle_t, pmFp_t *);
OBJ_EXT_PIOMAPI extern pmReturnType pmClose
              ( pmFp_t );
OBJ_EXT_PIOMAPI extern pmReturnType pmCloseR
              ( pmFp_t );
OBJ_EXT_PIOMAPI extern pmReturnType pmRead
              ( pmFp_t, pmRWBuf_t *);
OBJ_EXT_PIOMAPI extern pmReturnType pmDDInfo
              ( pmFp_t, pmDDInfo_t *);
OBJ_EXT_PIOMAPI extern pmReturnType pmWrite
              ( pmFp_t, pmRWBuf_t *);
OBJ_EXT_PIOMAPI extern pmReturnType pmFlush
              ( pmFp_t );
OBJ_EXT_PIOMAPI extern pmReturnType pmGetPos
              ( pmFp_t, pmUInt16, pmPos_t *);
OBJ_EXT_PIOMAPI extern pmReturnType pmRepos
              ( pmFp_t, pmPos_t * );
OBJ_EXT_PIOMAPI extern pmReturnType pmTrace
              ( pmUInt16, void *, pmTrceLvl_t );
OBJ_EXT_PIOMAPI extern pmReturnType pmTraceMsg
              ( pmTrceLvl_t, char* );
OBJ_EXT_PIOMAPI extern pmReturnType pmDetach
              ( pmHandle_t, pmUInt16 );
OBJ_EXT_PIOMAPI extern pmReturnType pmShutDown
              ( pmUInt16 );
OBJ_EXT_PIOMAPI extern pmReturnType pmGetErrText
              ( pmReturnType, pmNameBuf_t * );
OBJ_EXT_PIOMAPI extern pmReturnType pmGetID
              ( pmHandle_t, pmVerLst_t ** );
OBJ_EXT_PIOMAPI extern pmReturnType pmAGetAttr
              ( pmHandle_t, pmNameBuf_t, pmNameBuf_t* );
OBJ_EXT_PIOMAPI extern pmReturnType pmAPutAttr
              ( pmHandle_t, pmNameBuf_t, pmNameBuf_t );
OBJ_EXT_PIOMAPI extern pmReturnType pmFPutAttr
              ( pmFp_t, pmNameBuf_t, pmNameBuf_t );
OBJ_EXT_PIOMAPI extern pmReturnType pmFGetAttr
              ( pmFp_t, pmNameBuf_t, pmNameBuf_t * );
OBJ_EXT_PIOMAPI extern pmReturnType pmGetStats
              ( pmHandle_t, pmStatBuf_t * );
OBJ_EXT_PIOMAPI extern pmReturnType pmDiag
              ( int, void  * );
OBJ_EXT_PIOMAPI extern void         pmHexDmp
              ( FILE *, char* , unsigned , char*, int );
/* SA-31869 --------------> */
#ifdef WIN32
OBJ_EXT_PIOMAPI extern DWORD pmGetFileType( pmFp_t );
#endif
/* SA-31869 <-------------- */
/* SA-43327 ---->            */
#ifndef __MVS__
OBJ_EXT_PIOMAPI extern const char * pmTraceFileName();
#endif
/* SA-43327 <----            */

/* DR 58755, 58762 --> */

#ifdef __cplusplus  /* end CPP */
}
#endif

#if defined(SOLARIS) && defined(PIOM64)
   #pragma pack()
#elif defined(__MVS__)                                             /* 115918 */
   #pragma pack(reset)                                                /* 115918 */
#elif defined(_WIN64)                                            /* SA-51031 */
   #pragma pack (pop)                                               /* SA-51031 */
#elif !defined(AIX) && !defined(SOLARIS) \
   && !defined(_WIN64)     /* DR 53279, DR 53280 DR 65685 */
   #pragma pack (pop)
#endif

/* DR 58755, 58762 <-- */

#endif /* PMTYPES_H */
