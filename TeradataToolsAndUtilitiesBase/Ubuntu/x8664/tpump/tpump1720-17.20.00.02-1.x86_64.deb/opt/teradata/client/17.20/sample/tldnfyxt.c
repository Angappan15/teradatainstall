/**************************************************************************
*                                                                         *
* tldnfyxt.c   - Sample Notify Exit for TPump.                            *
*                                                                         *
* Copyright 1997-2013 Teradata Corporation.                               *
* ALL RIGHTS RESERVED.                                                    *
* Teradata Corporation CONFIDENTIAL AND TRADE SECRET                      *
*                                                                         *
* This copyrighted material is the Confidential, Unpublished              *
* Property of the Teradata Corporation.  This copyright notice and        *
* any other copyright notices included in machine readable                *
* copies must be reproduced on all authorized copies.                     *
*                                                                         *
*                                                                         *
* Purpose    - This is a sample notify exit for TPump.                    *
*                                                                         *
* Execute    - Build Notify on a Unix system                              *
*                compile and link into shared object                      *
*                    cc -G    tldnfyxt.c - o libtldnfyxt.so               *
*            - Build Notify on a Win32 system                             *
*                compile and link into dynamic link library               *
*                    cl /DWIN32 /LD    tldnfyxt.c                         *
*            - Build Notify on AIX system                                 *
*               cc -c -brtl -qalign=packed tldnfyxt.c                     *
*               ld -G -e_dynamn -bE:export_dynamn.txt tldnfyxt.o          *
*                     -o libtldnfyxt.so -lm -lc                           *
*               where export_dynamn.txt conaints the symbol "_dynamn"     * 
*            - Build Notify on Linux system                               *
*               gcc -shared -fPIC tldnfyxt.c -o libtldnfyxt.so            *
*                                                                         *
* History Information                                                     *
*                                                                         *
* Revision    Date     Issue    DID      Comments                         *
* ----------- -------- -------- -------- -------------------------------- *
* 16.00.00.00 06/03/16 SA-47292 CD185012 Change from long to int          *
* 15.00.00.00 03/06/13 SA-29984 YY151001 Add EXITEON                      *
* 14.10.00.01 09/12/12 SA-27869 YY151001 Make change to UserName,         *
*                                        UserString                       *
* 14.10.00.00 07/02/12 SA-2762  YY151001 NOTIFY EXIT64 support            *
*                                                                         *
* Revision    Date     DR     DID      Comments                           *
* ----------- -------- ------ -------- ---------------------------------- *
* 13.10.00.02 07/08/10 143786 SS185133 Back out DR139961                  *
* 13.10.00.01 02/26/10 139961 SS185133 Coverity: Fix errors for TPump     *
* 13.01.00.00 09/03/08 115929 YY151    SAS/C to IBM/C migration           *
* 13.00.00.00 09012007 100764 SV185048 Visual Studio 8.0 build            *
* 02.01.00.01 10/05/05 96204  CSG       Port to HP-UX on Itanium          *
* 02.00.00.02 06/08/04 84784  WH151001 Backout Teradata Branding          *
* 02.00.00.01 03/10/04 68940  CSG      TPump Porting to Linux 32-bit- @006*
* 02.00.00.00 12/17/03 84784  WH151001 Teradata Branding            - @005*
* 01.07.00.01 12/26/02 66745  WH151001 Notify Exit DMLError         - @004*
* 01.07.00.00 09032002 52912  WH151001 Notify Exit Ultra            - @003*
* 01.05.00.00 01242002 59796  TKU      Change %d to %u for UInt32   - @002*
*                                      values that are user viewable and  *
*                                      modify similar variable types      *
*                                      from type long to unsigned long    *
* 01.04.00.01 10242001 58553  CSG      Tpump Notify Coredumps on AIX      *
* 01.04.00.00 05292001 55986  CFL      Max record length of 80      - @001*
* 01.03.01.01 08142000 51679  CSG      File open Event added              *
* 01.03.01.00 07142000 51727  CSG      Add some more Events               *
* 01.02.00.00 06121999 42578  CSG      Update NOTIFY EXIT interface       *
**************************************************************************/
#ifdef __MVS__                                              /*DR115929==>*/
#pragma pack(1)
#endif                                                      /*DR115929<==*/

#include <stdio.h>
typedef unsigned int UInt32;
typedef int Int32;                                              /*DR96204*/
#define NOTIFYID_FASTLOAD      1
#define NOTIFYID_MULTILOAD     2
#define NOTIFYID_FASTEXPORT    3
#define NOTIFYID_BTEQ          4
#define NOTIFYID_TPUMP         5

#define MAXVERSIONIDLEN    32
#define MAXUTILITYNAMELEN  36                                      /*@001*/
#define MAXUINT64LEN       24                                   /*SA-2762*/
#define MAXUSERNAMELEN     64                                  /*SA-29984*/
#define MAXUSERSTRLEN      80                                  /*SA-29984*/
#define MAXFILENAMELEN    256

typedef enum {
    NMEventInitialize    = 0, /* DR51679 Event Name should be consistent */
    NMEventFileInmodOpen = 1,
    NMEventCkptBeg       = 2,
    NMEventImportBegin   = 3, /* DR51679 Event Name should be consistent */
    NMEventImportEnd     = 4, /* DR51679 Event Name should be consistent */
    NMEventErrorTable    = 5, /* DR51679 Event Name should be consistent */
    NMEventDBSRestart    = 6,
    NMEventCLIError      = 7,
    NMEventDBSError      = 8,
    NMEventExit          = 9,
    NMEventTableStats    = 10,
    NMEventCkptEnd       = 11,                                     /*@001*/
    NMEventRunStats      = 12,                             /*@003*//*@004*/
    NMEventDMLError      = 13,                                  /*SA-2762*/
    NMEventCkptBeg64     = 14,                                  /*SA-2762*/
    NMEventCkptEnd64     = 15,                                  /*SA-2762*/
    NMEventImportEnd64   = 16,                                  /*SA-2762*/
    NMEventErrorTable64  = 17,                                  /*SA-2762*/
    NMEventTableStats64  = 18,                                  /*SA-2762*/
    NMEventRunStats64    = 19,                                  /*SA-2762*/
    NMEventDMLError64    = 20,                                  /*SA-2762*/
    NMEventInitializeEON = 21                                  /*SA-29984*/
    } NfyTLDEvent;

#define TIDUPROW 2816                                              /*@004*/
typedef enum {                                                     /*@004*/
    DEFeedbackDefault   = 0,                                       /*@004*/
    DEFeedbackNoLogging = 1                                        /*@004*/
    } DMLErrorFeedbackType;                                        /*@004*/

typedef struct _TLNotifyExitParm {
    UInt32 Event;             /* should be NfyFLDEvent values *//*DR96204*/
    union {
        struct {
           int VersionLen;
           char   VersionId[MAXVERSIONIDLEN];
           int    UtilityId;
           int    UtilityNameLen;
           char   UtilityName[MAXUTILITYNAMELEN];
           int    UserNameLen;
           char   UserName[MAXUSERNAMELEN];                     /*SA-29984*/
           int    UserStringLen;
           char   UserString[MAXUSERSTRLEN];                    /*SA-29984*/
           } Initialize;
        struct {                                             /*SA-29984==>*/
           int VersionLen;
           char   VersionId[MAXVERSIONIDLEN];
           int    UtilityId;
           int    UtilityNameLen;
           char   UtilityName[MAXUTILITYNAMELEN];
           int    UserNameLen;
           char   *UserName; 
           int    UserStringLen;
           char   *UserString;
           } InitializeEON;                                  /*<==SA-29984*/
        struct {
            int  nImport;
            } ImpStart;
        struct {             /*DR51679 added communication data structure*/
            UInt32  FileNameLen;                  /* for file open event */
            char FileOrInmodName[MAXFILENAMELEN];
            UInt32 nImport;
            } FileOpen ;
        struct {
            UInt32 Records;                                     /*DR96204*/
            } CheckPt;
        struct {
            char *TableName;
            UInt32 Rows;                                        /*DR96204*/
            } ETDrop ;
        struct {
            Int32 ReturnCode;                                   /*DR96204*/
            } Exit;
        struct {
            int nImport;
            UInt32 RecsIn;                                   /*DR96204==>*/ 
            UInt32 RecsSkipped;
            UInt32 RecsRejd;  
            UInt32 RecsOut;  
            UInt32 RecsError;                                /*<==DR96204*/
            } Complete;
        struct {
            char type;
            char *dbasename;
            char *szName;
            UInt32 Activity;                                    /*DR96204*/
            } TableStats;
        struct {
            UInt32 ErrorCode;             /*DR51679 changed int to UInt32*/
            } DBSError;
        struct {                      /*DR51679 Unused structures removed*/
         UInt32 ErrorCode;
            } CLIError;
        struct {                                                   /*@003*/
            int nImport;                                           /*@003*/
            UInt32 nSQLstmt;                                 /*DR96204==>*/      
            UInt32 nReqSent; 
            UInt32 RecsIn;  
            UInt32 RecsSkipped; 
            UInt32 RecsRejd;   
            UInt32 RecsOut;   
            UInt32 RecsError;                                /*<==DR96204*/
            } Stats;                                               /*@003*/
        struct {                                                   /*@004*/
            UInt32 nImport;                                        /*@004*/
            UInt32 ErrorCode;                                      /*@004*/
            char *ErrorMsg;                                        /*@004*/
            UInt32 nRecord;                                        /*@004*/
            unsigned char nApplySeq;                               /*@004*/
            unsigned char nDMLSeq;                                 /*@004*/
            unsigned char nSMTSeq;                                 /*@004*/
            char *ErrorData;       /* error data                     @004*/
            UInt32 ErrorDataLen;   /* length of error data body      @004*/
            UInt32 *feedback;      /* the feedback from user exit    @004*/
            } DMLError;                                            /*@004*/
/*SA-2762==>*/
        struct {                                           
            char Records[MAXUINT64LEN]; 
            } CheckPt64;  
        struct {  
	        UInt32 nImport; 
            UInt32 ErrorCode; 
            char *ErrorMsg;  
            char nRecord[MAXUINT64LEN];  
            unsigned char nApplySeq; 
            unsigned char nDMLSeq;
            unsigned char nSMTSeq;
            char *ErrorData;
            UInt32 ErrorDataLen; 
            UInt32 *feedback; 
            } DMLError64; 
        struct {   
            char *TableName; 
            char Rows[MAXUINT64LEN]; 
            } ETDrop64 ; 
        struct { 
            int nImport;  
            char RecsIn[MAXUINT64LEN];  
            char RecsSkipped[MAXUINT64LEN]; 
            char RecsRejd[MAXUINT64LEN]; 
            char RecsOut[MAXUINT64LEN];  
            char RecsError[MAXUINT64LEN]; 
            } Complete64; 
        struct { 
            char type;  
            char *dbasename;  
            char *szName;    
            char Activity[MAXUINT64LEN];
            } TableStats64;
        struct {         
            int nImport; 
            UInt32 nSQLstmt;  
            UInt32 nReqSent; 
            char RecsIn[MAXUINT64LEN];  
            char RecsSkipped[MAXUINT64LEN];  
            char RecsRejd[MAXUINT64LEN];
            char RecsOut[MAXUINT64LEN];  
            char RecsError[MAXUINT64LEN];
            } Stats64;  
/*<==SA-2762*/
        } Vals;
    } TLNotifyExitParm;

#ifdef I370
#define  TLNfyExit MLNfEx
#endif
  
extern Int32 TLNfyExit(                                        /*DR96204*/
#ifdef __STDC__
                      TLNotifyExitParm *Parms
#endif
);

#ifdef WIN32                                          /*Change for WIN32*/
__declspec(dllexport) int _dynamn(TLNotifyExitParm *P)
#else
Int32 _dynamn(P)                                               /*DR96204*/
TLNotifyExitParm *P;
#endif

{
    FILE *fp;
    int i;                                                        /*@004*/
    if (!(fp = fopen("NFYEXIT.OUT", "a")))
        return(1);
    switch(P->Event) {
    case NMEventInitialize :                                   /*Nothing*/
        fprintf(fp, "exit called @ Tpump init.\n");
        fprintf(fp, "Version: %s\n", P->Vals.Initialize.VersionId);
#ifdef  __MVS__                                               /*DR115929*/
   P->Vals.Initialize.UtilityName[MAXUTILITYNAMELEN-1] = '\0';/*DR115929*/
#else                                                         /*DR115929*/
        P->Vals.Initialize.UtilityName[MAXUTILITYNAMELEN] = '\0';
#endif                                                        /*DR115929*/
        fprintf(fp, "Utility: %s\n", P->Vals.Initialize.UtilityName);
        fprintf(fp, "User: %s\n", P->Vals.Initialize.UserName);
        if (P->Vals.Initialize.UserStringLen)
           fprintf(fp, "UserString: %s\n", P->Vals.Initialize.UserString);
        break;
/*SA-29984==>*/
    case NMEventInitializeEON : 
        fprintf(fp, "exit called @ Tpump init.\n");
        fprintf(fp, "Version: %s\n", P->Vals.InitializeEON.VersionId);
#ifdef  __MVS__                                  
        P->Vals.InitializeEON.UtilityName[MAXUTILITYNAMELEN-1] = '\0';
#else                               
        P->Vals.InitializeEON.UtilityName[MAXUTILITYNAMELEN] = '\0';
#endif                       
        fprintf(fp, "Utility: %s\n", P->Vals.InitializeEON.UtilityName);
        fprintf(fp, "User: %s\n", P->Vals.InitializeEON.UserName);
        if (P->Vals.InitializeEON.UserStringLen)
           fprintf(fp, "UserString: %s\n", P->Vals.InitializeEON.UserString);
        break;
/*<==SA-29984*/
    case NMEventFileInmodOpen :           /*DR51679 File Open Event added*/
        fprintf(fp, "Exit called @ File/Inmod Open\n\
File/Inmod Name  : %s  Import : %d\n",
                P->Vals.FileOpen.FileOrInmodName,P->Vals.FileOpen.nImport);
        break;

    case NMEventCkptBeg :
        fprintf(fp,"exit called @ checkpoint begin : %u Records .\n",
                P->Vals.CheckPt.Records);                          /*@002*/
        break;
/*SA-2762==>*/
    case NMEventCkptBeg64 :                                     
        fprintf(fp,"exit called @ checkpoint begin : %s Records .\n",
                P->Vals.CheckPt64.Records);
        break; 
/*<==SA-2762*/

	case NMEventCkptEnd :
        fprintf(fp,"exit called @ checkpoint End :   %u Records Sent.\n",
                P->Vals.CheckPt.Records);                          /*@002*/
        break;

/*SA-2762==>*/
	case NMEventCkptEnd64 :
        fprintf(fp,"exit called @ checkpoint End :   %s Records Sent.\n",
                P->Vals.CheckPt64.Records); 
        break;
/*<==SA-2762*/

	case NMEventCLIError :
        fprintf(fp, "exit called @ CLI error %d\n",
                P->Vals.CLIError.ErrorCode);
        break;

    case NMEventErrorTable :                                       /*@001*/
            fprintf(fp,"exit called @ ErrTable Drop :    "         /*@001*/
                 "%u logable records.\n",                  /*@002*//*@004*/
                 P->Vals.ETDrop.Rows);
        break;

/*SA-2762==>*/
    case NMEventErrorTable64 : 
            fprintf(fp,"exit called @ ErrTable Drop :    " 
                 "%s logable records.\n", 
                 P->Vals.ETDrop64.Rows); 
        break;
/*<==SA-2762*/

    case NMEventDBSError :
        fprintf(fp, "exit called @ DBS error %d\n",
                P->Vals.DBSError.ErrorCode);
        break;

    case NMEventImportBegin:    /*DR51679 event name should be consistent*/
            fprintf(fp, "exit called @ import %d  starting. \n",
                 P->Vals.ImpStart.nImport);
            break;

    case NMEventImportEnd :     /*DR51679 event name should be consistent*/
            fprintf(fp, "exit called @ import %d   ending   \n",
            P->Vals.Complete.nImport);
            fprintf(fp,                                            /*@001*/
                "Total Records Read: %u \nRecords Skipped    "     /*@002*/
                "%u \nUnreadable Records:%u \nRecords Sent:       "/*@002*/
                "%u \nData Errors :       %u \n",                  /*@002*/
                P->Vals.Complete.RecsIn,
                P->Vals.Complete.RecsSkipped,
                P->Vals.Complete.RecsRejd,
                P->Vals.Complete.RecsOut,
                P->Vals.Complete.RecsError);
        break;

/*SA-2762==>*/
    case NMEventImportEnd64 : 
            fprintf(fp, "exit called @ import %d   ending   \n",
            P->Vals.Complete64.nImport);
            fprintf(fp,                                    
                "Total Records Read: %s \n",
                 P->Vals.Complete64.RecsIn);
            fprintf(fp,                                    
                "Records Skipped: %s \n",
                 P->Vals.Complete64.RecsSkipped);
            fprintf(fp,                                    
                "Unreadable Records: %s \n",
                 P->Vals.Complete64.RecsRejd);
            fprintf(fp,                                    
                "Records Sent: %s \n",
                 P->Vals.Complete64.RecsOut);
            fprintf(fp,                                    
                "Data Errors: %s \n",
                 P->Vals.Complete64.RecsError);
        break; 
/*<==SA-2762*/

    case NMEventDBSRestart :
        fprintf(fp, "exit called @ RDBMS restarted\n");
        break;

    case NMEventExit :
           fprintf(fp, "exit called @ tpump notify out of scope:"  /*@001*/
                " return code %d.\n",                              /*@001*/
                P->Vals.Exit.ReturnCode);
        break;

    case NMEventTableStats:
           fprintf(fp,"exit called @ Table Stats: \n");
           if(P->Vals.TableStats.type == 'I')
            fprintf(fp,"Rows Inserted    :      "                 /*@001*/
                "%u \nTable/Macro Name :  %s \nDatabase Name"     /*@002*/
                "    :    %s \n",                                 /*@001*/
                P->Vals.TableStats.Activity,
                P->Vals.TableStats.szName,
                P->Vals.TableStats.dbasename);
           if(P->Vals.TableStats.type == 'U')
                fprintf(fp,"Rows Updated     :      "             /*@001*/
                "%u \nTable/Macro Name :  %s \nDatabase Name"     /*@002*/
                "    :   %s \n",                                  /*@001*/
                P->Vals.TableStats.Activity,
                P->Vals.TableStats.szName,
                P->Vals.TableStats.dbasename);
                if(P->Vals.TableStats.type == 'D')
                fprintf(fp,"Rows Deleted     :     "              /*@001*/
                "%u \nTable/Macro Name :   %s \nDatabase Name"    /*@002*/
                "    :  %s \n",                                   /*@001*/
                P->Vals.TableStats.Activity,
                P->Vals.TableStats.szName,
                P->Vals.TableStats.dbasename);
        break;

/*SA-2762==>*/
    case NMEventTableStats64:     
           fprintf(fp,"exit called @ Table Stats: \n");
           if(P->Vals.TableStats64.type == 'I')
            fprintf(fp,"Rows Inserted    :      "  
                "%s \nTable/Macro Name :  %s \nDatabase Name" 
                "    :    %s \n",          
                P->Vals.TableStats64.Activity,
                P->Vals.TableStats64.szName,
                P->Vals.TableStats64.dbasename);
           if(P->Vals.TableStats64.type == 'U')
                fprintf(fp,"Rows Updated     :      " 
                "%s \nTable/Macro Name :  %s \nDatabase Name"
                "    :   %s \n", 
                P->Vals.TableStats64.Activity,
                P->Vals.TableStats64.szName,
                P->Vals.TableStats64.dbasename);
                if(P->Vals.TableStats64.type == 'D')
                fprintf(fp,"Rows Deleted     :     " 
                "%s \nTable/Macro Name :   %s \nDatabase Name"
                "    :  %s \n", 
                P->Vals.TableStats64.Activity,
                P->Vals.TableStats64.szName,
                P->Vals.TableStats64.dbasename);
        break;
/*<==SA-2762*/

    case NMEventRunStats :                                         /*@003*/
            fprintf(fp, "exit called @ states\n");                 /*@003*/
            fprintf(fp, "import %d \n",                            /*@003*/
                P->Vals.Stats.nImport);                            /*@003*/
            fprintf(fp,                                            /*@003*/
                "Total SQL Statements: %u \nRequest Sent: %u \n"   /*@003*/    
                "Records Read: %u \nRecords Skipped: %u \n"        /*@003*/
                "nUnreadable Records: %u \nRecords Sent: %u \n"    /*@003*/
                "Data Errors : %u \n",                             /*@003*/
                P->Vals.Stats.nSQLstmt,                            /*@003*/
                P->Vals.Stats.nReqSent,                            /*@003*/
                P->Vals.Stats.RecsIn,                              /*@003*/
                P->Vals.Stats.RecsSkipped,                         /*@003*/
                P->Vals.Stats.RecsRejd,                            /*@003*/
                P->Vals.Stats.RecsOut,                             /*@003*/
                P->Vals.Stats.RecsError);                          /*@003*/
        break;                                                     /*@003*/

/*SA-2762==>*/
    case NMEventRunStats64 :  
            fprintf(fp, "exit called @ states\n"); 
            fprintf(fp, "import %d \n",
                P->Vals.Stats64.nImport); 
            fprintf(fp,                                    
                "Total SQL Statements: %d \n",
                P->Vals.Stats64.nSQLstmt);
            fprintf(fp,                                    
                "Request Sent: %d \n",
                P->Vals.Stats64.nReqSent);
            fprintf(fp,                                    
                "Records Read: %s \n",
                P->Vals.Stats64.RecsIn);
            fprintf(fp,                                    
                "Records Skipped: %s \n",
                P->Vals.Stats64.RecsSkipped);
            fprintf(fp,                                    
                "Unreadable Records: %s \n",
                P->Vals.Stats64.RecsRejd);
            fprintf(fp,                                    
                "Records Sent: %s \n",
                P->Vals.Stats64.RecsOut);
            fprintf(fp,                                    
                "Data Errors: %s \n",
                P->Vals.Stats64.RecsError);
        break; 
/*<==SA-2762*/

    case NMEventDMLError :                                         /*@004*/
            fprintf(fp, "exit called @ DML error \n");             /*@004*/
            fprintf(fp, "import %d \n",                            /*@004*/
            P->Vals.DMLError.nImport);                             /*@004*/
            fprintf(fp,                                            /*@004*/
                "Error code: %u \nError text: %s \n"               /*@004*/    
                "Record number: %u \nApply number: %d \n"          /*@004*/
                "DML number: %d \nStatement number: %d \n"         /*@004*/
                "Error data length : %u \n"                        /*@004*/
                "feedback : %u \n",                                /*@004*/
                P->Vals.DMLError.ErrorCode,                        /*@004*/
                P->Vals.DMLError.ErrorMsg,                         /*@004*/
                P->Vals.DMLError.nRecord,                          /*@004*/
                P->Vals.DMLError.nApplySeq,                        /*@004*/
                P->Vals.DMLError.nDMLSeq,                          /*@004*/
                P->Vals.DMLError.nSMTSeq,                          /*@004*/
                P->Vals.DMLError.ErrorDataLen,                     /*@004*/
                *(P->Vals.DMLError.feedback));                     /*@004*/
            fprintf(fp, "Error data: ");                           /*@004*/
            for (i=0 ;i<P->Vals.DMLError.ErrorDataLen; i++) {      /*@004*/
                fprintf(fp, "%c", P->Vals.DMLError.ErrorData[i]);  /*@004*/
            }                                                      /*@004*/
            fprintf(fp, "\n");                                     /*@004*/
            if (P->Vals.DMLError.ErrorCode == TIDUPROW) {          /*@004*/
               *(P->Vals.DMLError.feedback) = DEFeedbackNoLogging; /*@004*/ 
               fprintf(fp, "Returning feedback = %u \n",           /*@004*/
                                        DEFeedbackNoLogging);      /*@004*/   
            }                                                      /*@004*/
        break;                                                     /*@004*/

/*SA-2762==>*/
    case NMEventDMLError64 : 
            fprintf(fp, "exit called @ DML error \n");
            fprintf(fp, "import %d \n", 
            P->Vals.DMLError64.nImport);  
            fprintf(fp,                            
                "Error code: %u \nError text: %s \n"      
                "Record number: %s \nApply number: %d \n" 
                "DML number: %d \nStatement number: %d \n"
                "Error data length : %u \n"    
                "feedback : %u \n",         
                P->Vals.DMLError64.ErrorCode, 
                P->Vals.DMLError64.ErrorMsg,  
                P->Vals.DMLError64.nRecord,   
                P->Vals.DMLError64.nApplySeq, 
                P->Vals.DMLError64.nDMLSeq,   
                P->Vals.DMLError64.nSMTSeq,  
                P->Vals.DMLError64.ErrorDataLen, 
                *(P->Vals.DMLError64.feedback));  
            fprintf(fp, "Error data: ");
            for (i=0 ;i<P->Vals.DMLError64.ErrorDataLen; i++) {
                fprintf(fp, "%c", P->Vals.DMLError64.ErrorData[i]);
            }                    
            fprintf(fp, "\n");     
            if (P->Vals.DMLError64.ErrorCode == TIDUPROW) {  
               *(P->Vals.DMLError64.feedback) = DEFeedbackNoLogging;  
               fprintf(fp, "Returning feedback = %u \n",
                                        DEFeedbackNoLogging);   
            }  
        break; 
/*<==SA-2762*/

    default :
        fprintf(fp,"\nAn Invalid Event Passed to the Exit Routine\n");
        break;

    }
    fclose(fp);
    return(0);
}
