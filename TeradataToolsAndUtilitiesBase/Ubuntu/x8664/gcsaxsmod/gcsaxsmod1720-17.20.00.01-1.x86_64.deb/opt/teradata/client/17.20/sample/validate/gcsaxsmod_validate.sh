#!/bin/sh
#******************************************************************************
#*    Copyright 2020 Teradata Corporation. ALL RIGHTS RESERVED.
#*    TERADATA CONFIDENTIAL AND TRADE SECRET.
#*
#*    Teradata Access Module for GCS Quick Start
#*    validatation for UNIX
#*
#*******************************************************************************

BUCKET=$1
PREFIX=$2
OBJECT=$3
PATH=$4
REQUIRED_ARGS=4

error_handle (){
        echo "$@"
        echo "Note:"
        echo "***************************************************************************"
        echo "* Please refer to the console messages and try to fix the errors before   *"
        echo "* re-running the job again. If the job error message does not make sense, *"
        echo "* please capture the console output and send it to the Teradata GSC team. *"
        echo "***************************************************************************"
}

if test ! $# = $REQUIRED_ARGS
then
  echo "Script Usage: ./gcsvalidate.sh parameter1 parameter2 parameter3 parameter4"
  echo "Parameter1: bucket name"
  echo "Parameter2: prefix"
  echo "Parameter3: object name"
  echo "Parameter4: path to access module library"
  echo "Test Binary Usage: ./gcs_testharness  [-h] |  [-v] [-t <n>]  [ -i <GCS ID> ] [ -k <GCS Key> ] [-g <n_read_limit>]  -r|-w  -m <module pathname> -p <module params>"
  echo "Example: ./gcs_testharness -w -p \"<Bucket=BucketName> <Prefix=PrefixName> <Object=ObjectName> -m <module_path>\""
  echo "where   <Bucket> This parameter specifies the GCS bucket to be used for load and export operations"
  echo "        <Prefix> This parameter is the name of the "directory" to be used within the bucket on the GCS service."
  echo "        <Object> Object is the name of the directory containing the files comprising the object."

  error_handle "Quick Start Validation of Teradata Access Module for GCS script failed."
  exit 1
fi

./gcs_testharness -w -T 5 -p "Bucket=$BUCKET Prefix=$PREFIX Object=$OBJECT" -m $PATH

