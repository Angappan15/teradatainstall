/***************************************************************************
*
* TITLE: flnfyext.c .... an example notify exit...
*
* Copyright(C) 1996-2005, 2007-2014, 2016 by Teradata Corporation.
* All Rights Reserved.
* Teradata Corporation CONFIDENTIAL AND TRADE SECRET
*
* This copyrighted material is the Confidential, Unpublished
* Property of the Teradata Corporation.  This copyright notice and
* any other copyright notices included in machine readable
* copies must be reproduced on all authorized copies.
*
*
* Description  This file is a sample user exit routine for
*              processing NOTIFY events
*
* History Information
*
* Revision    Date     JIRA     DID      Comments
* ----------- -------- -------- -------- --------------------------------------
* 16.00.00.00 06/03/16 SA-47292 CD185012 Change from long to int        
* 15.00.00.01 03202013 SA-30235 NT185003 Change MAXDBASENAMELEN to 62
* 15.00.00.00 02182013 SA-29748 NT185003 FastLoad Notify Exit changes for
* 14.10.00.00 10192012 SA-28595 NT185003 FL supports Notify Exit EON
*                                        Database name
*
* Revision    Date     DCR   DID      Comments
* ----------- -------- ----- -------- --------------------------------------
* 14.00.00.04 06292012 SA-1863 NT185003 Support 8-byte row count (DR141961)
* 14.00.00.03 03112011 117582 AS185203 EON Support  
* 14.00.00.02 11152010 141961 NT185003 Support 8 byte row count
* 14.00.00.01 11032010 109902 SV185048 Added database name to notify
* 13.00.00.01 09072007 114414 NT185003 Teradata Corporation Copyright
* 13.00.00.00 09012007 100894 SV185048 Visual Studio 8.0 build          
* 07.07.00.01 09292005 96206 CSG      Port to HPUX-IA64 platform
* 07.06.00.02 06182004 68859 XX151000 Back out branding changes
* 07.06.00.01 01142004 68859 XX151000 Change DBS to TERADATA DATABASE
* 07.01.00.01 07/10/98 42517 SF3      Redesign User Exit Interface
* 06.01.00.01 04/04/97 34579 SF3      Initial Version
*
*
* Notes         The entry point to this User Exit must
*               be called "_dynamn"
* Notes DR141961 and SA-1863 : support 8 byte row counters
*              To display correctly, please use the events:
*
*               NFEventCheckPoint64    = 13
*               NFEventPhaseIEnd64     = 14
*               NFEventPhaseIIEnd64    = 15
*               NFEventDropErrTableI64 = 16
*               NFEventDropErrTableII64= 17
*
*               instead of
*
*               NFEventCheckPoint      =  3
*               NFEventPhaseIEnd       =  4
*               NFEventPhaseIIEnd      =  6
*               NFEventDropErrTableI   =  7
*               NFEventDropErrTableII  =  8
*
* Note SA-28595, please use 2 new events
*
*               NFEventInitializeEON   = 18
*               NFEventPhaseIBeginEON  = 19
*
*
*       FastLoad works with both OLD and NEW Notify Exit.
*
***************************************************************************/
#include <stdio.h>
#include <inttypes.h>

/* DR 96206 --> */
typedef int Int32;      
typedef unsigned int UInt32;
#ifdef WIN32
typedef unsigned __int64   UInt64 ;             /* DR141961 */
#else
typedef uint64_t UInt64 ;             /* DR141961 */
#endif
/* DR 96206 <-- */

typedef enum { NFEventInitialize      =  0 ,
               NFEventFileInmodOpen   =  1 ,
               NFEventPhaseIBegin     =  2 ,
               NFEventCheckPoint      =  3 ,
               NFEventPhaseIEnd       =  4 ,
               NFEventPhaseIIBegin    =  5 ,
               NFEventPhaseIIEnd      =  6 ,
               NFEventDropErrTableI   =  7 ,
               NFEventDropErrTableII  =  8 ,
               NFEventDBSRestart      =  9 ,
               NFEventCLIError        = 10 ,
               NFEventDBSError        = 11 ,
               NFEventExit            = 12 ,
               /* DR141961 ==> */
               NFEventCheckPoint64    = 13 ,
               NFEventPhaseIEnd64     = 14 ,
               NFEventPhaseIIEnd64    = 15 ,
               NFEventDropErrTableI64 = 16 ,
               NFEventDropErrTableII64= 17 ,
               /* DR141961 <== */
               /* SA-28595 ==> */
               NFEventInitializeEON   = 18 ,
               NFEventPhaseIBeginEON  = 19
               /* SA-28595 <== */
} NfyFLDEvent;

#define ID_FASTLOAD     1
#define ID_MULTILOAD    2
#define ID_FASTEXPORT   3
#define ID_BTEQ         4
#define ID_TPUMP        5

#define MAXVERSIONIDLEN       32
#define MAXUTILITYNAMELEN     32
#define MAXUSERNAMELEN        64
#define MAXUSERSTRLEN         80
#define MAXTABLENAMELEN      128
#define MAXFILENAMELEN       256
#define MAXDBASENAMELEN       62   /* DR109902 */  /* SA-30235 */
#define MAXUINT64             24   /* DR141961 */

typedef struct _FLNotifyExitParm {
   Int32 Event;
   union {
      struct {
         UInt32 VersionLen;
         char   VersionId[MAXVERSIONIDLEN];
         UInt32 UtilityId;
         UInt32 UtilityNameLen;
         char   UtilityName[MAXUTILITYNAMELEN];
         UInt32 UserNameLen;
         char   UserName[MAXUSERNAMELEN];
         UInt32 UserStringLen;
         char   UserString[MAXUSERSTRLEN];
      } Initialize;
      /* SA-28595 ==> */
      struct {
         UInt32 VersionLen;
         char   VersionId[MAXVERSIONIDLEN];
         UInt32 UtilityId;
         UInt32 UtilityNameLen;
         char   UtilityName[MAXUTILITYNAMELEN];
         UInt32 UserNameLen;
         char   *UserName;
         UInt32 UserStringLen;
         char   UserString[MAXUSERSTRLEN];
      } InitializeEON;
      /* SA-28595 <== */
      struct {
         UInt32 FileNameLen;
         char   FileOrInmodName[MAXFILENAMELEN];
      } FileInmodOpen ;
      struct {
         UInt32 TableNameLen;
         char   TableName[MAXTABLENAMELEN];
         char   DBaseName[MAXDBASENAMELEN];    /* DR109902 */ /* SA-29748 */
         UInt32 dummy;
      } PhaseIBegin ;
      /* SA-28595 ==> */
      struct {
         UInt32 TableNameLen;
         char   *TableName;
         char   *DBaseName;                    /* SA-29748 */
         UInt32 dummy;
      } PhaseIBeginEON ;
      /* SA-28595 <== */
      struct {
         UInt32 RecordCount;
      } CheckPoint;
      /* DR141961 ==> */
      struct {
        char    RecordCount[MAXUINT64];
      } CheckPoint64;
      /* DR141961 <== */
      struct {
         UInt32 RecsRead;
         UInt32 RecsSkipped;
         UInt32 RecsRejected;
         UInt32 RecsSent;
      } PhaseIEnd ;
      /* DR141961 ==> */
      struct {
         char RecsRead[MAXUINT64];
         char RecsSkipped[MAXUINT64];
         char RecsRejected[MAXUINT64];
         char RecsSent[MAXUINT64];
      } PhaseIEnd64 ;
      /* DR141961 <== */
      struct {
         UInt32 dummy;
      } PhaseIIBegin;
      struct {
         UInt32 Inserts;
         UInt32 dummy1;
         UInt32 dummy2;
         UInt32 dummy3;
      } PhaseIIEnd;
      /* DR141961 ==> */
      struct {
         char Inserts[MAXUINT64];
         UInt32 dummy1;
         UInt32 dummy2;
         UInt32 dummy3;
      } PhaseIIEnd64;
      /* DR141961 <== */
      struct {
         UInt32 Rows;
         UInt32 dummy;
      } DropErrTableI;
      /* DR141961 ==> */
      struct {
         char   Rows[MAXUINT64];
         UInt32 dummy;
      } DropErrTableI64;
      /* DR141961 <== */
      struct {
         UInt32 Rows;
         UInt32 dummy;
      } DropErrTableII ;
      /* DR141961 ==> */
      struct {
         char   Rows[MAXUINT64];
         UInt32 dummy;
      } DropErrTableII64 ;
      /* DR141961 <== */
      struct {
         UInt32 dummy;
      } DBSRestart;
      struct {
         UInt32 ErrorCode;
      } CLIError;
      struct {
         UInt32 ErrorCode;
      } DBSError;
      struct {
         UInt32 ReturnCode;
      } Exit;
   } Vals;
} FLNotifyExitParm;

/*************************************************************************
*
*   CODE STARTS HERE
*
*************************************************************************/
#ifdef WIN32
__declspec(dllexport) Int32 _dynamn(FLNotifyExitParm *P)
#else
Int32 _dynamn(FLNotifyExitParm *P)
#endif
{
   static FILE *fp;

   if (!fp) {
#ifdef I370
      if (!(fp = fopen("NFYEXIT", "w")))
         return(1);
#else
      if (!(fp = fopen("NFYEXIT.OUT", "w")))
         return(1);
#endif
   }

   switch(P->Event) {
     case NFEventInitialize :
        fprintf(fp,
                "exit called @ FastLoad Notify initialization.\n");
        fprintf(fp,
                "              Version Id:   %s.\n",
                P->Vals.Initialize.VersionId);
        fprintf(fp,
                "              Utility Id:   %d.\n",
                P->Vals.Initialize.UtilityId);
        fprintf(fp,
                "              Utility Name: %s.\n",
                P->Vals.Initialize.UtilityName);
        fprintf(fp,
                "              User Name:    %s.\n",
                P->Vals.Initialize.UserName);
        break;

     /* SA-28595 ==> */
     case NFEventInitializeEON :
        fprintf(fp,
                "exit called @ FastLoad Notify initialization.\n");
        fprintf(fp,
                "              Version Id:   %s.\n",
                P->Vals.InitializeEON.VersionId);
        fprintf(fp,
                "              Utility Id:   %d.\n",
                P->Vals.InitializeEON.UtilityId);
        fprintf(fp,
                "              Utility Name: %s.\n",
                P->Vals.InitializeEON.UtilityName);
        fprintf(fp,
                "              User Name:    %s.\n",
                P->Vals.InitializeEON.UserName);
        break;
     /* SA-28595 <== */

     case NFEventFileInmodOpen :
        fprintf(fp,
                "exit called @ FastLoad file/inmod open: %s.\n",
                P->Vals.FileInmodOpen.FileOrInmodName);
        break;

     case NFEventPhaseIBegin :
        fprintf(fp,
                "exit called @ FastLoad phase I (start) for Database %s.\n",
                P->Vals.PhaseIBegin.DBaseName);      /*  DR109902  */
        fprintf(fp,
                "exit called @ FastLoad phase I (start) for table %s.\n",
                P->Vals.PhaseIBegin.TableName);
        break;

     /* SA-28595 ==> */
     case NFEventPhaseIBeginEON :
        fprintf(fp,
                "exit called @ FastLoad phase I (start) for Database %s.\n",
                P->Vals.PhaseIBeginEON.DBaseName);      /* DR109902  */
        fprintf(fp,
                "exit called @ FastLoad phase I (start) for table %s.\n",
                P->Vals.PhaseIBeginEON.TableName);
        break;
     /* SA-28595 <== */

     case NFEventCheckPoint :
        fprintf(fp,
                "exit called @ FastLoad checkpoint : %lu records loaded.\n",
                P->Vals.CheckPoint.RecordCount);
        break;

     /* DR141961 ==> */
     case NFEventCheckPoint64 :
        fprintf(fp,
                "exit called @ FastLoad checkpoint : %s records loaded.\n",
                P->Vals.CheckPoint64.RecordCount);
        break;
     /* DR141961 <== */

     case NFEventPhaseIEnd :
        fprintf(fp,
                "exit called @ FastLoad phase I (end).\n");
        fprintf(fp,
                "              Records read:     %lu\n",
                P->Vals.PhaseIEnd.RecsRead);
        fprintf(fp,
                "              Records skipped:  %lu\n",
                P->Vals.PhaseIEnd.RecsSkipped);
        fprintf(fp,
                "              Records rejected: %lu\n",
                P->Vals.PhaseIEnd.RecsRejected);
        fprintf(fp,
                "              Records sent:     %lu\n",
                P->Vals.PhaseIEnd.RecsSent);
        break;

     /* DR141961 ==> */
     case NFEventPhaseIEnd64 :
        fprintf(fp,
                "exit called @ FastLoad phase I (end).\n");
        fprintf(fp,
                "              Records read:     %s\n",
                P->Vals.PhaseIEnd64.RecsRead);
        fprintf(fp,
                "              Records skipped:  %s\n",
                P->Vals.PhaseIEnd64.RecsSkipped);
        fprintf(fp,
                "              Records rejected: %s\n",
                P->Vals.PhaseIEnd64.RecsRejected);
        fprintf(fp,
                "              Records sent:     %s\n",
                P->Vals.PhaseIEnd64.RecsSent);
        break;
     /* DR141961 <== */

     case NFEventPhaseIIBegin :
        fprintf(fp,
                "exit called @ FastLoad phase II (start).\n");
        break;

     case NFEventPhaseIIEnd :
        fprintf(fp,
                "exit called @ FastLoad phase II (end): %lu records loaded.\n",
                P->Vals.PhaseIIEnd.Inserts);
        break;

     /* DR141961 ==> */
     case NFEventPhaseIIEnd64 :
        fprintf(fp,
                "exit called @ FastLoad phase II (end): %s records loaded.\n",
                P->Vals.PhaseIIEnd64.Inserts);
        break;
     /* DR141961 <== */

     case NFEventDropErrTableI :
        fprintf(fp,
                "exit called @ FastLoad ET 1 Drop : %lu records in table.\n",
                P->Vals.DropErrTableI.Rows);
        break;

     /* DR141961 ==> */
     case NFEventDropErrTableI64 :
        fprintf(fp,
                "exit called @ FastLoad ET 1 Drop : %s records in table.\n",
                P->Vals.DropErrTableI64.Rows);
        break;
     /* DR141961 <== */

     case NFEventDropErrTableII :
        fprintf(fp,
                "exit called @ FastLoad ET 2 Drop : %lu records in table.\n",
                P->Vals.DropErrTableII.Rows);
        break;

     /* DR141961 ==> */
     case NFEventDropErrTableII64 :
        fprintf(fp,
                "exit called @ FastLoad ET 2 Drop : %s records in table.\n",
                P->Vals.DropErrTableII64.Rows);
        break;
     /* DR141961 <== */

     case NFEventDBSRestart :
        fprintf(fp,
                "exit called @ FastLoad detects DBS restart.\n");
        break;

     case NFEventCLIError :
        fprintf(fp,
                "exit called @ FastLoad detects CLI error: %d.\n",
                P->Vals.CLIError.ErrorCode);
        break;

     case NFEventDBSError :
        fprintf(fp,
                "exit called @ FastLoad detects DBS error: %d.\n",
                P->Vals.DBSError.ErrorCode);
        break;

     case NFEventExit :
	fprintf(fp,
                "exit called @ FastLoad exiting. Return code: %d.\n",
                P->Vals.Exit.ReturnCode);
        fclose(fp);
        break;
   }

   return(0);
}

/******************************************************************************
*
* End of FlNfyExt.c
*
******************************************************************************/
