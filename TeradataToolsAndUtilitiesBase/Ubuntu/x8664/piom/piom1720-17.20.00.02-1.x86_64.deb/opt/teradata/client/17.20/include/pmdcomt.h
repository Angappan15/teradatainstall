/* % TITLE pmdcomt.h ... Independent/Dependent Access Module                */
/*                       common struct/types                                */
/****************************************************************************/
/*                                                                          */
/*  Copyright 1999-2015,2022 Teradata Corporation.  ALL RIGHTS RESERVED.    */
/*  Teradata Corporation CONFIDENTIAL AND TRADE SECRET                      */
/*  This copyrighted material is the Confidential, Unpublished              */
/*  Property of the Teradata Corporation.  This copyright notice            */
/*  and any other copyright notices included in machine readable            */
/*  copies must be reproduced on all authorized copies.                     */
/*                                                                          */
/* CRITICAL USAGE NOTE:                                                     */
/*  This header file is to be the EXACT same file for both SA & TPT.        */
/*  The cooresponding versions in /vob/tdcli & /vob/paralx must match       */
/*  The identiy will insure that the same access module will work with      */
/*  the standalone utilities AND the TPT DC oeprator                        */
/*                                                                          */
/*                                                                          */
/* History Information                                                      */
/*                                                                          */
/*                      JIRA                                                */
/* Revision    Date     ISSUE    DID      Comments                          */
/* ----------- -------- -------- -------- -----------------------           */
/* 17.20.00.01 02042022 SA-53620 HM186000 Update Copyright changes          */
/* 17.10.00.01 03272021 SA-53170 HM186000 Sync SA PIOM header with          */
/*                                        TPT DC header                     */ 
/* 17.00.00.02 05122020 SA52533  HM186000 Merge/Sync Access Module Header   */
/*                                        Files From TPT DC                 */
/* 17.00.00.01 04152019 SA51725  HM186000 Provide attributes for Record Type*/
/*                                        and Delimiter Used                */
/* 17.00.00.00 01302019 SA51632  HM186000 compiler warnings on definition   */
/*                                        of PLATFORM_ID on Windows platform*/
/* 16.20.00.00 09142018 SA51031  HM186000 Port PIOM to native 64-bit        */
/* 15.10.00.00 06122014 SA33970  HM186000 Merge/Sync Access Module Header   */
/*                                        Files From TPT                    */
/* 15.00.00.02 01162014 SA33011  HM186000 Update copyright year to 2014     */
/* 15.00.00.01 12132013 SA32585  HM186000 Dataconnector : Fix issues related*/
/*                                        to file open on Z/OS platform     */
/* 15.00.00.00 04022013 SA30234  HM186000 Data format needs to be passed to */
/*                                        attached AM immediately following */
/*                                        open via pmiPIDMOptPutF_A         */
/* 14.10.00.02 01072013 SA29438  HM186000 Update copyright year to 2013     */
/* 14.10.00.01 11152012 SA28888  HM186000 PIOM returns error when OBJNAME   */
/*                                        file attribute length > 256 bytes */
/* 14.10.00.00 07272012 SA3822   HM186000 PIOM porting on Mac OS            */
/* 14.00.00.08 11072011 SA17649  HM168000 Improve performance of UDDI       */
/* 14.00.00.07 10042011 SA17774  tb122393 Open file in append mode feature. */
/*                                                                          */
/*                      DR/#                                                */
/* Revision    Date     DCR    DID     Comments                             */
/* ----------- -------- ------ ------- -----------------------              */
/* 14.00.00.06 07082011 152240 TWB     Update copyright year to 2011        */
/* 14.00.00.05 04202011 149182 TWB     Define linux flavors                 */
/* 14.00.00.04 12032010 141568 MN7     Win 64bit PIOM to handle alignment   */
/* 14.00.00.03 11302010 143378 TWB     New UDDI return codes                */
/* 14.00.00.02 07012010 104392 TWB     Implement UDDI (Universal Delimited  */
/*                                     Data Interface (VARTEXT)             */
/* 14.00.00.01 04082010 140969 TWB     Restart resource protection protocol.*/
/* 13.10.00.10 12172009 138394 TWB     Copyright to 2010                    */
/* 13.10.00.09 11092009 136971 TWB     Remove UNIX5 symbol undef (for BTEQ).*/
/* 13.10.00.08 09212009 135937 TWB     Add PLATFORMs HPUX RISC & ITANIUM    */
/* 13.10.00.07 07272009 134223 TWB     Write BOMs                           */
/* 13.10.00.06 07142009 134200 MN7     Define PLATFORM_ID for z/Linux       */
/* 13.10.00.05 07012009 129830 MN7     Win64-bit version of PIOM            */
/* 13.10.00.04 08272008 115918 TWB     IBM compiler.  Changes               */
/*                                     courtesy ASG & DEH                   */
/* 13.10.00.03 07202009 133527 TWB     Update Copyright                     */
/* 13.10.00.02 05182009 132666 TWB     Define UTF16 numeric symbol          */
/* 13.10.00.01 05042009 121824 TWB     Define UNIX5 symbol internally       */
/* 13.00.00.01 06262007 100091 TWB     Common AM headers                    */
/* 02.04.00.02 03272006 100810 TWB     Include Solaris "sub" platform in ID */
/* 02.04.00.01 01052006 100716 TWB     Timeout support                      */
/* 02.03.00.02 08312005  98655 TWB     Include LINUX in PLATFORM_ID define  */
/* 02.03.00.01 05252005  89779 TWB     character set conflict error value rc*/
/* 02.02.00.07 06242005  94488 CSG     Port to HP-Itanium                   */
/* 02.02.00.06 11022004  91167 TWB     UTF16 attribute handling             */
/* 02.02.00.05 04292004  68938 TWB     Include AIX packing                  */
/* 02.02.00.04 04212004  86512 TWB     Platform ID definition               */
/* 02.02.00.03 02172004  54292 TWB     FastExport/OLEDB AM structs          */
/* 02.02.00.02 02042004  57864 TWB     Added AM attribute names             */
/* 02.02.00.01 11182003  69285 TWB     New attributes                       */
/* 02.01.00.01 04112003  63259 TWB     Add new return codes                 */
/* 02.00.00.06 11142002  65685 TRV     pack 1 avoided for Win 64 platform   */
/* 02.00.00.05 11072002  64602 TWB     Add header version Ids               */
/* 02.00.00.04 09022002  64540 TRV     Changes for NPAM C++ compilation     */
/* 02.00.00.03 08272002  63707 TWB     Copyright Notice                     */
/* 02.00.00.02 07182002  58762 TRV     HPUX 64-bit Porting                  */
/* 02.00.00.01 07042002  58755 TRV     SOLARIS SPARC 64-bit Porting         */
/* 02.00.00.00 07012002  58754 TRV     Native 64-bit Client Support         */
/* 01.04.00.03 02152001  53279 CSG     Port DATACON to AIX                  */
/* 01.04.00.02 02132001  53280 CSG     Port DATACON to HPUX                 */
/* 01.04.00.01 11142000  52214 CSG     To support Solaris C++ compilation   */
/* 01.03.01.01 06212000  51361 TWB     Add pmrcNoEOR return code            */
/* 01.01.00.01 05131998  42617 TWB     Initial externalization of API       */
/*                                                                          */
/****************************************************************************/

#ifndef PMDCOMT_H
#define PMDCOMT_H

#define pmMAX_CLIENT_ID    255
#define pmMAX_ATR_NAME_LEN 255
#define pmMAX_ATR_VAL_LEN  1300                                   /*SA-28888*/
#define BUILD_YEAR (char const[5]) { __DATE__[7], __DATE__[8], __DATE__[9], __DATE__[10],'\0'}  /* SA-53620 */

#define PM_ATR_NAME_TIMEOUT "TIMEOUT_SECONDS"                     /* 100716 */
#define PM_ATR_NAME_CHARSET_NAME  "CHARSET_NAME"             /* Begin 69285 */
#define PM_ATR_NAME_CHARSET_NUMBER  "CHARSET_NUMBER"
#define PM_ATR_INSTANCE_NUMBERS  "INSTANCE_NUMBERS"              /*TPT-31816*/
#define PM_ATR_NAME_RECORD_TYPE "RECORD_TYPE"                    /* SA-51725 */
#define PM_ATR_NAME_DELIMITER_VALUE "DELIMITER_VALUE"            /* SA-51725 */
#ifdef __MVS__                                                    /* 104392 */
#define PM_DEFAULT_CHARSET_NAME "EBCDIC"                          /* 104392 */
#else                                                             /* 104392 */
#define PM_DEFAULT_CHARSET_NAME "ASCII"                           /* 104392 */
#endif                                                            /* 104392 */
#define PM_ATR_NAME_WR_BOM "WRITE_BOM"
#define PM_ATR_NAME_ENHANCED_RESTART "Restart_Validation"         /* 100091 */
#define PM_ATR_NAME_KEEP_RESTART_RESOURCES "PRESERVE_RESTART_INFO"/* 140969 */
#define PM_ATR_NAME_FILE_DATA_FORMAT "FILE_DATA_FORMAT"           /* SA-30234 */
#define PM_ATR_VALU_UTF32  "UTF32"                                /* 100091 */
#define PM_ATR_VALU_UTF16  "UTF16"                                 /* 91167 */
#define PM_ATR_VALU_UTF16n "62"                                   /* 132666 */
#define PM_ATR_VALU_UTF8   "UTF8"
#define PM_ATR_VALU_UTF8n  "63"                                   /* 134223 */
#define PM_ATR_VALU_ASCII  "ASCII"
#define PM_ATR_NAME_BYTE_ORDER  "BYTE_ORDER"
#define PM_ATR_VALU_BIG "BIG_ENDIAN"
#define PM_ATR_VALU_LITTLE "LITTLE_ENDIAN"
#define PM_ATR_VALU_YES "YES"
#define PM_ATR_VALU_NO  "NO"
#define PM_ATR_VALU_DEFAULT "DEFAULT"                          /* End 69285 */

/*                                                              Begin 57864 */
/*           Used to pass the CHECKPOINT value from the client load utility */
/*                  (i.e. FastLoad, MultiLoad, TPump) to the access module. */
/*     The attribute value is a string containing the ASCII encoding of the */
/*  decimal textual representation of the CHECKPOINT value.  A value of "0" */
/*      indicates that checkpoint/restart processing is not enabled; a file */
/*    opened by an access module instance for which the CHECKPOINT_INTERVAL */
/*         attribute is "0" (at the time of the File Open request) will not */
/*                                     receive a File Get Position request. */

#define PM_ATR_NAME_CHECKPOINT_OPTION "CHECKPOINT_INTERVAL"
/*                                                                End 57864 */

/*                                                              Begin 54292 */
#define PM_ATR_NAME_EXPORT_WIDTH "EXPORT_WIDTHS"

/*          The list of server character type codes.  These values are used */
/*            in the CharType field of pmExpWidth_t structures.  The values */
/*                               should match the corresponding values from */
/*                                            dbsv2/src/par/evl/evltypes.h. */
#define pmEVLLATIN1  1               /* 8-bit Latin1 character data type */
#define pmEVLUNICODE 2             /* 16-bit Unicode character data type */
#define pmEVLSJIS    3                  /* KanjiSJIS character data type */
#define pmEVLGRAPHIC 4       /* Graphic character data type (in Unicode) */  
#define pmEVLKANJI1  5                     /* Kanji1 character data type */
/*                                                                End 54292 */

/* DR 58755, DR 58762 --> */

#if defined(HPUX) && defined(PIOM64) && !defined(HPUX_IA64)        /*DR94488*/
#ifdef __cplusplus                    /* DR 64540 --> */
#define pmdcomt_packing "pack 8"                                   /* 86512 */
#pragma pack 8 
#else
/*#define pmdcomt_packing "HP_ALIGN NATURAL PUSH"*/     /* 86512 *//*SA33970*/
/*#pragma HP_ALIGN NATURAL PUSH*/                                  /*SA33970*/
#endif                                /* DR 64540 <-- */
#elif defined(HPUX_IA64) && defined(PIOM64)   /* DR 94488 --> */
#define pmdcomt_packing "pack(8)"
#pragma pack(8)                               /* DR 94488 <-- */
#elif defined(SOLARIS) && defined(PIOM64)
#define pmdcomt_packing "pack(8)"                                  /* 86512 */
#pragma pack(8)
#elif defined (AIX)                                                /* 68938 */
#define pmdcomt_packing "options align=packed"                     /* 68938 */
#pragma options align=packed                                       /* 68938 */
#elif defined(__MVS__)                                            /* 115918 */
#pragma pack(packed)                                              /* 115918 */
#define pmdcomt_packing "pack(packed)"                            /* 134223 */
#elif !defined(HPUX) && !defined(SOLARIS)                         /* 115918 */\
      && !defined(_WIN64)  && !defined(__APPLE__)/* DRs: 53279, 53280, 52214, 65685,SA3822 */ 
#define pmdcomt_packing "pack (push, 1)"                           /* 86512 */
#pragma pack (push, 1)
#elif defined(_WIN64)                                              /*141568*/
#define pmdcomt_packing "pack (push, 1)"                           /*141568*/
#pragma pack (push, 1)                                             /*141568*/                                             
#endif                                                             /*141568*/

#if !defined (pmdcomt_packing)                                     /* 64602 */
#define pmdcomt_packing "none"                                     /* 86512 */
#endif                                                             /* 64602 */

/* DR 58755, DR 58762 <-- */

#define pmdcomt_HeaderVersion "Common 17.10.00.01"            /* SRC SA52533 */
#define pmdcomt_ID "pmdcomt header version '" pmdcomt_HeaderVersion \
 "', packing '" pmdcomt_packing "'"

/* DR 58754 : Changed long to int for PIOM64 */
typedef unsigned int pmUInt32;   /* 32-bit unsigned integer */    /*SA33970*/
#ifdef PIOM64
#define pmInterfaceVersionD 1001
#else
#define pmInterfaceVersionD 1000
#endif

/* DR 58754 (eoc)  */

typedef unsigned short  pmUInt16;       /* 16-bit unsigned integer */
typedef pmUInt32        pmReturnType;   /* Return value type for   */
                                        /* all API functions       */
typedef short           pmOpenMode_t;   /* Access Module mode for pmOpen */
typedef int             pmTrceLvl_t;    /* Trace level type */

/*                                                              Begin 54292 */
/*   Export widths information structure.  An array of these structures is  */
/* passed as the attribute value in an EXPORT_WIDTHS instance put attribute */
/*       request.  In this case the attribute value length is the number of */
/*     bytes occupied by the entire array.  The export width information is */
/*   used to calculate the size in bytes of exported fixed-length character */
/*      columns.  This size depends not only on the number of characters in */
/*  the data type (i.e. the n in CHAR(n)), but also on the selected session */
/*       character set (for example, "UTF8"), and the server character type */
/*   (specified in the CHARACTER SET clause of the CREATE TABLE statement). */
/*         The export width information passed in an EXPORT_WIDTHS instance */
/*     put attribute request pertains to the current session character set. */
/*        Each structure passed in the array has information for one server */
/*                                                          character type. */
typedef struct pmExpWidth
{
	pmUInt16 CharType;     /* Server character type code.                   */
	pmUInt16 ExpWidth;     /* Export width. Contains the scale value that   */
                           /*  is to be multiplied by the number of         */
                           /*  characters in the data type.                 */
	pmUInt16 ExpWidthAdj;  /* Export width adjustment.  Contains the offset */
                           /* value that is added to the product of ExpWidth*/
                           /* and number of characters in the data type in  */
                           /* order to obtain the export width.             */
} pmExpWidth_t;
/*                                                                End 54292 */

 
/* Media Position description structure */
typedef struct _pmPosData
{
  pmUInt32   Length;
  char      *Data;
} pmPos_t;
 
typedef struct _pmNameBuf
{
  pmUInt32   DataLength;
  char      *Data;
} pmNameBuf_t;

/* Access Module Version Identification structure */
#define pmMAX_VER_STR_LEN 31
typedef struct _pmVerLst_t
{
  char                ModuleName[pmMAX_VER_STR_LEN+1];
  char                ModuleVers[pmMAX_VER_STR_LEN+1];
  struct _pmVerLst_t *Next;
} pmVerLst_t;
 
/* List of return codes generated by any call to the API */
#define pmrcOK              0    /* All's well :: MUST BE ZERO !! :: */
#define pmrcBadpmHandle     1    /* Invalid pmHandle parameter passed */
#define pmrcBadParm         2    /* Bad parameter passed to API */
#define pmrcAXMNotFound     3    /* Requested Access Module not found */
#define pmrcFileNotFound    4    /* Requested file not found */
#define pmrcWriteOnly       5    /* Access Module is write only */
#define pmrcReadOnly        6    /* Access Module is read only */
#define pmrcBadFp           7    /* Invalid pmFp parameter passed */
#define pmrcOpenFiles       8    /* Access Module still has open files */
#define pmrcEOF             9    /* Access Module reached EOF */
#define pmrcCPReady         10   /* Access Module is ready to checkpoint */
#define pmrcInvUtil         11   /* Invalid utility ID passed to pmInit */
#define pmrcAllocErr        12   /* Error encountered during memory mgmt */
#define pmrcBadOpenMode     13   /* Unsupported mode */
#define pmrcBadFormat       14   /* Unsupported format */
#define pmrcBadBlksize      15   /* Unsupported block size */
#define pmrcDataFormatErr   16   /* Unexpected data format */
#define pmrcBufferOverFlow  17   /* Record beyond buffer */
#define pmrcBadVer          18   /* info->InterfaceVerNo!=pmInterfaceVersion */
#define pmrcFNameTooLong    19   /* File name too long */
#define pmrcInitCmdSyntax   20   /* Access Module Init string syntax error */
#define pmrcInitInvCmd      21   /* Init string invalid command char */
#define pmrcInitInvOpt      22   /* Init string invalid cmd option */
#define pmrcPosDataInvL     23   /* Invalid positioning data length */
#define pmrcUnsupported     24   /* Unsupported feature */
#define pmrcKeepReading     25   /* Continue reading 'till end-of-buffer */
#define pmrcAXMnotReady     26   /* pmInit has not been called */
#define pmrcBadTraceLvl     27   /* Invalid diagnostic trace level */
#define pmrcOpenAXMs        28   /* Access Modules still open */
#define pmrcEmptyFile       29   /* Empty file on read open */
#define pmrcRedundant       30   /* Redundant pmInit call */
#define pmrcBadFormatInfo   31   /* Invalid Supplemental Format Information */
#define pmrcBadChkPtMode    32   /* Invalid Checkpointing mode */
#define pmrcBadAttrName     33   /* Unrecognized attribute name */
#define pmrcFailure         34   /* Indeterminate error.  Ref pmGetErrText() */
#define pmrcNoEOR           35   /* EOF before EOR on text data        51361 */
#define pmrcBufferSizeExcess 36  /* BufferSize exceeded by axsmod      63259 */
#define pmrcAMsymbolError   37   /* AM symbol resolution error         63259 */
/*                              shifted values for compatibility Begin 91167 */
#define pmrcLRECLMismatch   38   /* USS: LRECL!=TWB schema length      67473 */
#define pmrcBadMBC          39   /* Bad multi-byte character found     67969 */
#define pmrcBadAttrValue    40   /* Invalid attribute value            90450 */
#define pmrcOnlyAfterAttach 41   /* Can't set AM attr after file open  90450 */
#define pmrcSignatureFailed 42   /* Unable to obtain data signature    90450 */
#define pmrcRestartDataMismatch 43 /* Data after restart doesn't match 90450 */
#define pmrcOnlyAfterOpen   44   /* Open attribute setting timing error69285 */
#define pmrcEndianConflict  45   /* Requested endianess vs. file       69285 */
#define pmrcCharacterSetConflict 46 /* file UTF control vs. characterset 89779*/
/*                                                                 End 91167 */
#define pmrcEscapeRecDelimError  47                                /*TPT33341*/
#define pmrcBadAttrNameDC   50   /* attribute name unrecognized by DC  91167 */
#define pmrcBadAttrValueDC  51   /* attribute value rejected by DC     91167 */

#define pmrcTimeout         55   /*              An I/O has timed out 100716 */
#define pmrcNoPositionPipe  56   /*            Can't position a PIPE  SA33970*/

#define pmrcColLenthError   60   /* Error, row not returned           143378 */
#define pmrcTooFewColumns   61   /* Error, too few columns            143378 */
#define pmrcTooManyColumns  62   /* Error, too many columns           143378 */
#define pmrcColMissingOpenQuote  63 /* Error, col missing open quote  143378 */
#define pmrcColMissingCloseQuote 64 /* Error, col missing close quote 143378 */
#define pmrcQuoteEscapeError     65                                /*SA-17649*/
#define pmrcDelimiterEscapeError 66                                /*SA-17649*/

 
/* Open modes (Read, Write, or ReadWrite) */
#define pmOpenModeR    1       /* Read only */
#define pmOpenModeW    2       /* Write only */
#define pmOpenModeRW   3       /* Read first, then write only */
#define pmOpenModeA    4       /* Open for writing at at/over EOF   SA-17774 */
#define pmOpenModeRWA  5                                         /* SA-32585 */
#define pmOpenMode_MAX 5                                         /* SA-32585 */
 
/* Shutdown modes */
#define pmShutDownNormal  1
#define pmShutDownBrute   2

/* Trace levels */
#define pmTrceNone     1  /* issue no trace messages */
#define pmTrceEvents   2
#define pmTrceIOcounts 3
#define pmTrceIObufs   4
#define pmTrceInfo     5
#define pmTrce_MAX     5

/*                                                              Begin 86512 */
/*                                              Identify compiling platform */
#ifdef PIOM64                                                     /* 100716 */
   #define MODE "64-bit "                                         /* 100716 */
#else                                                             /* 100716 */
   #define MODE "32-bit "                                         /* 100716 */
#endif                                                            /* 100716 */

#ifdef UNIX5                                                      /* 121824 */
   #undef UNIX5                                                   /* 121824 */
#endif                                                            /* 121824 */

                                  /* For Solaris, get flavor.  Begin 100810 */
#ifdef SOLARIS
   #define UNIX5                                                   /* 121824 */
   #ifdef INTEL
      #define PLATFORM_ID MODE "Solaris/Intel"
   #endif
   #ifdef SPARC
      #define PLATFORM_ID MODE "Solaris/SPARC"
   #endif
   #ifdef OPTERON
      #define PLATFORM_ID MODE "Solaris/Opteron"
   #endif
   #ifndef PLATFORM_ID
      #define PLATFORM_ID MODE "Solaris"
   #endif
#endif                                                        /* End 100810 */

#ifdef __APPLE__                                              /*SA-3822*/
   #define UNIX5                                              /*SA-3822*/
   #define PLATFORM_ID MODE "Mac OS X"                        /*SA-3822*/
#endif                                                        /*SA-3822*/

#ifdef I370
   #define PLATFORM_ID MODE "IBM 370"                                /* 100716 */
#endif

#ifdef MPRAS
   #define UNIX5                                                     /* 121824 */
   #define PLATFORM_ID MODE "MPRAS"                                  /* 100716 */
#endif

#ifdef _WIN64                                                     /* 129830 */
   #define PLATFORM_ID MODE "WIN64"                               /* 129830 */
#endif                                                            /* 129830 */
#if defined(_WIN32) && !defined(_WIN64)                           /* SA51632  */
   #define PLATFORM_ID MODE "WIN32"                               /* 100716 */
#endif

#ifdef __MVS__
   #ifdef PLATFORM_ID                                                /* 100716 */
      #undef PLATFORM_ID                                             /* 100716 */
   #endif                                                            /* 100716 */
   #define PLATFORM_ID MODE "IBM zSeries"                            /* 115918 */
#endif

#ifdef HPUX
   #define UNIX5                                                      /* 136971 */
   #ifdef RISC                                                        /* 135937 */
      #define PLATFORM_ID MODE "HPUX-PA"                              /* 135937 */
   #elif defined(ITANIUM)                                             /* 135937 */
      #define PLATFORM_ID MODE "HPUX-IA"                              /* 135937 */
   #else                                                              /* 135937 */
      #define PLATFORM_ID MODE "HPUX"                                 /* 135937 */
   #endif                                                             /* 135937 */
#endif

#ifdef AIX
   #define UNIX5                                                  /* 121824 */
   #define PLATFORM_ID MODE "IBM AIX"                             /* 100716 */
#endif

#ifdef LINUX                                                       /* 98655 */
   #define UNIX5                                                   /* 121824 */
#endif                                                             /* 98655 */

#ifdef SUSELINUX390                                               /* 134200 */
   #define PLATFORM_ID MODE "LINUX on z/OS"                       /* 134200 */
#endif                                                            /* 134200 */

#ifdef SUSELINUX8664                                              /* 149182 */
   #define PLATFORM_ID MODE "LINUX / SUSE x8664"                  /* 149182 */
#endif                                                            /* 149182 */

#ifdef REDHAT386                                                  /* 149182 */
   #define PLATFORM_ID MODE "LINUX / REDHAT i386"                 /* 149182 */
#endif                                                            /* 149182 */

#ifdef REDHAT8664                                                 /* 149182 */
   #define PLATFORM_ID MODE "LINUX / REDHAT x8664"                /* 149182 */
#endif                                                            /* 149182 */

#ifndef PLATFORM_ID
   #define UNIX5                                                     /* 121824 */
   #ifdef LINUX                                                      /* 149182 */
      #define PLATFORM_ID MODE "LINUX"                               /* TPT10758 */
   #else                                                             /* 149182 */
      #define PLATFORM_ID MODE "MPRAS (default)"                     /* 100716 */
   #endif
#endif                                                            /* 149182 */
/*                                                                End 86512 */ 

#ifdef UNIX5                                                       /* 98655 */
   #define UNIX5_compatible "yes"                                  /* 98655 */
#else                                                              /* 98655 */
   #define UNIX5_compatible "no"                                   /* 98655 */
#endif                                                             /* 98655 */

/* DR 58755, 58762 --> */

#if defined(HPUX) && defined(PIOM64) && !defined(HPUX_IA64)             /*DR94488*/
   #ifdef __cplusplus                                                   /* DR 64540 --> */
      #pragma pack 
   #else
      /*#pragma HP_ALIGN POP */                                         /*TPT21117*/
   #endif                                                               /* DR 64540 <-- */
#elif defined(HPUX_IA64) && defined(PIOM64)                             /* DR 94488 --> */
   #pragma pack()                                                       /* DR 94488 <-- */
#elif defined(SOLARIS) && defined(PIOM64)
   #pragma pack()
#elif defined (AIX)                                                     /* 68938 */
   #pragma options align=reset                                          /* 68938 */
#elif defined(__MVS__)                                                  /* 115918 */
   #pragma pack(reset)                                                  /* 115918 */
#elif !defined(HPUX) && !defined(SOLARIS)                               /* 115918 */\
      && !defined(_WIN64) && !defined(__APPLE__)                        /* DRs: 53279, 53280, 52214, 65685 , SA3822*/ 
   #pragma pack (pop)
#elif defined(_WIN64)                                                   /* 141568 */
   #pragma pack (pop)                                                   /* 141568 */
#endif                                                                  /* 141568 */

/* DR 58755, 58762 <-- */

#endif /* PMDCOMT_H */
