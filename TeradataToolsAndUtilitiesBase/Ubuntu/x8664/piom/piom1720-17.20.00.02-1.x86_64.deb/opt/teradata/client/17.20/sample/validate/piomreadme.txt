Overview:
  This directory contains a quick start validation tool to validate Teradata Data Connector
  after installation.

Directory Contents:
  piomvalidate.bat -- This script is installed on Windows platform. You must
  execute this script from its current installed location.  The script 
  will execute piomqstart.flscript in the quickstart directory: 
piomqstart.fl 
	
  Usage: piomvalidate.bat [NODEID] [UserName] [UserPassword]
  where: [NODIE] is a database name ID.
       	 [UserName] is a database user name.
       	 [UserPassword] is a database user password.

  piomvalidate.ksh -- This script is installed on unix platforms. You must
  execute this script from its current installed location.  The script 
  will execute piomqstart.fl script in the quickstart directory: 

	 Usage: ./piomvalidate.ksh <NODEID> <UserName> <UserPassword>
         where: <NODEID> is a database name ID
   	        <UserName> is database user name.
      	        <UserPassword> is database user password.
