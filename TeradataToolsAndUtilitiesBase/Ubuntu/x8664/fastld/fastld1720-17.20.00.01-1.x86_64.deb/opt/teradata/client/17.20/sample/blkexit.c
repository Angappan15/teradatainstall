/*************************************************************************
*
* Title: BLKEXIT - sample INMOD routine
*
* Copyright(C) 2005-2014 by Teradata Corporation.
* All Rights Reserved.
* Teradata Corporation CONFIDENTIAL AND TRADE SECRET
*
* This copyrighted material is the Confidential, Unpublished 
* Property of the Teradata Corporation.  This copyright notice and 
* any other copyright notices included in machine readable 
* copies must be reproduced on all authorized copies.
*
*
* Description  This file contains a sample INMOD, written in C.
*              This file does not support DBS restarts.
*
*
* History Information
*
* Revision    Date     DCR   DID     Comments
* ----------- -------- ----- ------- ---------------------------------------
* 13.00.00.01 09072007 114414 NT185003 Teradata Corporation Copyright
* 13.00.00.00 09012007 100894 SV185048 Visual Studio 8.0 build          
* 07.07.00.01 06/22/05 96206 CSG     Port to HP-UX-11.23 on Itanium
* 07.01.00.01 11/12/98 44120 SF3     Release for FastLoad 7.1
* 06.00.00.00 07/18/96 34208 SF3     Release for FastLoad 6.0
*               
*
* How to build this INMOD on a Unix system:
*
*    Compile and link it into a shared object:
*
*       cc -G -KPIC <inmod-name>.c -o <shared-object-name>
*
*
* How to use this program:
*
*   This INMOD routine will generate 2 columns of data:
*
*      4-byte integer counter for the Unique Primary Index
*      10-byte character string
*
* This sample INMOD will generate 100,000 rows, if no RECORD
* statement is used in the FastLoad job script.
*
* A sample of the job script for this INMOD would be as follows:
*
*
* use your own system, account and password here.
*
LOGON tdpid/user,password;

DROP TABLE Error_1;
DROP TABLE Error_2;
DROP TABLE TestTable;

CREATE TABLE TestTable AS (
   Counter Integer,
   text    char(10) )
UNIQUE PRIMARY INDEX(Counter);

BEGIN LOADING TestTable ErrorFiles Error_1, Error_2;
     
DEFINE 
   Counter (Integer),
   text    (char(10))
INMOD=<shared-object-name>;

INSERT INTO TestTable 
   (Counter, text)
VALUES 
   (:Counter, :text);

END LOADING;
LOGOFF;

*************************************************************************/

#include <stdio.h>
#include <string.h>

#define FILEOF     401
#define EM_OK      0

#define NUMROWS    100000
#define ROWSIZE    64000
              
typedef int Int32; /* DR 96206 */
typedef unsigned int UInt32; /* DR 96206 */
typedef short Int16;

typedef struct inmod_struct {
   Int32 ReturnCode;
   Int32 Length;
   char  Body[ROWSIZE];
} inmdtyp,*inmdptr;

inmdptr inmodptr;

char *str = "123test890";

Int32 reccnt = 0;
 
/*************************************************************************
*
* MakeRecord - Generate a record
*
*    This module creates the data record
*
*    In this example, we are just generating dummy records
*    with canned data, only we change the first column,
*    essentially a record number, so that each row is unique.
*
*    For performance reasons, we do not change the 2nd column.
*
*************************************************************************/
Int32 MakeRecord()
{
   char *p;

   /* have we reached EOF yet? */

   if (reccnt >= NUMROWS)
      return(FILEOF);

   /* nope. get start of buffer */

   p = inmodptr->Body;

   /* place column 1, a unique primary index */

   memcpy(p, &reccnt, (UInt32)sizeof(reccnt));   /*DR96206*/
   p += sizeof(reccnt);

   /* place column 2, a string */

   memcpy(p, str, strlen(str));
   p += strlen(str);

   inmodptr->ReturnCode = 0;
   inmodptr->Length = p - inmodptr->Body;

   reccnt++;

   return(EM_OK);
}

/*************************************************************************
*
* HostRestart - Host restarted 
*
*    Reset and start sending data from the begining.
*
*************************************************************************/
Int32 HostRestart()
{
   return(EM_OK);
}

/*************************************************************************
*
* CheckPoint - Save checkpoint
*
*************************************************************************/
Int32 CheckPoint()
{
   return(EM_OK);
}
 
/*************************************************************************
*
* DBSRestart - DBS restarted 
*
*    Do what you have to do. 
*    Reset record counter to checkpoint value
*
*************************************************************************/
Int32 DBSRestart()
{
   return(EM_OK);
}

/*************************************************************************
*
* CleanUp - Do cleanup.
*
*************************************************************************/
Int32 CleanUp()
{
   return(EM_OK);
}
 
/*************************************************************************
*
* InvalidCode - Invalid INMOD code returned.
*
*************************************************************************/
Int32 InvalidCode()
{
   fprintf(stderr, "**** Invalid code received by INMOD\n");
   return(EM_OK);
}
 
/*************************************************************************
*
* Init - initialize some stuff
*
*    Do any initialization necessary
*
*************************************************************************/
Int32 Init()
{
   return(EM_OK);
}

/*************************************************************************
*
* BLKEXIT - Start processing
*
*    This is the main module which contains the checks for
*    number of records generated and buffer filling.  This
*    module also sends the filled buffer to the DBS.
*
*************************************************************************/
#if defined WIN32
__declspec(dllexport) Int32 BLKEXIT(tblptr)
#elif defined I370
Int32 _dynamn(tblptr)
#else
Int32 BLKEXIT(tblptr)
#endif
char *tblptr;
{
   Int32 result;
 
   inmodptr = (struct inmod_struct *)tblptr;

   /* process the function passed to the INMOD */

   switch (inmodptr->ReturnCode) {
      case 0:  result = Init();
               if (result)
                  break;
               result = MakeRecord();
               break;
      case 1:  result = MakeRecord();
               break;
      case 2:  result = HostRestart();
               break;
      case 3:  result = CheckPoint();
               break;
      case 4:  result = DBSRestart();
               break;
      case 5:  result = CleanUp();
               break;
      default: result = InvalidCode();
   }

   /* see if we have reached EOF condition */

   if (result == FILEOF) {
      inmodptr->Length = 0;
      result = EM_OK;
   }

   return(result);
}

