Overview:
  This directory contains a quick start validation tool to validate 
  Teradata Access Module for GCS after installation.

Directory Contents:
  gcsvalidate.sh -- This script is installed on unix platforms. You must
  execute this script from its current installed location. The script
  will execute gcs_testharness in the validate directory

  Script Usage: ./gcsvalidate.sh parameter1 parameter2 parameter3 parameter4
  where:
     Parameter1 = bucket name
     Parameter2 = prefix
     Parameter3 = object name
     Parameter4 = path to access module library
  
  Test Binary Usage: ./gcs_testharness  [-h] [-v] [-t <n>] [-r | -w ] 
  [ -k GCS Key ] [ -i GCS ID ] -m <module path>  -p <module params> 
  -g <n_read_limit>

  Test Binary Usage: ./gcs_testharness -h

  Usage: ./gcs_testharness  [-h] |  [-v] [-t <n>]  [ -i <GCS ID> ] [ -k <GCS Key> ] 
  [-g <n_read_limit>]  -r|-w  -m <module pathname> -p <module params>

        -h                   Print this usage message and exit
        -v                   Enable erbose logging
        -t <n>               Set diagnostic trace flag
        -i <GCS ID>          Set GCS_ACCESS_KEY_ID env var for this run
        -k <GCS Key>         Set GCS_SECRET_ACCESS_KEY env var for this run
        -g <n_read_limit>    Execute <n_read_limit> reads and then do a getpos() operation
        -r                   Read data from GCS
        -w                   Write data to GCS
        -m <pathname>        Pathname of the access module to load
        -p <parameters>      Parameters to be passed ot the access module
  
  The 4 parameters [parameter1, parameter2, parameter3 and parameter4] 
  are required by the Test Binary [gcs_testharness] 
  and are substituted as mentioned below for the Test Binary to work.

  ./gcs_testharness -w -p \"<Bucket=parameter1> <Prefix=parameter2> <Object=parameter3>\ -m <module path>"

  where -w for write mode
        -r for read mode
        -m <module path> Path for Teradata Access Module for GCS.
        -p for module parameters which are described below.
        <Bucket> This parameter specifies the GCS bucket to be used for load and export operations
        <Prefix> This parameter is the name of the "directory" to be used within the bucket on the GCS service.
        <Object> Object is the name of the directory containing the files comprising the object.

