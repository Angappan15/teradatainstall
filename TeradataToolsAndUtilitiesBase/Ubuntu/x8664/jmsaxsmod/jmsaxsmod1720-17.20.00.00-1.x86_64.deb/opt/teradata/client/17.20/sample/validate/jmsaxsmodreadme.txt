Overview:
  This directory contains a quick start validation tool to validate Teradata Java Message
  Service(JMS) after installation.

Directory Contents:
  jmsaxsmodvalidate.bat -- This script is installed on Windows platform. You must
  execute this script from its current installed location.  The script 
  will execute jmsaxsmodqstart.fl script in the quickstart directory: 
jmsaxsmodqstart.fl 
	
  Usage: jmsaxsmodvalidate.bat [NODEID] [UserName] [UserPassword]
  where: [NODIE] is a database name ID.
       	 [UserName] is a database user name.
       	 [UserPassword] is a database user password.

  jmsaxsmodvalidate.ksh -- This script is installed on unix platforms. You must
  execute this script from its current installed location.  The script 
  will execute jmsaxsmodqstart.fl script in the quickstart directory: 

	 Usage: ./jmsaxsmodvalidate.ksh <NODEID> <UserName> <UserPassword>
         where: <NODEID> is a database name ID
   	        <UserName> is database user name.
      	        <UserPassword> is database user password.

jmsaxsmod_parmfile is the parameter file by using this particular file user can  submit job with 
required parameters.
