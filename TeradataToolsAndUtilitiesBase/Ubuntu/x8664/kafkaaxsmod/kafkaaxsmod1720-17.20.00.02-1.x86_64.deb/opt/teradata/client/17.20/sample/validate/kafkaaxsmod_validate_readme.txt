Overview:
  This directory contains a quick start validation tool to validate Teradata Kafka Message
  server Access Module after installation.

Directory Contents:

  kafkaaxsmodvalidate.bat  -- This script is installed on Windows platform. You must
  execute this script from its current installed location.The script
  will execute kafkaaxsmod_qstart.tpt in the quickstart directory
  Usage: ./kafkaaxsmod_validate.bat <NODEID> <UserName> <UserPassword> <TOPICNAME>
        <BROKER> <PARTITIONS>
  where <NODEID> is a database name id
        <UserName> is database User Name.
        <UserPassword> is database User Password.
        <TOPICNAME> is a Kafka Message Server topic name
        <BROKER> is a kafka Message Server Broker e.g. KAFKASERVERIPADDRESS:PORTNO
        <PARTITIONS> is partitions of the topic e.g. 0,1

  kafkaaxsmod_validate.ksh -- This script is installed on unix platforms. You must
  execute this script from its current installed location.The script
  will execute kafkaaxsmod_qstart.tpt in the quickstart directory
  Usage: ./kafkaaxsmod_validate.ksh <NODEID> <UserName> <UserPassword> <TOPICNAME>
         <BROKER> <PARTITIONS>
  where <NODEID> is a database name id
        <UserName> is database User Name.
        <UserPassword> is database User Password.
        <TOPICNAME> is a Kafka Message Server topic name
        <BROKER> is a kafka Message Server Broker e.g. KAFKASERVERIPADDRESS:PORTNO
        <PARTITIONS> is partitions of the topic e.g. 0,1
