/***********************************************************************
* TITLE   : btnfyext.h
************************************************************************
*
* Copyright 1996, 1998, 2002-2003, 2007, 2009-2010, 2012-2013,
* 2015, 2021 by Teradata Corporation. All Rights Reserved.
* TERADATA CONFIDENTIAL AND TRADE SECRET.
*
************************************************************************
*
* PURPOSE : The type definitions for BTEQ NOTIFY exit to aid in the
*           implementation of NOTIFY exits.
*
* IMPORTANT!!!
* This header file is an API which must be used as-is by employing a
* preprocessor include directive to include its contents in site
* specific Notify Exit source files. Since the data structures defined
* in this file are also used by BTEQ code, any mismatch in the
* definitions could lead to unexpected behaviour.
* Make sure to use the same version of this header file which is 
* distributed with the target BTEQ version.
*
************************************************************************
*
* History :
*
* Revision    Date      JI         DID      Comments
* ----------- --------- ---------- -------------------------------------
* 17.10.00.00 2021May27 BTEQ13205  SA Removed obsolete SAS/C paths.
* 16.00.00.00 2015Apr23 BTEQ10569  RC Make btnfyext.h an API.
* 15.00.00.00 2013May08 CLAC29596  DL Added Complete64 struct.
* 14.10.00.01 2012Jul11 CLAC2158   DL NOTIFY EXIT64 option.
* 14.10.00.00 2012Mar25 CLAC18794  SA CAP Removal part 2 of 2.
*
*                       DR
* Revision    Date      DCR   DID Comments
* ----------- --------- ----- --- --------------------------------------
* 14.00.00.01 2010Mar16 139318 RC Remove coptypes.h and shorteh.h
*                                 dependency.
* 13.10.00.01 2009Aug14 115056 RC SAS/C to IBM/C.
* 13.01.00.00 2009Apr28 115056 AS Single-sourcing header file for
*                                 workstation and mainframe.
* 13.00.00.01 2008Jan17 90037  AS Promoted datatype of ActivityCnt
*                                 from Int32 to UInt32.
* 13.00.00.00 2007Dec11 109981 AS Update copyright message to
*                                 indicate Teradata as new owner.
* 12.00.00.00 2007Apr26 112499 AS Updated macro MAXUSERSTRLEN from
*                                 80 to 256.
* 08.02.01.00 2002Dec13 64028  SA Added TTU7.1 Copyright refs.
* 08.02.00.00 2002Oct26 58309 CSG RC210052/SMA Native 64-Bit OS Support.
*       H5_01 1998Sep24 42562 DMR Renumbered events
*       H5_00 1998Jun26 42562 DMR NOTIFY FEATURE RFC
*       H3_01 1996Jul18 36967 CME SUN compile problems
*       H3_00 1996Feb02 34578 CME 34578 add Export-like features
*
***********************************************************************/
#ifndef BTNFYEXT_H
#define BTNFYEXT_H

#ifdef __MVS__
#pragma pack(1)
#endif

#ifndef COPTYPES_H
typedef unsigned int UInt32;
typedef int          Int32;
#ifdef WIN32
typedef unsigned __int64   UInt64;
#else
typedef unsigned long long UInt64;
#endif
#endif

typedef enum
{
  /*------------------------------------------------------------------*/
  /* The following event values must not be re-numbered, so that      */
  /* old user exit functions remain compatible with newer versions    */
  /* of BTEQ.                                                         */
  /*------------------------------------------------------------------*/
  NBEventInit       =  0
, NBEventDBSRestart =  9
, NBEventCLIError   = 10
, NBEventDBSError   = 11
, NBEventExit       = 12
, NBEventReqStart   = 42
, NBEventReqDone    = 43
, NBEventFetStart   = 44
, NBEventComplete   = 45
, NBEventFetStart64 = 46
, NBEventComplete64 = 47 
} NfyBTQEvent;

#define MAXVERSIONIDLEN       32
#define MAXUTILITYNAMELEN     32
#define MAXUSERNAMELEN        64
#define MAXUSERSTRLEN        256
#define MAXTABLENAMELEN      128
#define MAXFILENAMELEN       256

typedef struct _BTNotifyExitParm
{
  Int32  Event;                       /* should be NfyBTQEvent values */
  union
  {
    struct
    {
      UInt32  VersionLen;
      char    VersionId[MAXVERSIONIDLEN];
      UInt32  UtilityId;
      UInt32  UtilityNameLen;
      char    UtilityName[MAXUTILITYNAMELEN];
      UInt32  UserNameLen;
      char    UserName[MAXUSERNAMELEN];
      UInt32  UserStringLen;
      char    UserString[MAXUSERSTRLEN];
    } Initialize;
    struct
    {
      char *  Request;
    } ReqStart;
    struct
    {
      int     dummy;                        /* for compiler pickiness */
    } ReqDone ;
    struct
    {
      Int32   RequestNo;
      Int32   StatementNo;
      UInt32  ActivityCnt;
    } FetStart ;
    struct
    {
      UInt64  RequestNo;
      UInt64  ActivityCnt;
      Int32   StatementNo;
    } FetStart64 ;
    struct
    {
      Int32   RequestCnt;
    } Complete ;
    struct
    {
      UInt64  RequestCnt;
    } Complete64 ;
    struct
    {
      Int32   dummy;
    } DBSRestart;
    struct
    {
      UInt32  ErrorCode;
    } CLIError;
    struct
    {
      UInt32  ErrorCode;
    } DBSError;
    struct
    {
      Int32   ReturnCode;
    } Exit;
  } Vals;
} BTNotifyExitParm;

#endif /* BTNFYEXT_H */

/**********************************************************************/
/* EndOfCode btnfyext.h */
/************************/
