/*************************************************************************
**************************************************************************
**
**  TITLE: CliPPs.c                                            17.20.00.00
**         User Modifiable Pre- & Post- SQL Exit Interface
**
**  Copyright 1994-2022 by Teradata Corporation.  All rights reserved.
**
**  PURPOSE      To allow user to exit while processing SQL requests
**               that are sent to a Teradata RDBMS.
**
**  DESCRIPTION  This module contains four functions, CliPreSQLExt,
**               CliPostSQLExt, CliPreSQLExt2, and CliPostSQLExt2.
**               These functions are modifiable by the user to allow 
**               control of SQL sent to Teradata RDBMS.
**
**  HISTORY
**
**       H0_00  94FEB1  KM5   Created for all platforms 
**       H0_01  94Jun09 km5   Correct CLI interface file
**       H3_00  96Feb15 JAE   Changed version to H3_00.
**       H3_01  96Mar08 SYY   Merge WinCLI 3.0 changes into mainstream
**       H3_02  96May96 TH4   Turn off the Per&Post functions.
** 04.00.00.01 96Jun28   JAE      DR36785 Version number change.
** 04.02.00.00 97July    JTH      DR40000 Merge Wincli with Unix code. 
** 04.05.00.00 2000Jan18 CSG      DR45724 CLI2 C++ safe.
** 04.06.02.00 2002Apr24 cc151010 DR61234 Add display of logsessid.
** 04.08.00.00 2003Jul22 mg180007 DR68511 clean up defines, prototypes
** 04.08.00.01 2004Jun24 mg180007 DR87347 AddedUser Exits 2
** 04.08.01.00 2005Jun06 mg180007 DR88148 Consistency updates
** 13.00.00.00 2008Jan09 mg180007 DR117140 copyright update
** 13.00.00.01 2008Feb27 mg180007 DR112838 explicit load of user exits
** 13.01.00.00 2008Dec10 kl185018 DR116607 For TTU13.1, start using AIX 5.3
**                                         Compiler to build WS CLIv2
** 15.00.00.00 2013May24 kl185018 CLAC-30909 copyright update & Version change
** 15.00.00.01 2014Jan15 kl185018 CLAC-31729 copyright update 
** 15.10.00.00 2014Apr28 mg180007 CLAC-32368 version change
** 17.00.00.00 2020Mar16 hs186016 CLIWS-7543 version change
** 17.20.00.00 2022Jan01 hs186016 CLIWS-8198 version and copyright update
**
**************************************************************************
*************************************************************************/

/************************************************************************/
/*                         INCLUDE Files                                */
/************************************************************************/
/* Standard C include files */
#include <memory.h>
#include <stdio.h>
#include <string.h>
#include <time.h>

#ifdef WIN32 /* DR68511 */
#include <nojunk.h>
#include <windows.h>            
#endif

#include <coptypes.h>
#include <coperr.h>
#include <parcel.h>
#include <cliv2if.h>

#ifdef AIX  /* DR126607 */
void dummy_CliPPS();
#endif    /* DR126607 */

/************************************************************************/
/*                         Declarations                                 */
/************************************************************************/
#if defined (CLIEXITLEVEL1) || defined (CLIEXITLEVEL2) /* DR112838 */

#ifdef WIN32          
HINSTANCE hInstTDUsr;
#endif

/* Static Declaration for User Exits */
DLLEXPORT Int32 CliPPsOn;
time_t systime;
struct tm tmtime;
Int32 New_time; 

#ifdef WIN32
/************************************************************************/ 
/* Function   DllMain                                                   */ 
/*                                                                      */ 
/* Purpose    To serve as an entry point to the DLL                     */
/*                                                                      */
/* Notes      User can modify this function                             */ 
/************************************************************************/
BOOL EXPENTRY DllMain (HINSTANCE hDLL, DWORD dwReason, LPVOID lpReserved)
{
    switch (dwReason)
    {
    case DLL_PROCESS_ATTACH:
        hInstTDUsr = hDLL;
        break;
    case DLL_THREAD_ATTACH:
    case DLL_THREAD_DETACH:
    case DLL_PROCESS_DETACH:
        break;
    }
    return TRUE;
}
#endif /* WIN32 */

#endif /* CLIEXITLEVEL1 or CLIEXITLEVEL2 *//* DR112838 */

#ifdef CLIEXITLEVEL1 /* DR112838 */
/************************************************************************/
/* Function   CliPreSQLExt                                              */
/*                                                                      */
/* Purpose    To allow Pre SQL process cotrol by User connected to a    */
/*            RDBMS                                                     */
/*                                                                      */
/* Parameters pUExit - pointer to the CliPreSQLExit structure.          */
/*            result - returned error code for this function.           */
/*                                                                      */
/* Returns    EM_OK or SQLUSREXT on error                               */
/*                                                                      */
/* Notes      User can modify this function                             */
/************************************************************************/
/* This sample function will do the following:                          */
/* 1) filter out (stop from being sent to the RDBMS) erroneous commands */
/*    "selSQL time" and "selectSQL time"                                */
/* 2) get a time stamp of the SQL request being sent to the RDBMS       */
/* 3) replace "sel change" command with "select date;"                  */
/************************************************************************/
Int32 CliPreSQLExt(struct CliPreSQLExit *pUExit) /* DR68511 */
{
    /*************************************************************/
    /* CliPPsOn is a internal CLI variable that is initially     */
    /* set to TRUE to execute the CliPreSQLExt and CliPostSQLExt */
    /* functions.  Set the variable to FALSE will turn off the   */
    /* Pre&Post functions. In other words, CLI will not call the */
    /* CliPreSQLExt and CliPostSQLExt functions when CliPPsOn is */
    /* set to FALSE. Do NOT set this variable to FALSE if you    */
    /* want to execute the CliPreSQLExt and CliPostSQLExt        */
    /* functions.                                                */
    /*************************************************************/
    CliPPsOn = FALSE;

    /*** Uncomment next line to compile sample code ***/
    /* #define SAMPLE_PRE */
#ifdef SAMPLE_PRE   
    if (strstr(pUExit->SQL_Request_ptr, "selSQL time") ||
        strstr(pUExit->SQL_Request_ptr, "selectSQL time"))
    {
#ifdef WIN32 /* DR68511 */
        MessageBox((HWND) NULL, "*** SQL command not allowed SEE Sys Admin ***", "CLI Error", MB_OK);
#else
        printf("*** SQL command not allowed SEE Sys Admin ***\n");
#endif
        return(SQLUSREXT);
    }

    /* Otherwise setup to get elapsed time for request */             
    pUExit->Process_Post = TRUE;

    /* Example to change SQL do not exceed 8096 bytes */
    /* for UNIX platforms, or 1024 bytes for PC based */
    if (strstr(pUExit->SQL_Request_ptr, "sel change"))
    {
        memset(pUExit->SQL_Request_ptr, 0, 1024);
        memcpy(pUExit->SQL_Request_ptr, "select date;", 12);
        *pUExit->SQL_len_ptr = 12;
    }

    systime = time(NULL);
    tmtime  = *localtime(&systime);
    pUExit->Clock_time = tmtime.tm_sec;

    strftime( pUExit->Start_date, sizeof(pUExit->Start_date),
        " %H:%M on %A the %d of %B, %Y ", &tmtime);
#endif /* SAMPLE_PRE */
    return(EM_OK);
} /* CliPreSQLExt() */


/************************************************************************/ 
/* Function   CliPostSQLExt                                             */ 
/*                                                                      */ 
/* Purpose    To allow Post SQL process of request sent to the RDBMS    */
/*                                                                      */
/* Parameters CliSQLPostPtr - pointer to the CliPostSQLExit structure   */
/*                                                                      */ 
/* Returns    None                                                      */
/*                                                                      */
/* Notes      User can modify this function                             */ 
/************************************************************************/
/* This sample function will print out some of the data passed to the   */
/* user exit                                                            */
/************************************************************************/
void CliPostSQLExt (struct CliPostSQLExit *CliSQLPostPtr) /* DR68511 */
{
    /*** Uncomment next line to compile sample code ***/
    /* #define SAMPLE_POST */
#ifdef SAMPLE_POST

#ifdef WIN32 /* DR68511 */
    char tmpstr[305];
    sprintf(tmpstr,"CliSQLPostPtr->dbcname=%s\n CliSQLPostPtr->username=%s\n CliSQLPostPtr->password=%s\n CliSQLPostPtr->account=%s\n CliSQLPostPtr->Start_date=%s\n CliSQLPostPtr->logsessid=%d\n",
        CliSQLPostPtr->dbcname,
        CliSQLPostPtr->username,
        CliSQLPostPtr->password,
        CliSQLPostPtr->account,
        CliSQLPostPtr->Start_date,
        CliSQLPostPtr->logsessid);
    MessageBox((HWND) NULL, tmpstr, "Request Parameters", MB_OK);
    MessageBox((HWND) NULL, CliSQLPostPtr->SQL_Request_ptr, "SQL Request", MB_OK);
#else  /* WIN32 */
    printf("CliSQLPostPtr->SQL_Request_ptr=%s\n",CliSQLPostPtr->SQL_Request_ptr); 
    printf("CliSQLPostPtr->dbcname=%s\n",CliSQLPostPtr->dbcname); 
    printf("CliSQLPostPtr->username=%s\n",CliSQLPostPtr->username);
    printf("CliSQLPostPtr->password=%s\n",CliSQLPostPtr->password);
    printf("CliSQLPostPtr->account=%s\n",CliSQLPostPtr->account); 
    printf("CliSQLPostPtr->Start_date=%s\n",CliSQLPostPtr->Start_date); 
    printf("CliSQLPostPtr->logsessid=%d\n",CliSQLPostPtr->logsessid); 
#endif /* WIN32 */

    systime = time(NULL);
    tmtime  = *localtime(&systime);
    CliSQLPostPtr->Clock_time = tmtime.tm_sec - CliSQLPostPtr->Clock_time;

#ifdef WIN32 /* DR68511 */
    sprintf(tmpstr,"CliSQLPostPtr->Clock_time=%d\n",CliSQLPostPtr->Clock_time);
    MessageBox((HWND) NULL,tmpstr,"SQL Request", MB_OK);
#else  /* WIN32 */
    printf("CliSQLPostPtr->Clock_time=%d\n",CliSQLPostPtr->Clock_time);
#endif /* WIN32 */

#endif /* SAMPLE_POST */ 
    return;
} /* CliPostSQLExt() */

#endif /* CLIEXITLEVEL1 *//* DR112838 */

#ifdef CLIEXITLEVEL2 /* DR112838 */

/* DR87347 -> */
/************************************************************************/
/* Function   CliPreSQLExt2                                             */
/*                                                                      */
/* Purpose    To allow Pre SQL process cotrol by User connected to the  */
/*            RDBMS                                                     */
/*                                                                      */
/* Parameters CliSQLExit2_p pCUE2                                       */
/*                                                                      */
/* Returns    EM_OK or SQLUSREXT on error                               */
/*                                                                      */
/* Notes      User can modify this function                             */
/************************************************************************/
/* This sample function will do the following:                          */
/* 1) filter out (stop from being sent to RDBMS) erroneous commands     */
/*    "hello;" and "good bye;"                                          */
/* 2) replace SQL command "sel date;" with "sel time;" and vice versa   */
/* 3) time the request and returned time stamp information in the       */
/*    appropriate structure                                             */
/************************************************************************/

Int32 CliPreSQLExt2(CliSQLExit2_p pCUE2) /* DR68511 */
{
    /* set CliPPsOn to FALSE to prevent CLI from calling this function */
    CliPPsOn = FALSE;

    /*** Uncomment next line to compile sample code ***/
    /* #define SAMPLE_PRE */
#ifdef SAMPLE_PRE
    if (strstr(pCUE2->SQL_Request_ptr, "hello;") ||
        strstr(pCUE2->SQL_Request_ptr, "good bye;"))
    {
#ifdef WIN32 /* DR68511 */
        MessageBox((HWND) NULL,"*** SQL command not allowed SEE Sys Admin ***", "CLI Error", MB_OK);
#else
        printf("*** SQL command not allowed SEE Sys Admin ***\n");
#endif
        return(SQLUSREXT);
    }

    /* Otherwise setup to get elapsed time for request */             
    pCUE2->Process_Post = TRUE;

    /* Example to change SQL do not exceed 8096 bytes */
    /* for UNIX platforms, or 1024 bytes for PC based */
    if (strstr(pCUE2->SQL_Request_ptr, "sel date;"))
    {
        memset(pCUE2->SQL_Request_ptr, 0, 1024);
        memcpy(pCUE2->SQL_Request_ptr, "sel time;", 9);
        *pCUE2->SQL_len_ptr = 9;
    } 
    else if (strstr(pCUE2->SQL_Request_ptr, "sel time;"))
    {
        memset(pCUE2->SQL_Request_ptr,0,1024);
        memcpy(pCUE2->SQL_Request_ptr, "sel date;", 9);
        *pCUE2->SQL_len_ptr = 9;
    }

    systime = time(NULL);
    tmtime  = *localtime(&systime);
    pCUE2->Clock_time = tmtime.tm_sec;

    strftime(pCUE2->Start_date, sizeof(pCUE2->Start_date),
        " %H:%M on %A the %d of %B, %Y ", &tmtime);
#endif /* SAMPLE_PRE */
    return(EM_OK);
} /* CliPreSQLExt2() */

/************************************************************************/ 
/* Function   CliPostSQLExt2                                            */ 
/*                                                                      */ 
/* Purpose    To allow Post SQL process of request sent to the RDBMS    */
/*                                                                      */
/* Parameters CliSQLExit2_p pCUE2                                       */
/*                                                                      */ 
/* Returns    None                                                      */
/*                                                                      */
/* Notes      User can modify this function                             */ 
/************************************************************************/
/* This sample function will print out some of the data passed to the   */
/* user exit                                                            */
/************************************************************************/
void CliPostSQLExt2(CliSQLExit2_p pCUE2) /* DR68511 */
{
    /*** Uncomment next line to compile sample code ***/
    /* #define SAMPLE_POST */
#ifdef SAMPLE_POST

#ifdef WIN32 /* DR68511 */
    char tmpstr[305];
    sprintf(tmpstr,"pCUE2->opts.dbcname=%s\n pCUE2->opts.username=%s\n pCUE2->opts.password=%s\n pCUE2->opts.account=%s\n pCUE2->opts.Start_date=%s\n pCUE2->opts.logsessid=%d\n",
        pCUE2->opts.dbcname,
        pCUE2->opts.username,
        pCUE2->opts.password,
        pCUE2->opts.account,
        pCUE2->Start_date,
        pCUE2->logsessid);
    MessageBox((HWND) NULL, tmpstr, "Request Parameters", MB_OK);
    MessageBox((HWND) NULL, pCUE2->SQL_Request_ptr, "SQL Request", MB_OK);
#else  /* WIN32 */
    printf("pCUE2->SQL_Request_ptr=%s\n",pCUE2->SQL_Request_ptr); 
    printf("pCUE2->opts.dbcname=%s\n",pCUE2->opts.dbcname); 
    printf("pCUE2->opts.username=%s\n",pCUE2->opts.username);
    printf("pCUE2->opts.password=%s\n",pCUE2->opts.password);
    printf("pCUE2->opts.account=%s\n",pCUE2->opts.account); 
    printf("pCUE2->Start_date=%s\n",pCUE2->Start_date); 
    printf("pCUE2->logsessid=%d\n",pCUE2->logsessid); 
#endif /* WIN32 */

    systime = time(NULL);
    tmtime  = *localtime(&systime);
    pCUE2->Clock_time = tmtime.tm_sec - pCUE2->Clock_time;

#ifdef WIN32 /* DR68511 */
    sprintf(tmpstr, "pCUE2->Clock_time=%d\n", pCUE2->Clock_time);
    MessageBox((HWND) NULL,tmpstr,"SQL Request", MB_OK);
#else  /* WIN32 */
    printf("pCUE2->Clock_time=%d\n", pCUE2->Clock_time);
#endif /* WIN32 */

#endif /* SAMPLE_POST */ 
    return;
} /* CliPostSQLExt2() */
/* <- DR87347 */

#endif /* CLIEXITLEVEL2 *//* DR112838 */

#ifdef AIX  /* DR126607 */
void dummy_CliPPS()
{
}
#endif    /* DR126607 */

/************************************************************************/
/*                    End of CliPPS.c File                              */
/************************************************************************/
