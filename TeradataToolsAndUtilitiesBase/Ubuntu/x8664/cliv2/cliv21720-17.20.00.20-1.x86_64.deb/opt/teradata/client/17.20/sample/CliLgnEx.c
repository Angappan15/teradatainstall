/*************************************************************************
**************************************************************************
**
**  TITLE: CliLgnEx.c                                          17.20.00.00
**         User Modifiable Logon Exit Interface
**
**  Copyright 1993-2022 by Teradata Corporation.  All rights reserved.
**
**  PURPOSE      To allow user to exit while logging on if needed.
**
**  DESCRIPTION  This module contains two functions, CliUsrLgnExt and
**               CliUsrLgnExt2, that are modifiable to allow users to
**               exit during connection to Teradata RDBMS.
**
**  HISTORY
**               G0_01  93JAN12 BG1   Created for all platforms
**               G0_02  94Mrch2 BG1   Removed the default settings
**               G0_03  94Mch24 BG1   Changed the error code # due
**                                    to 2PC error code conflict.
**               G0_04  94Apr22 Bg1   Shorten the file name for pc
**                                    compatibility.
**               H0_00  94Jun09 Km5   Correct include file version
**               H0_01  94Jun21 msc/km5 sample code and header correction
**               H0_02  94Jul15 TSL/TL1 modified sample code
**               H3_00  96Feb15 JAE   Changed version to H3_00.
**               H3_01  96Mar08 SYY   Merge WinCLI 3.0 changes into mainstream.
**               H3_02  96Mayo6 TH4   Turn off the User Exit logon function.
** 04.00.00.01 96Jun28   JAE      DR36785 Version number change.
** 04.02.00.00 97July    JTH      DR40000 merge Wincli with Unix code.
** 04.05.00.00 2000Jan18 CSG      DR45724 CLI2 C++ safe.
** 04.08.00.00 2003Jul22 mg180007 DR68511 clean up defines, prototypes
** 04.08.00.01 2004Jun24 mg180007 DR87347 Added User Exit 2
** 04.08.01.00 2005Jun06 mg180007 DR88148 Consistency updates
** 13.00.00.00 2008Jan09 mg180007 DR117140 copyright update
** 13.00.00.01 2008Feb27 mg180007 DR112838 explicit load of user exits
** 13.01.00.00 2008Dec10 kl185018 DR116607 For TTU13.1, start using AIX 5.3
**                                         Compiler to build WS CLIv2
** 15.00.00.00 2013May24 kl185018 CLAC-30909 copyright update & Version change
** 15.00.00.01 2014Jan15 kl185018 CLAC-31729 copyright update
** 15.10.00.00 2014Apr28 mg180007 CLAC-32368 version change
** 17.00.00.00 2019Apr02 hs186016 CLIWS-7241 Add tdusr32.lib to Windows CLIv2 SDK
** 17.00.00.01 2020Mar23 hs186016 CLIWS-7536 Update CliLgnEx.c due to BTEQ-10347
**                                           Refer to Notes in CliUserLgnExt()
** 17.20.00.00 2022Jan01 hs186016 CLIWS-8198 version and copyright update
**
**************************************************************************
*************************************************************************/

/************************************************************************/
/*                         INCLUDE Files                                */
/************************************************************************/
#include <string.h>
#include <stdio.h>
#include <coptypes.h>
#include <parcel.h>
#include <cliv2if.h>
#include <coperr.h>

#ifdef AIX  /* DR126607 */
void dummy_CliLgnEx();
#endif    /* DR126607 */

#ifdef WIN32  /* CLIWS-7241 */
DLLEXPORT Int32 DummyCliUsrLgnEx;
#endif

/************************************************************************/
/*                         Declarations                                 */
/************************************************************************/
#if defined (CLIEXITLEVEL1) || defined (CLIEXITLEVEL2) /* DR112838 */
DLLEXPORT Int32 CliUsrLgnOn;
#endif /* CLIEXITLEVEL1 or CLIEXITLEVEL2 *//* DR112838 */

#ifdef CLIEXITLEVEL1 /* DR112838 */
/************************************************************************/
/* Function   CliUsrLgnExt                                              */
/*                                                                      */
/* Purpose    to perform a user-specific task during CLI connection     */
/*            to the RDBMS                                              */
/*                                                                      */
/* Parameters Adrrs - pointer to the CliExit structure.                 */
/*                                                                      */
/* Returns    EM_OK                                                     */
/*                                                                      */
/* Notes   1. User can modify this function                             */
/*         2. BTEQ-10347: for BTEQ 16.20.00.07 or later                 */
/*            In interactive mode only, username and password can be    */
/*            enclosed by double quotes.                                */
/************************************************************************/
/* This sample function will do the following:                          */
/* 1) if tdpid is "test1", change it to "testdbc"                       */
/* 2) if the userid is "clitst" and the password is blank, set the      */
/*    password to "clitst"                                              */
/************************************************************************/

Int32 CliUsrLgnExt(struct CliExit *Adrrs) /* DR68511 */
{
    Int32 result = EM_OK;
    /*************************************************************/
    /* CliUsrLgnOn is a internal CLI variable that is initially  */
    /* set to TRUE to execute the CliPreSQLExt and CliPostSQLExt */
    /* functions.  Set the variable to FALSE will turn off the   */
    /* Pre&Post functions. In other words, CLI will not call the */
    /* CliPreSQLExt and CliPostSQLExt functions when CliUsrLgnOn */
    /* is set to FALSE. Do NOT set this variable to FALSE if you */
    /* want to execute the CliPreSQLExt and CliPostSQLExt        */
    /* functions.                                                */
    /*************************************************************/
    CliUsrLgnOn = FALSE;

    /*** Uncomment next line to compile sample code ***/
    /* #define SAMPLE */
#ifdef SAMPLE
    if (!strcmp(Adrrs->dbcname, "test1"))
        strcpy(Adrrs->dbcname, "testdbc");
    /* Addrrs->username can have surrounding double quotes: BTEQ-10347, CLIWS-7536 */
    if ((!strcmp(Adrrs->username, "clitst") || !strcmp(Adrrs->username, "\"clitst\"")) &&
        (Adrrs->password[0] == '\0'))
        strcpy(Adrrs->password, "clitst");
#endif /* SAMPLE */
    return(result);
}

#endif /* CLIEXITLEVEL1 *//* DR112838 */

#ifdef CLIEXITLEVEL2 /* DR112838 */

/************************************************************************/
/* Function   CliUsrLgnExt2                                             */
/*                                                                      */
/* Purpose    to perform user specific task during CLIv2 connection     */
/*            to a RDBMS                                                */
/*                                                                      */
/* Parameters CliLgnExit2_p pCUE2                                       */
/*                                                                      */
/* Returns    The error code for this function                          */
/*                                                                      */
/* Notes   1. User can modify this function                             */
/*         2. BTEQ-10347: for BTEQ 16.20.00.07 or later                 */
/*            In interactive mode only, username and password can be    */
/*            enclosed by double quotes.                                */
/************************************************************************/
/* This sample function will do the following:                          */
/* 1) if tdpid is "test1", change it to "testdbc"                       */
/* 2) if the userid is "clitst" and the password is blank, set the      */
/*    password to "clitst"                                              */
/************************************************************************/

Int32 CliUsrLgnExt2(CliLgnExit2_p pCUE2)
{
    Int32 result = EM_OK;
    /* set CliUsrLgnOn to FALSE to prevent CLI from calling this function */
    CliUsrLgnOn = FALSE;

    /*** Uncomment next line to compile sample code ***/
    /* #define SAMPLE */
#ifdef SAMPLE
    if (!strcmp(pCUE2->opts.dbcname, "test1") &&
        pCUE2->opts.dbcname_max_len >= 7)
    {
        strcpy(pCUE2->opts.dbcname, "testdbc");
        pCUE2->opts.dbcname_actual_len = 7;
    }
    /* Addrrs->username can have surrounding double quotes: BTEQ-10347, CLIWS-7536 */
    if ((!strcmp(pCUE2->opts.username, "clitst") || !strcmp(pCUE2->opts.username, "\"clitst\"")) &&
        (pCUE2->opts.password[0] == '\0' && pCUE2->opts.password_max_len >= 6))
    {
        strcpy(pCUE2->opts.password, "clitst");
        pCUE2->opts.password_actual_len = 6;
    }
#endif /* SAMPLE */
    return(result);
} /* CliUsrLgnExt2() */

#endif /* CLIEXITLEVEL2 *//* DR112838 */

#ifdef AIX  /* DR126607 */
void dummy_CliLgnEx()
{
}
#endif    /* DR126607 */

/************************************************************************/
/*                    End of CliLgnEx.c File                            */
/************************************************************************/
