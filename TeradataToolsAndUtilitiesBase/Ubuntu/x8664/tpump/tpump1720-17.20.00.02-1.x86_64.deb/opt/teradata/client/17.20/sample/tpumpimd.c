/************************************************************************
*                                                                       *
* TITLE: tpumpimd.c                                                     *
*                                                                       *
* Copyright 1997-2008 Teradata Corporation.                             *       
* ALL RIGHTS RESERVED.                                                  *
* Teradata Corporation CONFIDENTIAL AND TRADE SECRET                    *
*                                                                       *
* This copyrighted material is the Confidential, Unpublished            *
* Property of the Teradata Corporation.  This copyright notice and      *
* any other copyright notices included in machine readable              *
* copies must be reproduced on all authorized copies.                   *
*                                                                       *
* PURPOSE: Sample 'inmod.c' TPump inmod on MP-RAS UNIX platform.        *
*                                                                       *
* History Information                                                   *
*                                                                       *
* Revision    Date     DR     DID     Comments                          *
* ----------- -------- ------ ------- --------------------------------- *
* 13.00.00.00 10/15/07 115451 YY151   Teradata Copyright                *
* 01.00.00.00 09/04/97 38436  CME     Need example inmod                *
* 01.01.00.01 07/06/98 42677  SNT     Rename inmod.c to tpumpimd.c.     *
*                                                                       *
*************************************************************************
 Notes: 
   This program is for INMOD testing using C user exit routine.
   When this routine is activated it looks at the content of the
   function code passed (a->code) and depending on its value, it
   0) initializes, i.e., opens a file, etc...
   1) reads a record
   5) acknowledges "close inmod" request.  The user exit routine
must return "return code"(a->code)  and "length" (a->len). You
should send return code = zero when no errors occur and non-zero for
an error. LOAD expects length = zero at the end of file. Then
it sends "CLOSE INMOD" request. THE USER EXIT routine must
explicitly return "return code" = ZERO to terminate the
conversation.

The following TPUMP control statements will work with this inmod:

.LOGTABLE <logtable>;
.LOGON <logon>;

DROP TABLE TABLE200;
DROP TABLE ET_TABLE200;
CREATE TABLE TABLE200 (
       X1 integer,
       x2 char(76)
);

.BEGIN LOAD SESSIONS 4
    ERRORTABLE ET_TABLE200;

.LAYOUT TABLE200;

.FIELD x1                 1  integer nullif x1 = 5;
.FIELD x2                 *  char(6)  nullif x1 = 4;
.FIELD x3                 *  char(10) nullif x1 = 4;
.FIELD x4                 *  char(10) nullif x1 = 4;
.FIELD x5                 *  char(10) nullif x1 = 4;
.FIELD x6                 *  char(10) nullif x1 = 4;
.FIELD x7                 *  char(10) nullif x1 = 4;
.FIELD x8                 *  char(10) nullif x1 = 4;
.FIELD x9                 *  char(5) nullif x1 = 4;
.FIELD x10                *  char(5) nullif x1 = 4;

.DML LABEL A;

INSERT INTO TABLE200 VALUES
(
 :x1
,:x2
);

.IMPORT INMOD <inmodname>
        LAYOUT TABLE200
        APPLY A FROM 1 THRU 100;

.END LOAD ;
.LOGOFF;

************************************************************************/
#include <stddef.h>                                                             
#include <stdlib.h>                                                             
#include <stdio.h>                                                              
typedef unsigned short     Int16;                                               
typedef unsigned char      Int8;                                                
typedef unsigned long int  Int32;                                               
                                                                                
/* PASSING parameter structures                                                 
*/                                                                              
                                                                                
typedef struct {                                                                
    Int32 code;                                                                 
    Int32 len;                                                                  
    struct {                                                                    
      int seqno;                                                                
    Int8  body[80];                                                             
    } buf;                                                                      
} inmodbuf;                                                                     
                                                                                
typedef struct {                                                                
    Int32 seq;                                                                  
    Int16 len;                                                                  
    char  param[80];                                                            
} inmodpty;                                                                     
                                                                                
  static int count=0;                                                           
  char *memcpy();                                                               
                                                                                
void _dynamn(a,b)                                                               
inmodbuf *a;                                                                    
inmodpty *b;                                                                    
{int code=0;                                                                    
                                                                                
/*printf("BEGIN--> %d  %d  %s\n",a->code,a->len,tempbuf);          */           
/*printf("     +++ %d  %d  %s\n",b->seq ,b->len,b->param);          */          
                                                                                
  code= (int) a->code;                                                          
  switch (code) {                                                               
   case 0:                                                                      
    /* Here you open the file and read the first record */                      
 /* printf("## CODE=0, openinig...\n"); */                                      
    count = 0;                                                                  
    if (! readrecord(a))                                                        
       printf("Messed up in open.\n");                                          
    break;                                                                      
   case 1:                                                                      
    /* Utility requested next record, read it */                                
/*  printf("## CODE=1, reading...\n");  */                                      
    if (! readrecord(a))                                                        
       printf("Messed up in read.\n");                                          
    break;                                                                      
   case 5:                                                                      
    /* Utility is closing INMOD routine */                                      
    a->code=0;                                                                  
    a->len=0;                                                                   
 /* printf("## CODE=5, terminating...\n"); */                                   
    break;                                                                      
   default:                                                                     
    a->code=12; /* any number not = to zero */                                  
    a->len=0;                                                                   
    printf("##### UNKNOWN code ######\n");a->code=0;a->len=0;                   
  };                                                                            
                                                                                
/*printf("END  --> %d  %d  %s\n",a->code,a->len,tempbuf); */                    
/*printf("     +++ %d  %d  %s\n",b->seq ,b->len,b->param);*/                    
}                                                                               
                                                                                
                                                                                
static int readrecord(a)                                                        
inmodbuf *a;                                                                    
{                                                                               
 int rtn=0;                                                                     
 int i=0;                                                                       
     if (count < 50000)                                                         
     {                                                                          
        a->buf.seqno = count;                                                   
        count++;                                                                
        for (i=0; i<75; i++) a->buf.body[i] = 'X';                              
        a->buf.body[75] = '\0';                                                 
                                                                                
        a->len=80;                                                              
        a->code=0;                                                              
        rtn=1;                                                                  
     }                                                                          
     else                                                                       
     {                                                                          
        printf("=== EOF ===\n");                                                
        a->code=99;                                                             
        a->len=0;                                                               
     };                                                                         
     return(rtn);                                                               
}                                                                               
