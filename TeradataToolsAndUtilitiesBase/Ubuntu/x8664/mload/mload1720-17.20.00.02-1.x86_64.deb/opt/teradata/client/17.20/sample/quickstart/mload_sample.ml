.LOGTABLE mylogtbale;
.LOGON NODEID/Username,UserPassword;

/*************************************************/
/* Drop tables                                   */
/*************************************************/
DROP TABLE mytesttbl;
DROP TABLE wt_mytesttbl;
DROP TABLE et_mytesttbl;
DROP TABLE uv_mytesttbl;

/*************************************************/
/* Create table                                  */
/*************************************************/

CREATE MULTISET TABLE mytesttbl, FALLBACK (
  c1 varchar(5),
  c2 varchar(5))
 PRIMARY INDEX(C1);
.BEGIN MLOAD TABLES mytesttbl;

.LAYOUT lay1a;
.FIELD c1  *  varchar(5) ;
.FIELD c2  *  varchar(5) ;
.DML LABEL labela;
INSERT INTO mytesttbl VALUES (:c1,:c2);
.IMPORT INFILE mload_data
               FORMAT VARTEXT '|'  
               LAYOUT lay1a
               APPLY  labela;

.END MLOAD;
.LOGOFF;
