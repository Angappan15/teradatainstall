/***************************************************************************
 *
 * TITLE: mldnfyxt.c .... an example notify exit...                  
 *
 *  Purpose       As a test and an example for users.
 *
 * Copyright 1990-2013 Teradata Corporation.
 * ALL RIGHTS RESERVED.
 * Teradata Corporation CONFIDENTIAL AND TRADE SECRET
 *
 * This copyrighted material is the Confidential, Unpublished
 * Property of the Teradata Corporation.  This copyright notice and
 * any other copyright notices included in machine readable
 * copies must be reproduced on all authorized copies.
 *
 *  Description   stuff for notify.
 *
 *  Notes         1) should probably include "mldnfyxt.h"
 *                2) the procedure must be called "_dynamn"
 *
 * History Information
 *                                                                       
 * Revision    Date     Issue    DID      Comments                       
 * ----------- -------- -------- -------- ------------------------------ 
 * 15.00.00.01 03212013 SA-29992 YY151001 14.10 and 15.0 Notify issue  
 * 15.00.00.00 02272013 SA-29733 YY151001 Fix DR112037                   
 *                                                                       
 * Revision    Date     DR     DID      Comments                           
 * ----------- -------- ------ -------- --------------------------------
 * 14.00.00.00 12032010 141944 XX151    Support 8 byte counter
 * 13.01.00.01 09152008 123961 YY151    Modify ML delete intialize event   
 * 13.01.00.00 09102008 110009 XX151000 Migrate from SAS/C to IBM/C  
 * 13.00.00.01 09052007 115449 XX151000 Copyright changes           
 * 13.00.00.00 09012007 100763 SV185048 Visual Studio 8.0 build           
 * 07.08.00.01 10052005 96203 CSG     Port to HP-UX Itanium 
 * 07.07.00.01 05182004 69016 YY151   Back out DR69016
 * 07.07.00.00 12222003 69016 YY151   Change 'RDBMS'/'DBS' to 
 *                                    'Teradata Database'
 * 07.06.00.01 08132001 56477 CSG     Corrected edit tag         
 * 07.06.00.00 07312001 56477 CSG     Port exit routine to WIN32
 * 07.05.00.00 03132001 53286 CSG     Port MLOAD to HP-UX
 * 07.02.00.00 06221998 42570 SFD     Update NOTIFY EXIT interface     
 *
 *  History       H3_00  95Oct29  CME  DR 34581 add Export-like features
 *
 ***************************************************************************/
/* DR110009 ==> */
#ifdef __MVS__
#pragma pack(1)
#endif
/* <== DR110009 */
#include <stdio.h>
typedef unsigned int UInt32;                    /* DR53286                */
typedef int Int32;                              /* DR96203                */

#include "mldnfyxt.h"
#ifdef WIN32                                    /* Change for WIN32 DR56477*/
__declspec(dllexport) Int32 _dynamn(MLNotifyExitParm *P) 
                                  /*DR96203*//*DR56477*/
#else                                                             /*DR56477*/
Int32 _dynamn( MLNotifyExitParm *P)   /*DR96203*/                   
#endif                                                            /*DR56477*/
{
    FILE *fp;
 
    if (!(fp = fopen("NFYEXIT.OUT", "a")))
        return(1);
 
    switch(P->Event) {
    case NMEventInitialize :   /* Nothing */
        fprintf(fp, "exit called @ mload init.\n");
        fprintf(fp, "Version: %s\n", P->Vals.Initialize.VersionId);
        fprintf(fp, "Utility: %s\n", P->Vals.Initialize.UtilityName);
        fprintf(fp, "User: %s\n", P->Vals.Initialize.UserName);
        if (P->Vals.Initialize.UserStringLen)
           fprintf(fp, "UserString: %s\n", P->Vals.Initialize.UserString);
        break;

    case NMEventFileInmodOpen:
        fprintf(fp, "exit called @ file open: import[%d]: %s\n",
                P->Vals.FileInmodOpen.ImportNo,
                P->Vals.FileInmodOpen.FileOrInmodName);
        break;                                                   /*DR56477*/

    case NMEventPhaseIBegin :
        fprintf(fp, "exit called @ acquistion start: Databasename : %s.\n",
            P->Vals.PhaseIBegin.DBaseName);                     /*SA-29733*/
        fprintf(fp, "exit called @ acquistion start: tablename[%d] : %s.\n",
            P->Vals.PhaseIBegin.TableNo,
            P->Vals.PhaseIBegin.TableName);
        break;

    case NMEventCheckPoint :
        fprintf(fp, "exit called @ checkpoint : %d records loaded.\n",
                P->Vals.CheckPoint.RecordCount);
        break;
 
    case NMEventPhaseIEnd :
        fprintf(fp, "exit called @ acquistion end.\n");
        fprintf(fp, "Records Read: %d\n", P->Vals.PhaseIEnd.RecsRead);
        fprintf(fp, "Records Skipped: %d\n", P->Vals.PhaseIEnd.RecsSkipped);
        fprintf(fp, "Records Rejected: %d\n", P->Vals.PhaseIEnd.RecsRejected);
        fprintf(fp, "Records Sent: %d\n", P->Vals.PhaseIEnd.RecsSent);
        break;
 
    case NMEventPhaseIIBegin :
        fprintf(fp, "exit called @ application start\n");
        break;

    case NMEventPhaseIIEnd :
        fprintf(fp, "exit called @ application complete for table %d.\n",
                P->Vals.PhaseIIEnd.TableNo);
        fprintf(fp, "%d updates, %d inserts, %d deletes\n",
                P->Vals.PhaseIIEnd.Updates,
                P->Vals.PhaseIIEnd.Inserts,
                P->Vals.PhaseIIEnd.Deletes);
        break;

    case NMEventErrorTableI :
        fprintf(fp, 
               "exit called @ ET Table[%d] Drop : %d records in table.\n",
                P->Vals.ErrorTableI.TableNo, P->Vals.ErrorTableI.Rows);
        break;

    case NMEventErrorTableII :
        fprintf(fp, 
               "exit called @ UV Table[%d] Drop : %d records in table.\n",
                P->Vals.ErrorTableII.TableNo, P->Vals.ErrorTableII.Rows);
        break;

    case NMEventDBSRestart :
        fprintf(fp, "exit called @ RDBMS restarted\n");
        break;

    case NMEventCLIError :
        fprintf(fp, "exit called @ CLI error %d\n",
                P->Vals.CLIError.ErrorCode);
        break;

    case NMEventDBSError :
        fprintf(fp, "exit called @ DBS error %d\n",
                P->Vals.DBSError.ErrorCode);
        break;
 
    case NMEventExit :
      fprintf(fp, "exit called @ mload notify out of scope: return code %d.\n",
                P->Vals.Exit.ReturnCode);
        break;

    case NMEventAmpsDown :
        fprintf(fp, "exit called @ down amps have been detected\n");
        break;

    case NMEventImportBegin :
        fprintf(fp, "exit called @ import %d starting\n",
                P->Vals.ImportBegin.ImportNo);
        break;

    case NMEventImportEnd :
        fprintf(fp, "exit called @ import %d ending.\n",
                     P->Vals.ImportEnd.ImportNo);
        fprintf(fp, "Records Read: %d\n", P->Vals.ImportEnd.RecsRead);
        fprintf(fp, "Records Skipped: %d\n", P->Vals.ImportEnd.RecsSkipped);
        fprintf(fp, "Records Rejected: %d\n", P->Vals.ImportEnd.RecsRejected);
        fprintf(fp, "Records Sent: %d\n", P->Vals.ImportEnd.RecsSent);
        break;
 
    case NMEventDeleteInit : /* DR123961 */
        fprintf(fp, "exit called @ mload delete init.\n");
        fprintf(fp, "Version: %s\n", P->Vals.DeleteInit.VersionId);
        fprintf(fp, "Utility: %s\n", P->Vals.DeleteInit.UtilityName);
        fprintf(fp, "User: %s\n", P->Vals.DeleteInit.UserName);
        if (P->Vals.DeleteInit.UserStringLen)
           fprintf(fp, "UserString: %s\n", P->Vals.DeleteInit.UserString);
        break;

    case NMEventDeleteBegin :
        fprintf(fp, "exit called @ delete app start: Databasename : %s.\n",
            P->Vals.DeleteBegin.DBaseName);                     /*SA-29992*/
        fprintf(fp, "exit called @ delete app start for table[%d]: %s.\n",
                P->Vals.DeleteBegin.TableNo, P->Vals.DeleteBegin.TableName);
        break;
 
    case NMEventDeleteEnd :
        fprintf(fp, "exit called @ delete app done for table[%d]: %d rows.\n",
                P->Vals.DeleteEnd.TableNo, P->Vals.DeleteEnd.Deletes);
        break;

    case NMEventDeleteExit :
fprintf(fp, "exit called @ mload delete notify out of scope: return code %d.\n",
                P->Vals.DeleteExit.ReturnCode);
        break;

    /*SA-29992==>*/
    case NMEventInitializeEON :   /* Nothing */
        fprintf(fp, "exit called @ mload init.\n");
        fprintf(fp, "Version: %s\n", P->Vals.InitializeEON.VersionId);
        fprintf(fp, "Utility: %s\n", P->Vals.InitializeEON.UtilityName);
        fprintf(fp, "User: %s\n", P->Vals.InitializeEON.UserName);
        if (P->Vals.InitializeEON.UserStringLen)
           fprintf(fp, "UserString: %s\n", P->Vals.InitializeEON.UserString);
        break;

    case NMEventPhaseIBeginEON :
        fprintf(fp, "exit called @ acquistion start: Databasename : %s.\n",
            P->Vals.PhaseIBeginEON.DBaseName);                     /*SA-29733*/
        fprintf(fp, "exit called @ acquistion start: tablename[%d] : %s.\n",
            P->Vals.PhaseIBeginEON.TableNo,
            P->Vals.PhaseIBeginEON.TableName);
        break;

    case NMEventCheckPoint64 :
        fprintf(fp, "exit called @ checkpoint : %s records loaded.\n",
                P->Vals.CheckPoint64.RecordCount);
        break;
 
    case NMEventPhaseIEnd64 :
        fprintf(fp, "exit called @ acquistion end.\n");
        fprintf(fp, "Records Read: %s\n", P->Vals.PhaseIEnd64.RecsRead);
        fprintf(fp, "Records Skipped: %s\n", P->Vals.PhaseIEnd64.RecsSkipped);
        fprintf(fp, "Records Rejected: %s\n", P->Vals.PhaseIEnd64.RecsRejected);
        fprintf(fp, "Records Sent: %s\n", P->Vals.PhaseIEnd64.RecsSent);
        break;
 
    case NMEventPhaseIIEnd64 :
        fprintf(fp, "exit called @ application complete for table %d.\n",
                P->Vals.PhaseIIEnd64.TableNo);
        fprintf(fp, "%s updates, %s inserts, %s deletes\n",
                P->Vals.PhaseIIEnd64.Updates,
                P->Vals.PhaseIIEnd64.Inserts,
                P->Vals.PhaseIIEnd64.Deletes);
        break;

    case NMEventErrorTableI64 :
        fprintf(fp, 
               "exit called @ ET Table[%d] Drop : %s records in table.\n",
                P->Vals.ErrorTableI64.TableNo, P->Vals.ErrorTableI64.Rows);
        break;

    case NMEventErrorTableII64 :
        fprintf(fp, 
               "exit called @ UV Table[%d] Drop : %s records in table.\n",
                P->Vals.ErrorTableII64.TableNo, P->Vals.ErrorTableII64.Rows);
        break;

    case NMEventImportEnd64 :
        fprintf(fp, "exit called @ import %d ending.\n",
                     P->Vals.ImportEnd64.ImportNo);
        fprintf(fp, "Records Read: %s\n", P->Vals.ImportEnd64.RecsRead);
        fprintf(fp, "Records Skipped: %s\n", P->Vals.ImportEnd64.RecsSkipped);
        fprintf(fp, "Records Rejected: %s\n", P->Vals.ImportEnd64.RecsRejected);
        fprintf(fp, "Records Sent: %s\n", P->Vals.ImportEnd64.RecsSent);
        break;
 
    case NMEventDeleteInitEON : 
        fprintf(fp, "exit called @ mload delete init.\n");
        fprintf(fp, "Version: %s\n", P->Vals.DeleteInitEON.VersionId);
        fprintf(fp, "Utility: %s\n", P->Vals.DeleteInitEON.UtilityName);
        fprintf(fp, "User: %s\n", P->Vals.DeleteInitEON.UserName);
        if (P->Vals.DeleteInitEON.UserStringLen)
           fprintf(fp, "UserString: %s\n", P->Vals.DeleteInitEON.UserString);
        break;

    case NMEventDeleteBeginEON :
        fprintf(fp, "exit called @ delete app start: Databasename : %s.\n",
            P->Vals.DeleteBeginEON.DBaseName);                     /*SA-29992*/
        fprintf(fp, "exit called @ delete app start for table[%d]: %s.\n",
                P->Vals.DeleteBeginEON.TableNo, P->Vals.DeleteBeginEON.TableName);
        break;
 
    case NMEventDeleteEnd64 :
        fprintf(fp, "exit called @ delete app done for table[%d]: %s rows.\n",
                P->Vals.DeleteEnd64.TableNo, P->Vals.DeleteEnd64.Deletes);
        break;
    }
    /*<==SA-29992*/
    fclose(fp);
    return(0);
}
