#ifndef EXPNFYXT_H
#define EXPNFYXT_H
/************************************************************************
*                                                                       *
* Title: EXPNFYXT.H - FastExport type defintions for NOTIFY exits       *
*                                                                       *
*                                                                       *
* Copyright 1996-2014,2021 by Teradata Corporation.                     *
* All Rights Reserved.                                                  *
* TERADATA CONFIDENTIAL AND TRADE SECRET                                * 
*                                                                       *
* This copyrighted material is the Confidential, Unpublished            *
* Property of the Teradata Corporation.  This copyright notice and      *
* any other copyright notices included in machine readable              *
* copies must be reproduced on all authorized copies.                   *
*                                                                       *
*  Purpose       To aid in the implementation of a NOTIFY exit for      *
*                FastExport.                                            *
*                                                                       *
*  Description   Type definitions for NOTIFY.                           *
*                                                                       *
* History Information                                                   *
*                                                                       *
* Revision    Date     Issue    DID      Comments                       *
* ----------- -------- -------- -------- ------------------------------ *
* 17.10.00.01 06202021 SA-53075 HM186000 MF connectivity via gateway    *
*                                                                       *
* Revision    Date     DR    DID     Comments                           *
* ----------- -------- ----- ------- -----------------------------------*
* 15.00.00.00 03212013 SA-29928 NT185003 Make Notify Exit compatible    *
*                                        with previous release          *
* 14.10.00.01 11092012 SA-28537 AB185052 Notify Exit to support EON     *
* 14.10.00.00 07272012 SA-27709 AB185052 Large Count support for EXIT   *
* 14.00.00.02 10032011 117581 AS185203 Support Extended Object Names    *
* 14.00.00.01 11012010 112036 SV185048 Add database name to notify      *
* 13.10.00.03 02152010 139205 AB185052 Stack corruption with Notify Exit*
* 13.10.00.02 12172009 136629 NT185003 core dump with Notify Exit       *
* 13.01.00.00 04092009 124562 YY151001 FEXP w/o Apooling support        *
* 13.00.00.00 09102007 114415 NT185003 Teradata Corporation Copyright   *
* 07.08.00.01 10052005 96207 CSG     Port to HP-UX IA64                 *
* 07.05.00.00 03122001 53284 CSG     Port FEXP to HP-UX                 *
* 07.02.00.01 07241998 42570 SFD     Update NOTIFY Event values         *
* 07.02.00.00 06221998 42570 SFD     Update NOTIFY EXIT interface       *
* 06.00.00.00 11/15/96 38008 MKB     Add ClearCase support              *
*                                                                       *
* Past History                                                          *
*                H3_00  96Feb19  CME  DR 34580 add Export-like features *
*                H3_01  96Apr15  MKB  DR 35873 MTEST compatibility      *
*                                                                       *
************************************************************************/
 
/**************************************/
/* Structure for User Exit Interface  */
/* DR42570 - redesigned and rewritten */
/**************************************/
                                                      /* DR53284  -->  */

/* The following typedef has been commented out here and has been      */
/* put in expnfyxt.c because of the reasons:-                          */
/* 1) This header file is being used by other fexp source files.       */
/*    They are taking type defintions  already   coptypes.h.           */
/*    So on HP-UX  compiler is encountering type redefintion error     */
/* 2) This has been put in expnfyxt.c ,because this file is using      */
/*    UInt32 , and not using coptypes.h                                */
/* typedef unsigned long UInt32;  */                 /* DR53284  -->   */


#define NOTIFYID_FASTLOAD      1
#define NOTIFYID_MULTILOAD     2
#define NOTIFYID_FASTEXPORT    3
#define NOTIFYID_BTEQ          4
#define NOTIFYID_TPUMP         5

#define MAXVERSIONIDLEN       32
#define MAXUTILITYNAMELEN     32
#define MAXUSERNAMELEN        64   /* DR117581 *//* SA-28537 *//* SA-29928 */
#define MAXUSERSTRLEN         80
#define MAXFILENAMELEN       256
#define MAXDBNAMELEN          62   /* DR117581 *//*  DR112036  *//*SA-28537*/
                                   /* SA-29928 */

/* DR139205 ---> */
#ifdef WIN32
#define MAXREQUESTLEN        1000000
#else
#define MAXREQUESTLEN        1048576 /* DR136629 */
#endif
/* DR139205 <--- */
/* SA-27709 ---> */
#define MAXUINT64             24 
#ifdef WIN32
typedef unsigned __int64   UInt64 ;
#endif
/* SA-27709 <--- */

typedef enum {
    NXEventInitialize     = 0,
    NXEventFileInmodOpen  = 1,
    NXEventDBSRestart     = 9,
    NXEventCLIError       = 10,
    NXEventDBSError       = 11,
    NXEventExit           = 12,
    NXEventExportBegin    = 31,
    NXEventReqSubmitBegin = 32,
    NXEventReqSubmitEnd   = 33,
    NXEventReqFetchBegin  = 34,
    NXEventFileOutmodOpen = 35,
    NXEventStmtFetchBegin = 36,
    NXEventStmtFetchEnd   = 37,
    NXEventReqFetchEnd    = 38,
    NXEventExportEnd      = 39,         /*DR124562*/
    NXEventBlockCount     = 40,         /*DR124562*/
    NXEventExportEnd64    = 41,         /*SA-27709*/
    NXEventInitializeEON      = 42,     /*SA-28537*/
    NXEventReqSubmitBeginEON  = 43,     /*SA-28537*/
    NXEventExportBeginEON     = 44      /*SA-28537*/
} NfyExpEvent;
 
typedef struct _FXNotifyExitParm {
   UInt32 Event;       
   union {
      struct {
         UInt32 VersionLen;
         char   VersionId[MAXVERSIONIDLEN];
         UInt32 UtilityId;
         UInt32 UtilityNameLen;
         char   UtilityName[MAXUTILITYNAMELEN];
         UInt32 UserNameLen;
         char   UserName[MAXUSERNAMELEN];
         UInt32 UserStringLen;
         char   UserString[MAXUSERSTRLEN];
      }Initialize;
      /* SA-28537 ---> */
      struct {
         UInt32 VersionLen;
         char   VersionId[MAXVERSIONIDLEN];
         UInt32 UtilityId;
         UInt32 UtilityNameLen;
         char   UtilityName[MAXUTILITYNAMELEN];
         UInt32 UserNameLen;
         char   *UserName;
         UInt32 UserStringLen;
         char   UserString[MAXUSERSTRLEN];
      }InitializeEON;
       /* SA-28537 <--- */
      struct {
         UInt32 FileNameLen;
         char   FileOrInmodName[MAXFILENAMELEN];
         UInt32 dummy;
      } FileInmodOpen ;
      struct {
         UInt32 dummy;
      } DBSRestart;
      struct {
         UInt32 ErrorCode;
      } CLIError;
      struct {
         UInt32 ErrorCode;
      } DBSError;
      struct {
         UInt32 ReturnCode;
      } Exit;
      struct {
         UInt32 dummy;
         char DatabaseName[MAXDBNAMELEN];   /*  DR112036  */ 
      } ExportBegin;
      /* SA-28537 ---> */
      struct {
         UInt32 dummy;
         char *DatabaseName;
      } ExportBeginEON;
      /* SA-28537 <--- */
      struct {
         UInt32 RequestLen;
         char Request[MAXREQUESTLEN];
      } ReqSubmitBegin;
      /* SA-28537 ---> */
      struct {
         UInt32 RequestLen;
         char *Request;
      } ReqSubmitBeginEON;
      /* SA-28537 <--- */
      struct {
         UInt32 StatementCnt;
         UInt32 BlockCnt;
      } ReqSubmitEnd;
      struct {
         UInt32 dummy;
      } ReqFetchBegin;
      struct {
         UInt32 FileNameLen;
         char   FileOrOutmodName[MAXFILENAMELEN];
      } FileOutmodOpen;
      struct {
         UInt32 StatementNo;
         UInt32 BlockCnt;
      } StmtFetchBegin;
      struct {
         UInt32 Records;
      } StmtFetchEnd;
      struct {
         UInt32 RecsExported;
         UInt32 RecsRejected;
      } ReqFetchEnd;
      struct {
         UInt32 RecsExported;           /*SA-27709*/   /* THOMAS */     
         UInt32 RecsRejected;
      } ExportEnd;
      struct {                     /*SA-27709 --->*/    
         char RecsExported[MAXUINT64];
         UInt32 RecsRejected;
      }ExportEnd64;                /*SA-27709 --->*/
      struct {                          /*DR124562*/
         UInt32 BlockCount;             /*DR124562*/
      } BlockCount;                     /*DR124562*/
   } Vals;
} FXNotifyExitParm;
 
/*DR 96207 -->*/

#ifdef __MVS__                                     /* SA-53075 */
extern long FXNotifyExit(
#else
extern Int32 FXNotifyExit(
#endif

/*DR 96207 <--*/

#ifdef __STDC__                                 /*H3_01*/
                         FXNotifyExitParm *Parms
#endif                                          /*H3_01*/
);
 
#endif /* EXPNFYXT_H */
