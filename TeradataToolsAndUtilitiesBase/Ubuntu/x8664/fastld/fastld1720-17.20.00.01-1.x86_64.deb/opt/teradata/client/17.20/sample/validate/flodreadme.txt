Overview:
  This directory contains a quick start validation tool to validate Teradata
  FastLoad after installation.

Directory Contents:
  flodvalidate.bat -- This script is installed on Windows platform. You must
  execute this script from its current installed location.  
  Usage: flodvalidate [NODEID] [UserName] [UserPassword]
  where: [NODEID] is a database name Id.
         [UserName] is a database User Name.
         [UserPassword] is a database User Password.

  flodvalidate.ksh -- This script is installed on UNIX platforms. You must
  execute this script from its current installed location.  
  Usage: ./flodvalidate.ksh [NODEID] [UserName] [UserPassword]
  where: [NODEID] is a database name Id.
         [UserName] is a database User Name.
         [UserPassword] is a database User Password.
